﻿INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
6963,2419,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
6964,2420,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
6965,2421,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
6966,2421,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
6967,2422,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
6968,2422,319);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
6969,2423,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
6970,2423,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
6971,2423,320);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
6972,2424,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
6973,2424,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
6974,2425,323);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
6975,2425,324);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
6976,2425,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
6977,2426,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
6978,2427,326);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
6979,2428,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
6980,2429,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
6981,2429,328);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
6982,2430,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
6983,2430,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
6984,2431,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
6985,2431,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
6986,2431,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
6987,2432,330);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
6988,2432,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
6989,2432,332);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
6990,2432,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
6991,2432,334);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
6992,2433,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
6993,2433,335);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
6994,2434,336);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
6995,2434,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
6996,2434,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
6997,2434,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
6998,2435,337);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
6999,2435,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7000,2435,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7001,2436,337);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7002,2436,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7003,2437,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7004,2438,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7005,2439,340);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7006,2440,341);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7007,2441,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7008,2442,343);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7009,2443,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7010,2444,344);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7011,2444,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7012,2444,345);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7013,2445,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7014,2445,347);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7015,2445,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7016,2445,336);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7017,2446,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7018,2446,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7019,2446,348);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7020,2447,349);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7021,2447,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7022,2448,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7023,2448,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7024,2448,350);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7025,2449,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7026,2449,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7027,2449,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7028,2450,351);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7029,2450,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7030,2451,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7031,2451,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7032,2451,352);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7033,2451,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7034,2451,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7035,2452,353);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7036,2452,354);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7037,2453,344);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7038,2453,355);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7039,2453,356);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7040,2453,357);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7041,2454,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7042,2455,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7043,2455,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7044,2456,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7045,2457,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7046,2457,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7047,2458,360);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7048,2459,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7049,2459,361);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7050,2460,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7051,2460,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7052,2460,361);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7053,2461,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7054,2461,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7055,2461,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7056,2462,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7057,2462,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7058,2462,362);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7059,2463,363);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7060,2464,364);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7061,2465,365);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7062,2466,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7063,2466,366);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7064,2467,361);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7065,2467,360);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7066,2468,364);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7067,2468,336);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7068,2469,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7069,2469,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7070,2470,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7071,2470,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7072,2471,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7073,2471,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7074,2471,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7075,2472,367);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7076,2473,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7077,2473,367);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7078,2474,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7079,2475,319);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7080,2475,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7081,2476,369);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7082,2477,370);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7083,2478,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7084,2478,371);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7085,2479,366);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7086,2480,372);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7087,2481,373);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7088,2481,362);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7089,2481,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7090,2481,374);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7091,2482,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7092,2482,376);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7093,2482,377);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7094,2483,376);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7095,2483,377);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7096,2484,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7097,2484,378);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7098,2485,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7099,2486,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7100,2486,324);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7101,2486,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7102,2487,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7103,2488,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7104,2489,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7105,2489,367);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7106,2490,381);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7107,2491,382);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7108,2492,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7109,2492,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7110,2492,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7111,2492,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7112,2492,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7113,2493,382);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7114,2493,381);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7115,2494,383);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7116,2494,384);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7117,2495,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7118,2495,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7119,2495,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7120,2496,386);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7121,2496,347);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7122,2496,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7123,2496,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7124,2496,388);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7125,2497,374);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7126,2497,389);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7127,2498,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7128,2498,390);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7129,2498,374);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7130,2499,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7131,2499,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7132,2499,391);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7133,2500,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7134,2500,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7135,2501,392);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7136,2501,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7137,2501,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7138,2502,394);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7139,2503,344);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7140,2503,394);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7141,2504,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7142,2504,395);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7143,2504,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7144,2504,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7145,2504,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7146,2505,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7147,2505,395);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7148,2505,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7149,2505,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7150,2505,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7151,2505,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7152,2506,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7153,2506,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7154,2507,330);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7155,2507,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7156,2507,334);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7157,2508,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7158,2508,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7159,2508,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7160,2509,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7161,2509,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7162,2509,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7163,2509,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7164,2509,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7165,2510,396);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7166,2511,348);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7167,2511,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7168,2511,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7169,2511,336);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7170,2512,324);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7171,2512,397);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7172,2513,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7173,2513,336);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7174,2514,398);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7175,2515,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7176,2515,398);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7177,2515,399);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7178,2516,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7179,2516,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7180,2516,398);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7181,2516,350);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7182,2517,369);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7183,2517,398);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7184,2518,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7185,2518,398);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7186,2519,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7187,2519,400);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7188,2519,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7189,2519,336);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7190,2520,381);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7191,2520,374);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7192,2521,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7193,2521,401);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7194,2522,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7195,2522,369);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7196,2522,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7197,2522,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7198,2523,402);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7199,2523,349);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7200,2524,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7201,2524,355);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7202,2524,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7203,2524,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7204,2525,390);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7205,2525,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7206,2525,354);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7207,2526,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7208,2526,348);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7209,2526,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7210,2527,404);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7211,2528,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7212,2528,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7213,2528,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7214,2528,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7215,2529,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7216,2529,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7217,2529,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7218,2530,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7219,2530,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7220,2530,405);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7221,2530,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7222,2531,406);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7223,2531,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7224,2531,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7225,2532,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7226,2532,360);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7227,2532,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7228,2533,360);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7229,2534,407);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7230,2535,408);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7231,2535,407);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7232,2536,407);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7233,2536,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7234,2536,409);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7235,2537,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7236,2537,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7237,2537,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7238,2537,411);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7239,2538,412);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7240,2538,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7241,2538,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7242,2539,413);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7243,2540,413);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7244,2540,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7245,2540,414);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7246,2541,413);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7247,2541,415);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7248,2541,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7249,2541,357);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7250,2542,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7251,2542,413);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7252,2542,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7253,2542,320);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7254,2543,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7255,2543,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7256,2543,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7257,2544,416);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7258,2545,382);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7259,2545,374);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7260,2546,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7261,2546,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7262,2546,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7263,2546,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7264,2546,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7265,2547,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7266,2547,417);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7267,2548,412);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7268,2548,418);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7269,2548,357);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7270,2549,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7271,2549,351);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7272,2549,384);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7273,2550,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7274,2550,351);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7275,2550,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7276,2551,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7277,2551,419);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7278,2552,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7279,2552,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7280,2552,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7281,2552,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7282,2553,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7283,2553,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7284,2553,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7285,2553,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7286,2553,336);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7287,2553,366);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7288,2554,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7289,2554,415);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7290,2555,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7291,2555,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7292,2555,350);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7293,2555,344);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7294,2556,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7295,2556,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7296,2556,420);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7297,2557,362);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7298,2558,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7299,2558,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7300,2558,421);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7301,2559,394);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7302,2559,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7303,2559,323);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7304,2560,422);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7305,2561,423);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7306,2561,405);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7307,2562,424);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7308,2562,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7309,2563,347);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7310,2563,425);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7311,2563,426);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7312,2564,347);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7313,2564,427);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7314,2564,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7315,2564,428);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7316,2565,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7317,2565,371);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7318,2565,390);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7319,2566,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7320,2566,429);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7321,2567,430);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7322,2567,319);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7323,2568,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7324,2568,429);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7325,2569,431);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7326,2570,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7327,2570,431);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7328,2570,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7329,2571,432);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7330,2571,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7331,2572,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7332,2572,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7333,2572,433);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7334,2573,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7335,2573,433);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7336,2573,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7337,2573,434);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7338,2574,435);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7339,2574,347);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7340,2575,436);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7341,2575,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7342,2575,347);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7343,2575,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7344,2576,437);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7345,2577,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7346,2577,438);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7347,2577,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7348,2577,439);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7349,2578,384);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7350,2578,433);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7351,2579,386);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7352,2579,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7353,2579,351);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7354,2580,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7355,2580,440);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7356,2580,334);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7357,2581,386);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7358,2581,319);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7359,2581,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7360,2582,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7361,2582,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7362,2582,441);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7363,2583,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7364,2583,351);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7365,2583,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7366,2584,328);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7367,2585,442);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7368,2585,443);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7369,2585,444);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7370,2586,445);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7371,2586,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7372,2587,343);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7373,2587,446);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7374,2588,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7375,2588,343);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7376,2588,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7377,2588,439);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7378,2588,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7379,2589,447);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7380,2589,336);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7381,2589,364);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7382,2590,448);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7383,2590,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7384,2590,444);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7385,2591,449);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7386,2591,443);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7387,2591,350);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7388,2592,450);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7389,2592,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7390,2592,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7391,2593,451);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7392,2593,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7393,2593,384);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7394,2593,405);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7395,2594,352);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7396,2595,351);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7397,2595,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7398,2595,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7399,2596,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7400,2596,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7401,2596,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7402,2596,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7403,2596,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7404,2596,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7405,2597,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7406,2597,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7407,2597,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7408,2597,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7409,2597,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7410,2598,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7411,2598,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7412,2598,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7413,2598,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7414,2598,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7415,2599,430);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7416,2599,352);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7417,2600,386);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7418,2600,443);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7419,2601,452);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7420,2601,404);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7421,2601,349);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7422,2602,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7423,2602,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7424,2602,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7425,2603,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7426,2603,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7427,2603,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7428,2603,444);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7429,2603,453);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7430,2604,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7431,2604,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7432,2604,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7433,2605,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7434,2605,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7435,2605,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7436,2605,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7437,2606,425);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7438,2607,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7439,2607,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7440,2607,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7441,2607,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7442,2607,454);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7443,2608,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7444,2608,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7445,2608,418);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7446,2609,415);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7447,2609,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7448,2609,357);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7449,2610,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7450,2610,361);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7451,2610,433);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7452,2611,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7453,2611,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7454,2611,334);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7455,2611,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7456,2611,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7457,2611,336);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7458,2612,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7459,2612,455);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7460,2613,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7461,2613,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7462,2613,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7463,2613,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7464,2613,409);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7465,2614,328);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7466,2614,456);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7467,2614,457);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7468,2615,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7469,2615,458);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7470,2615,459);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7471,2615,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7472,2616,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7473,2616,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7474,2616,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7475,2616,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7476,2616,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7477,2617,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7478,2617,396);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7479,2618,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7480,2618,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7481,2618,390);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7482,2619,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7483,2619,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7484,2619,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7485,2619,364);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7486,2620,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7487,2620,427);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7488,2620,390);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7489,2621,340);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7490,2621,383);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7491,2622,390);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7492,2622,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7493,2622,420);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7494,2623,383);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7495,2623,382);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7496,2624,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7497,2624,460);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7498,2625,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7499,2625,326);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7500,2625,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7501,2625,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7502,2625,444);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7503,2626,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7504,2626,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7505,2626,374);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7506,2626,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7507,2626,461);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7508,2627,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7509,2627,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7510,2627,450);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7511,2627,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7512,2627,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7513,2628,462);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7514,2628,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7515,2628,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7516,2629,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7517,2629,384);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7518,2630,463);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7519,2630,336);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7520,2630,464);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7521,2630,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7522,2631,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7523,2631,395);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7524,2631,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7525,2631,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7526,2631,465);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7527,2631,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7528,2632,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7529,2632,466);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7530,2632,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7531,2632,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7532,2632,334);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7533,2632,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7534,2632,467);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7535,2633,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7536,2633,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7537,2633,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7538,2634,435);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7539,2634,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7540,2634,466);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7541,2634,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7542,2634,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7543,2634,334);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7544,2634,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7545,2635,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7546,2635,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7547,2636,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7548,2636,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7549,2636,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7550,2636,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7551,2637,446);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7552,2638,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7553,2638,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7554,2638,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7555,2638,332);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7556,2639,332);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7557,2640,332);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7558,2640,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7559,2641,332);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7560,2641,468);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7561,2641,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7562,2642,460);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7563,2642,469);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7564,2643,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7565,2643,364);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7566,2643,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7567,2643,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7568,2644,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7569,2644,439);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7570,2645,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7571,2645,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7572,2645,350);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7573,2646,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7574,2646,324);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7575,2646,384);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7576,2647,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7577,2647,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7578,2647,350);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7579,2648,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7580,2648,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7581,2648,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7582,2648,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7583,2649,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7584,2649,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7585,2649,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7586,2649,440);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7587,2650,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7588,2650,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7589,2650,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7590,2650,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7591,2650,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7592,2650,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7593,2651,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7594,2651,405);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7595,2652,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7596,2652,470);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7597,2652,352);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7598,2653,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7599,2653,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7600,2653,469);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7601,2654,386);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7602,2654,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7603,2654,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7604,2655,435);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7605,2655,471);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7606,2655,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7607,2655,405);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7608,2656,401);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7609,2657,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7610,2657,360);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7611,2658,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7612,2658,390);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7613,2658,420);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7614,2659,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7615,2659,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7616,2660,356);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7617,2660,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7618,2661,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7619,2661,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7620,2661,350);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7621,2662,337);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7622,2662,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7623,2663,472);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7624,2663,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7625,2663,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7626,2664,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7627,2664,350);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7628,2665,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7629,2665,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7630,2665,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7631,2666,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7632,2666,440);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7633,2666,460);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7634,2667,386);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7635,2667,341);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7636,2667,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7637,2667,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7638,2667,388);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7639,2668,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7640,2668,431);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7641,2668,467);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7642,2668,354);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7643,2669,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7644,2669,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7645,2669,350);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7646,2669,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7647,2669,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7648,2670,421);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7649,2670,404);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7650,2670,469);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7651,2671,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7652,2671,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7653,2671,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7654,2671,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7655,2671,443);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7656,2672,422);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7657,2672,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7658,2672,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7659,2673,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7660,2673,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7661,2673,443);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7662,2674,473);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7663,2674,474);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7664,2675,347);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7665,2675,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7666,2675,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7667,2675,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7668,2676,450);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7669,2676,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7670,2676,357);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7671,2677,369);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7672,2677,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7673,2678,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7674,2678,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7675,2678,405);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7676,2678,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7677,2679,337);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7678,2679,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7679,2679,354);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7680,2680,337);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7681,2680,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7682,2680,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7683,2681,350);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7684,2681,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7685,2682,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7686,2682,458);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7687,2682,459);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7688,2682,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7689,2683,354);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7690,2683,458);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7691,2683,459);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7692,2683,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7693,2684,476);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7694,2685,476);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7695,2685,465);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7696,2686,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7697,2686,476);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7698,2686,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7699,2686,334);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7700,2686,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7701,2686,409);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7702,2687,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7703,2687,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7704,2687,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7705,2687,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7706,2687,414);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7707,2688,432);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7708,2688,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7709,2688,354);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7710,2689,382);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7711,2689,418);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7712,2689,357);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7713,2690,424);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7714,2690,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7715,2690,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7716,2691,382);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7717,2691,460);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7718,2691,420);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7719,2692,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7720,2692,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7721,2692,384);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7722,2693,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7723,2693,355);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7724,2693,404);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7725,2693,356);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7726,2693,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7727,2694,367);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7728,2694,406);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7729,2694,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7730,2695,454);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7731,2695,464);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7732,2695,384);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7733,2696,454);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7734,2696,335);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7735,2697,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7736,2697,454);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7737,2698,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7738,2698,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7739,2698,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7740,2698,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7741,2699,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7742,2699,477);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7743,2699,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7744,2699,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7745,2699,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7746,2699,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7747,2699,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7748,2699,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7749,2700,478);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7750,2700,328);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7751,2700,335);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7752,2701,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7753,2701,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7754,2701,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7755,2701,376);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7756,2701,465);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7757,2701,377);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7758,2702,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7759,2702,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7760,2702,378);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7761,2702,350);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7762,2702,399);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7763,2702,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7764,2703,373);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7765,2703,326);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7766,2703,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7767,2703,374);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7768,2704,413);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7769,2704,362);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7770,2704,479);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7771,2705,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7772,2705,364);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7773,2705,423);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7774,2705,351);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7775,2706,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7776,2706,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7777,2706,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7778,2706,435);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7779,2707,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7780,2707,398);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7781,2708,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7782,2708,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7783,2708,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7784,2708,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7785,2708,480);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7786,2708,481);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7787,2709,482);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7788,2709,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7789,2709,398);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7790,2710,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7791,2710,418);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7792,2710,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7793,2711,402);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7794,2711,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7795,2711,390);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7796,2712,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7797,2712,345);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7798,2712,326);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7799,2713,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7800,2713,345);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7801,2713,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7802,2713,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7803,2713,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7804,2714,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7805,2714,361);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7806,2714,444);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7807,2715,381);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7808,2715,352);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7809,2715,420);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7810,2715,390);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7811,2716,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7812,2716,319);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7813,2717,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7814,2717,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7815,2717,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7816,2717,319);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7817,2718,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7818,2718,420);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7819,2719,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7820,2719,364);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7821,2719,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7822,2719,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7823,2719,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7824,2719,367);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7825,2720,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7826,2720,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7827,2720,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7828,2720,469);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7829,2721,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7830,2721,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7831,2721,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7832,2722,344);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7833,2722,418);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7834,2723,483);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7835,2723,360);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7836,2723,444);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7837,2724,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7838,2724,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7839,2724,384);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7840,2725,354);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7841,2725,417);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7842,2726,412);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7843,2726,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7844,2726,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7845,2727,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7846,2727,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7847,2727,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7848,2727,355);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7849,2728,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7850,2728,363);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7851,2728,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7852,2728,429);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7853,2729,477);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7854,2729,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7855,2729,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7856,2729,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7857,2729,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7858,2730,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7859,2730,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7860,2730,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7861,2730,416);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7862,2730,399);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7863,2730,484);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7864,2731,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7865,2731,418);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7866,2731,357);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7867,2732,404);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7868,2732,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7869,2733,362);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7870,2733,479);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7871,2734,431);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7872,2734,351);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7873,2735,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7874,2735,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7875,2735,386);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7876,2735,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7877,2735,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7878,2735,388);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7879,2735,485);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7880,2736,383);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7881,2736,355);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7882,2737,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7883,2737,462);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7884,2737,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7885,2737,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7886,2738,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7887,2738,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7888,2739,486);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7889,2739,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7890,2739,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7891,2739,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7892,2740,353);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7893,2740,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7894,2740,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7895,2740,354);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7896,2740,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7897,2741,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7898,2741,384);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7899,2741,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7900,2742,436);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7901,2742,355);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7902,2742,404);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7903,2742,356);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7904,2743,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7905,2743,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7906,2743,347);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7907,2743,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7908,2744,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7909,2744,332);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7910,2745,381);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7911,2745,396);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7912,2746,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7913,2746,341);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7914,2746,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7915,2747,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7916,2747,413);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7917,2747,395);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7918,2747,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7919,2747,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7920,2747,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7921,2748,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7922,2748,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7923,2748,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7924,2748,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7925,2748,481);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7926,2748,390);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7927,2748,374);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7928,2749,413);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7929,2749,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7930,2750,482);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7931,2750,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7932,2750,399);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7933,2751,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7934,2751,386);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7935,2751,362);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7936,2751,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7937,2751,388);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7938,2752,355);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7939,2752,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7940,2752,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7941,2752,374);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7942,2752,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7943,2753,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7944,2753,487);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7945,2753,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7946,2753,488);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7947,2754,486);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7948,2754,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7949,2754,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7950,2755,384);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7951,2755,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7952,2756,347);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7953,2756,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7954,2756,409);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7955,2757,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7956,2757,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7957,2758,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7958,2758,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7959,2758,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7960,2758,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7961,2758,479);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7962,2759,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7963,2759,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7964,2759,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7965,2760,347);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7966,2760,365);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7967,2761,489);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7968,2761,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7969,2761,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7970,2762,446);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7971,2762,457);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7972,2763,344);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7973,2763,332);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7974,2763,469);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7975,2764,349);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7976,2764,324);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7977,2765,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7978,2765,337);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7979,2765,482);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7980,2766,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7981,2766,364);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7982,2766,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7983,2766,349);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7984,2766,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7985,2766,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7986,2767,386);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7987,2767,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7988,2767,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7989,2767,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7990,2767,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7991,2768,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7992,2768,479);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7993,2769,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7994,2769,324);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7995,2769,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7996,2770,480);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7997,2770,374);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7998,2771,426);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
7999,2771,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8000,2771,350);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8001,2772,477);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8002,2772,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8003,2772,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8004,2772,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8005,2772,469);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8006,2773,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8007,2773,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8008,2773,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8009,2773,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8010,2773,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8011,2774,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8012,2774,390);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8013,2775,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8014,2775,324);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8015,2776,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8016,2776,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8017,2776,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8018,2777,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8019,2777,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8020,2777,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8021,2777,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8022,2778,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8023,2778,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8024,2778,350);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8025,2778,490);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8026,2779,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8027,2779,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8028,2779,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8029,2779,383);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8030,2779,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8031,2780,390);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8032,2780,457);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8033,2780,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8034,2781,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8035,2781,386);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8036,2781,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8037,2781,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8038,2781,388);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8039,2782,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8040,2782,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8041,2782,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8042,2782,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8043,2783,383);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8044,2783,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8045,2783,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8046,2783,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8047,2784,334);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8048,2785,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8049,2785,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8050,2785,364);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8051,2785,433);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8052,2786,356);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8053,2786,433);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8054,2787,408);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8055,2787,469);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8056,2787,364);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8057,2788,408);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8058,2788,335);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8059,2789,347);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8060,2789,422);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8061,2789,357);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8062,2790,422);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8063,2790,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8064,2790,384);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8065,2791,383);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8066,2791,360);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8067,2792,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8068,2792,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8069,2792,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8070,2792,367);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8071,2792,443);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8072,2793,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8073,2793,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8074,2793,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8075,2793,367);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8076,2793,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8077,2794,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8078,2794,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8079,2795,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8080,2795,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8081,2795,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8082,2795,347);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8083,2795,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8084,2795,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8085,2796,386);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8086,2796,347);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8087,2796,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8088,2796,388);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8089,2796,405);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8090,2797,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8091,2797,381);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8092,2797,384);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8093,2798,477);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8094,2798,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8095,2798,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8096,2798,390);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8097,2799,386);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8098,2799,412);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8099,2800,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8100,2800,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8101,2800,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8102,2800,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8103,2801,415);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8104,2801,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8105,2801,374);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8106,2802,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8107,2802,347);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8108,2802,336);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8109,2803,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8110,2803,384);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8111,2804,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8112,2804,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8113,2804,491);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8114,2805,436);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8115,2805,415);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8116,2806,401);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8117,2806,477);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8118,2806,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8119,2806,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8120,2807,477);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8121,2807,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8122,2807,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8123,2807,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8124,2807,351);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8125,2807,384);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8126,2808,413);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8127,2808,415);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8128,2808,332);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8129,2809,330);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8130,2809,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8131,2809,334);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8132,2810,328);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8133,2810,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8134,2810,335);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8135,2811,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8136,2811,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8137,2811,335);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8138,2811,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8139,2812,408);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8140,2812,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8141,2812,350);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8142,2813,408);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8143,2813,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8144,2813,492);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8145,2813,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8146,2813,351);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8147,2814,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8148,2814,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8149,2814,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8150,2815,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8151,2815,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8152,2815,434);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8153,2816,493);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8154,2817,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8155,2817,357);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8156,2817,469);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8157,2818,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8158,2818,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8159,2818,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8160,2818,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8161,2819,494);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8162,2819,495);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8163,2819,469);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8164,2820,399);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8165,2820,496);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8166,2820,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8167,2821,355);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8168,2821,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8169,2821,399);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8170,2821,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8171,2822,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8172,2822,383);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8173,2822,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8174,2822,443);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8175,2823,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8176,2823,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8177,2823,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8178,2823,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8179,2823,352);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8180,2823,481);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8181,2824,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8182,2824,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8183,2824,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8184,2824,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8185,2825,381);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8186,2825,334);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8187,2825,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8188,2826,477);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8189,2826,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8190,2826,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8191,2826,341);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8192,2826,328);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8193,2827,452);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8194,2827,469);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8195,2827,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8196,2827,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8197,2828,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8198,2828,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8199,2829,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8200,2829,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8201,2829,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8202,2829,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8203,2830,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8204,2830,336);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8205,2830,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8206,2831,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8207,2831,347);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8208,2831,497);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8209,2832,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8210,2832,364);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8211,2832,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8212,2833,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8213,2833,364);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8214,2833,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8215,2834,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8216,2834,363);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8217,2835,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8218,2835,407);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8219,2835,374);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8220,2836,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8221,2836,328);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8222,2836,374);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8223,2837,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8224,2837,328);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8225,2838,347);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8226,2838,382);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8227,2838,363);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8228,2839,383);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8229,2839,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8230,2840,386);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8231,2840,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8232,2840,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8233,2840,388);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8234,2841,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8235,2841,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8236,2841,467);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8237,2842,451);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8238,2842,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8239,2842,384);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8240,2842,374);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8241,2843,373);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8242,2843,332);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8243,2843,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8244,2843,384);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8245,2843,374);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8246,2844,424);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8247,2845,376);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8248,2845,377);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8249,2846,412);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8250,2846,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8251,2846,466);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8252,2846,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8253,2846,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8254,2846,334);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8255,2846,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8256,2847,363);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8257,2847,439);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8258,2848,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8259,2848,431);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8260,2848,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8261,2848,490);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8262,2849,356);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8263,2849,381);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8264,2849,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8265,2850,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8266,2850,381);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8267,2850,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8268,2850,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8269,2850,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8270,2850,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8271,2851,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8272,2851,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8273,2852,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8274,2852,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8275,2852,454);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8276,2852,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8277,2853,454);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8278,2853,482);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8279,2854,446);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8280,2854,381);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8281,2855,427);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8282,2855,332);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8283,2856,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8284,2856,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8285,2856,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8286,2856,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8287,2857,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8288,2857,460);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8289,2858,498);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8290,2858,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8291,2858,354);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8292,2859,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8293,2859,415);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8294,2859,477);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8295,2859,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8296,2859,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8297,2860,401);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8298,2860,381);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8299,2860,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8300,2861,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8301,2861,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8302,2861,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8303,2862,413);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8304,2862,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8305,2862,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8306,2863,424);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8307,2863,367);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8308,2863,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8309,2864,427);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8310,2865,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8311,2865,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8312,2865,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8313,2866,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8314,2866,413);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8315,2867,436);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8316,2867,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8317,2867,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8318,2868,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8319,2868,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8320,2868,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8321,2868,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8322,2868,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8323,2868,481);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8324,2868,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8325,2869,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8326,2869,401);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8327,2870,386);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8328,2870,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8329,2871,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8330,2871,386);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8331,2871,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8332,2871,388);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8333,2871,350);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8334,2871,490);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8335,2871,370);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8336,2872,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8337,2872,386);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8338,2872,413);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8339,2872,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8340,2872,388);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8341,2872,350);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8342,2872,490);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8343,2872,370);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8344,2873,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8345,2873,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8346,2873,413);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8347,2873,351);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8348,2873,499);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8349,2874,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8350,2874,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8351,2874,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8352,2874,364);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8353,2874,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8354,2874,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8355,2874,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8356,2875,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8357,2875,409);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8358,2876,337);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8359,2876,416);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8360,2877,332);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8361,2877,433);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8362,2878,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8363,2878,482);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8364,2878,351);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8365,2879,404);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8366,2879,337);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8367,2879,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8368,2880,355);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8369,2880,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8370,2880,367);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8371,2881,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8372,2881,337);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8373,2881,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8374,2882,500);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8375,2882,458);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8376,2882,459);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8377,2882,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8378,2883,328);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8379,2883,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8380,2883,469);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8381,2884,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8382,2884,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8383,2884,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8384,2884,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8385,2884,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8386,2885,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8387,2885,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8388,2885,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8389,2885,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8390,2886,348);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8391,2886,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8392,2887,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8393,2887,335);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8394,2887,469);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8395,2887,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8396,2888,337);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8397,2888,482);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8398,2888,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8399,2889,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8400,2889,364);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8401,2889,336);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8402,2889,501);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8403,2890,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8404,2890,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8405,2890,374);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8406,2890,457);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8407,2890,391);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8408,2891,439);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8409,2891,472);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8410,2892,431);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8411,2892,502);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8412,2892,352);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8413,2892,434);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8414,2893,383);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8415,2893,430);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8416,2894,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8417,2894,360);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8418,2894,324);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8419,2894,488);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8420,2895,468);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8421,2895,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8422,2896,468);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8423,2896,465);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8424,2896,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8425,2897,498);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8426,2897,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8427,2897,501);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8428,2898,425);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8429,2898,501);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8430,2898,426);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8431,2899,503);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8432,2899,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8433,2899,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8434,2899,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8435,2900,340);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8436,2900,396);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8437,2900,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8438,2901,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8439,2901,473);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8440,2902,326);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8441,2902,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8442,2902,473);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8443,2903,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8444,2903,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8445,2903,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8446,2903,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8447,2903,419);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8448,2904,469);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8449,2904,409);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8450,2904,467);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8451,2905,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8452,2905,364);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8453,2905,351);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8454,2905,457);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8455,2906,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8456,2906,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8457,2906,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8458,2907,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8459,2907,413);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8460,2907,431);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8461,2908,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8462,2908,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8463,2908,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8464,2908,382);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8465,2909,386);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8466,2909,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8467,2909,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8468,2910,330);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8469,2910,332);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8470,2910,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8471,2910,334);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8472,2911,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8473,2911,378);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8474,2911,374);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8475,2911,345);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8476,2912,413);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8477,2912,332);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8478,2912,349);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8479,2912,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8480,2913,504);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8481,2913,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8482,2913,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8483,2913,335);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8484,2913,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8485,2914,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8486,2914,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8487,2914,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8488,2914,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8489,2914,490);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8490,2915,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8491,2915,399);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8492,2915,490);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8493,2916,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8494,2916,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8495,2917,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8496,2917,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8497,2917,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8498,2917,350);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8499,2918,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8500,2918,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8501,2918,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8502,2919,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8503,2919,489);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8504,2919,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8505,2919,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8506,2920,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8507,2920,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8508,2920,345);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8509,2921,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8510,2921,425);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8511,2921,409);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8512,2921,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8513,2922,413);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8514,2922,458);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8515,2922,459);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8516,2922,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8517,2923,413);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8518,2923,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8519,2923,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8520,2923,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8521,2924,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8522,2924,384);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8523,2925,436);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8524,2925,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8525,2925,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8526,2925,319);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8527,2926,503);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8528,2926,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8529,2926,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8530,2926,351);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8531,2926,491);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8532,2927,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8533,2927,503);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8534,2927,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8535,2927,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8536,2927,374);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8537,2927,491);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8538,2928,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8539,2928,503);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8540,2928,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8541,2928,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8542,2928,491);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8543,2928,457);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8544,2929,505);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8545,2930,500);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8546,2930,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8547,2930,459);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8548,2931,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8549,2931,500);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8550,2931,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8551,2932,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8552,2932,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8553,2932,474);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8554,2932,461);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8555,2933,366);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8556,2933,506);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8557,2933,328);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8558,2934,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8559,2934,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8560,2934,374);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8561,2934,391);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8562,2935,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8563,2935,490);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8564,2936,362);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8565,2936,367);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8566,2937,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8567,2937,364);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8568,2937,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8569,2937,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8570,2938,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8571,2938,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8572,2938,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8573,2938,420);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8574,2939,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8575,2939,328);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8576,2939,409);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8577,2940,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8578,2940,319);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8579,2941,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8580,2941,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8581,2941,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8582,2941,408);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8583,2941,335);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8584,2942,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8585,2942,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8586,2942,328);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8587,2942,409);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8588,2943,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8589,2943,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8590,2943,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8591,2943,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8592,2943,328);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8593,2943,481);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8594,2943,409);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8595,2944,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8596,2944,431);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8597,2945,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8598,2945,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8599,2945,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8600,2945,461);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8601,2946,356);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8602,2946,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8603,2946,418);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8604,2946,357);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8605,2947,330);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8606,2947,413);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8607,2947,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8608,2947,334);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8609,2947,490);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8610,2948,507);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8611,2949,413);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8612,2949,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8613,2949,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8614,2949,336);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8615,2950,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8616,2950,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8617,2950,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8618,2950,431);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8619,2950,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8620,2950,420);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8621,2951,446);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8622,2951,482);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8623,2951,467);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8624,2952,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8625,2952,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8626,2952,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8627,2953,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8628,2953,364);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8629,2953,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8630,2953,351);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8631,2954,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8632,2954,480);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8633,2954,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8634,2955,381);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8635,2955,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8636,2955,374);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8637,2956,503);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8638,2956,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8639,2956,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8640,2957,503);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8641,2957,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8642,2957,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8643,2957,396);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8644,2958,503);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8645,2958,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8646,2958,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8647,2958,396);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8648,2958,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8649,2959,347);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8650,2959,422);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8651,2960,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8652,2960,477);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8653,2960,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8654,2960,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8655,2960,390);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8656,2961,415);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8657,2961,477);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8658,2961,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8659,2961,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8660,2961,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8661,2961,357);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8662,2962,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8663,2962,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8664,2963,340);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8665,2963,413);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8666,2964,413);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8667,2964,474);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8668,2965,330);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8669,2965,332);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8670,2965,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8671,2965,465);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8672,2965,334);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8673,2966,344);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8674,2966,343);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8675,2966,341);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8676,2966,508);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8677,2967,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8678,2967,438);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8679,2967,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8680,2967,491);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8681,2968,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8682,2968,383);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8683,2968,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8684,2969,364);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8685,2969,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8686,2969,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8687,2969,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8688,2969,398);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8689,2969,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8690,2970,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8691,2970,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8692,2970,477);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8693,2970,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8694,2970,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8695,2971,483);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8696,2971,397);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8697,2972,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8698,2972,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8699,2972,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8700,2973,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8701,2973,332);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8702,2973,324);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8703,2973,384);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8704,2974,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8705,2974,431);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8706,2974,420);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8707,2975,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8708,2975,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8709,2975,384);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8710,2976,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8711,2976,337);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8712,2976,433);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8713,2977,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8714,2977,418);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8715,2977,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8716,2977,357);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8717,2978,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8718,2978,356);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8719,2978,482);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8720,2978,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8721,2978,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8722,2978,350);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8723,2978,336);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8724,2979,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8725,2979,347);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8726,2979,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8727,2979,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8728,2979,474);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8729,2980,370);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8730,2980,418);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8731,2980,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8732,2981,405);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8733,2981,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8734,2982,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8735,2982,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8736,2982,439);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8737,2983,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8738,2983,402);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8739,2983,425);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8740,2983,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8741,2984,427);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8742,2984,428);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8743,2984,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8744,2984,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8745,2985,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8746,2985,418);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8747,2985,434);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8748,2986,418);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8749,2986,465);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8750,2986,434);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8751,2987,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8752,2987,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8753,2987,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8754,2987,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8755,2987,438);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8756,2987,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8757,2987,481);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8758,2988,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8759,2988,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8760,2988,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8761,2988,481);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8762,2988,334);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8763,2988,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8764,2988,409);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8765,2988,496);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8766,2989,474);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8767,2989,420);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8768,2990,509);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8769,2990,399);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8770,2990,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8771,2990,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8772,2991,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8773,2991,351);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8774,2991,467);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8775,2991,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8776,2992,351);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8777,2992,467);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8778,2992,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8779,2993,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8780,2993,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8781,2993,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8782,2993,481);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8783,2993,351);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8784,2993,467);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8785,2994,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8786,2994,477);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8787,2994,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8788,2994,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8789,2994,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8790,2995,330);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8791,2995,477);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8792,2995,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8793,2995,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8794,2995,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8795,2995,334);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8796,2995,490);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8797,2996,347);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8798,2996,345);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8799,2997,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8800,2997,345);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8801,2998,384);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8802,2998,433);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8803,2998,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8804,2999,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8805,2999,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8806,2999,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8807,2999,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8808,2999,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8809,3000,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8810,3000,386);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8811,3000,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8812,3000,415);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8813,3001,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8814,3001,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8815,3001,466);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8816,3001,414);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8817,3001,334);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8818,3002,383);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8819,3002,381);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8820,3003,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8821,3003,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8822,3003,323);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8823,3003,413);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8824,3004,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8825,3004,367);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8826,3004,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8827,3004,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8828,3005,449);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8829,3005,367);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8830,3005,390);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8831,3006,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8832,3006,480);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8833,3006,354);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8834,3007,471);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8835,3007,345);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8836,3007,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8837,3007,405);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8838,3008,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8839,3008,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8840,3008,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8841,3008,477);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8842,3008,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8843,3008,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8844,3008,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8845,3008,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8846,3009,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8847,3009,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8848,3009,367);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8849,3009,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8850,3010,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8851,3010,345);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8852,3011,450);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8853,3011,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8854,3011,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8855,3012,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8856,3012,477);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8857,3012,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8858,3012,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8859,3012,351);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8860,3013,394);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8861,3013,510);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8862,3014,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8863,3014,364);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8864,3014,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8865,3015,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8866,3015,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8867,3015,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8868,3015,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8869,3015,511);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8870,3015,512);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8871,3016,330);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8872,3016,369);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8873,3016,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8874,3016,334);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8875,3016,490);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8876,3017,347);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8877,3017,446);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8878,3018,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8879,3018,366);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8880,3018,405);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8881,3019,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8882,3019,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8883,3019,349);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8884,3019,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8885,3020,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8886,3020,431);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8887,3020,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8888,3020,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8889,3021,381);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8890,3021,450);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8891,3022,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8892,3022,390);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8893,3022,420);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8894,3023,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8895,3023,404);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8896,3024,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8897,3024,384);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8898,3024,496);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8899,3025,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8900,3025,465);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8901,3025,384);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8902,3025,496);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8903,3026,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8904,3026,367);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8905,3027,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8906,3027,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8907,3027,347);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8908,3028,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8909,3028,462);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8910,3028,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8911,3029,456);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8912,3030,422);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8913,3030,424);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8914,3030,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8915,3031,456);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8916,3031,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8917,3032,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8918,3032,355);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8919,3032,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8920,3032,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8921,3032,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8922,3033,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8923,3033,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8924,3033,413);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8925,3033,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8926,3033,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8927,3034,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8928,3034,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8929,3034,332);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8930,3034,490);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8931,3035,332);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8932,3035,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8933,3035,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8934,3036,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8935,3036,469);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8936,3036,389);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8937,3036,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8938,3036,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8939,3037,469);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8940,3037,389);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8941,3037,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8942,3037,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8943,3038,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8944,3038,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8945,3038,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8946,3038,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8947,3039,330);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8948,3039,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8949,3039,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8950,3039,334);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8951,3039,457);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8952,3040,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8953,3040,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8954,3040,496);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8955,3040,420);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8956,3041,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8957,3041,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8958,3041,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8959,3041,421);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8960,3042,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8961,3042,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8962,3042,336);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8963,3042,469);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8964,3042,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8965,3043,364);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8966,3043,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8967,3043,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8968,3043,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8969,3043,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8970,3044,340);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8971,3044,513);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8972,3045,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8973,3045,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8974,3045,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8975,3045,374);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8976,3046,402);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8977,3046,498);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8978,3046,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8979,3047,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8980,3047,378);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8981,3047,498);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8982,3047,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8983,3048,436);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8984,3048,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8985,3048,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8986,3048,411);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8987,3049,341);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8988,3049,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8989,3049,420);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8990,3050,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8991,3050,367);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8992,3051,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8993,3051,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8994,3051,450);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8995,3051,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8996,3051,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8997,3052,435);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8998,3052,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
8999,3052,409);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9000,3053,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9001,3053,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9002,3053,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9003,3053,347);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9004,3054,413);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9005,3054,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9006,3054,469);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9007,3054,390);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9008,3054,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9009,3054,420);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9010,3055,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9011,3055,374);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9012,3056,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9013,3056,482);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9014,3056,374);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9015,3057,323);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9016,3057,514);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9017,3057,467);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9018,3058,411);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9019,3058,507);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9020,3059,408);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9021,3059,462);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9022,3059,335);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9023,3060,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9024,3060,458);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9025,3060,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9026,3060,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9027,3060,459);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9028,3060,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9029,3061,337);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9030,3061,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9031,3061,345);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9032,3062,344);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9033,3062,347);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9034,3062,341);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9035,3062,508);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9036,3063,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9037,3063,425);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9038,3063,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9039,3063,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9040,3064,347);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9041,3064,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9042,3064,335);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9043,3065,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9044,3065,335);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9045,3065,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9046,3066,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9047,3066,418);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9048,3066,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9049,3066,490);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9050,3067,344);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9051,3067,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9052,3067,350);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9053,3067,469);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9054,3068,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9055,3068,334);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9056,3068,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9057,3069,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9058,3069,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9059,3069,456);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9060,3070,323);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9061,3070,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9062,3070,414);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9063,3071,477);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9064,3071,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9065,3071,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9066,3071,349);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9067,3071,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9068,3072,477);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9069,3072,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9070,3072,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9071,3072,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9072,3072,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9073,3072,384);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9074,3073,477);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9075,3073,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9076,3073,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9077,3073,332);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9078,3073,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9079,3073,384);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9080,3074,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9081,3074,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9082,3074,357);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9083,3074,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9084,3075,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9085,3075,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9086,3075,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9087,3075,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9088,3075,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9089,3076,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9090,3076,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9091,3076,351);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9092,3076,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9093,3077,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9094,3077,351);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9095,3077,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9096,3078,477);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9097,3078,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9098,3078,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9099,3078,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9100,3078,357);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9101,3079,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9102,3079,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9103,3079,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9104,3079,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9105,3080,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9106,3080,429);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9107,3081,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9108,3081,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9109,3081,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9110,3081,357);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9111,3082,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9112,3082,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9113,3082,487);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9114,3082,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9115,3083,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9116,3083,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9117,3083,390);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9118,3083,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9119,3084,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9120,3084,341);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9121,3084,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9122,3085,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9123,3085,498);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9124,3085,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9125,3086,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9126,3086,372);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9127,3086,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9128,3086,384);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9129,3087,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9130,3087,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9131,3087,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9132,3087,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9133,3087,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9134,3088,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9135,3088,366);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9136,3089,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9137,3089,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9138,3089,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9139,3089,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9140,3090,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9141,3090,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9142,3090,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9143,3090,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9144,3091,382);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9145,3091,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9146,3091,450);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9147,3092,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9148,3092,512);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9149,3093,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9150,3093,458);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9151,3093,459);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9152,3093,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9153,3094,337);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9154,3094,450);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9155,3094,397);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9156,3095,341);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9157,3095,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9158,3096,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9159,3096,365);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9160,3096,515);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9161,3097,341);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9162,3097,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9163,3098,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9164,3098,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9165,3098,350);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9166,3098,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9167,3099,351);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9168,3099,335);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9169,3099,467);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9170,3099,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9171,3100,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9172,3100,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9173,3100,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9174,3100,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9175,3100,335);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9176,3100,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9177,3101,422);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9178,3101,433);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9179,3102,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9180,3102,516);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9181,3102,490);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9182,3102,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9183,3103,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9184,3103,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9185,3103,516);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9186,3103,490);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9187,3103,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9188,3104,364);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9189,3104,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9190,3104,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9191,3104,465);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9192,3105,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9193,3105,347);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9194,3105,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9195,3105,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9196,3105,334);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9197,3105,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9198,3105,336);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9199,3105,517);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9200,3106,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9201,3106,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9202,3106,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9203,3106,334);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9204,3106,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9205,3106,336);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9206,3106,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9207,3106,517);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9208,3107,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9209,3107,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9210,3107,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9211,3107,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9212,3108,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9213,3108,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9214,3108,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9215,3109,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9216,3109,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9217,3110,326);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9218,3110,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9219,3110,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9220,3111,507);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9221,3111,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9222,3112,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9223,3112,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9224,3112,433);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9225,3112,491);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9226,3113,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9227,3113,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9228,3113,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9229,3113,434);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9230,3113,384);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9231,3114,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9232,3114,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9233,3114,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9234,3114,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9235,3115,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9236,3115,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9237,3115,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9238,3115,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9239,3115,496);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9240,3116,330);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9241,3116,446);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9242,3116,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9243,3116,440);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9244,3116,334);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9245,3116,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9246,3117,436);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9247,3117,386);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9248,3117,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9249,3117,411);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9250,3117,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9251,3118,330);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9252,3118,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9253,3118,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9254,3118,334);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9255,3118,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9256,3119,412);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9257,3119,345);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9258,3119,439);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9259,3120,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9260,3120,418);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9261,3120,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9262,3121,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9263,3121,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9264,3121,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9265,3121,355);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9266,3121,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9267,3122,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9268,3122,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9269,3123,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9270,3123,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9271,3123,421);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9272,3123,457);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9273,3124,348);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9274,3124,350);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9275,3124,374);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9276,3125,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9277,3125,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9278,3125,374);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9279,3125,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9280,3126,476);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9281,3126,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9282,3127,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9283,3127,353);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9284,3127,354);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9285,3127,497);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9286,3128,386);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9287,3128,341);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9288,3128,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9289,3129,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9290,3129,394);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9291,3129,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9292,3129,384);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9293,3130,394);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9294,3130,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9295,3130,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9296,3130,384);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9297,3131,436);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9298,3131,394);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9299,3131,518);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9300,3131,409);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9301,3132,436);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9302,3132,518);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9303,3132,409);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9304,3132,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9305,3133,348);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9306,3133,450);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9307,3133,434);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9308,3133,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9309,3134,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9310,3134,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9311,3134,419);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9312,3134,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9313,3135,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9314,3135,383);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9315,3135,332);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9316,3135,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9317,3136,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9318,3136,366);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9319,3136,332);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9320,3136,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9321,3136,374);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9322,3137,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9323,3137,395);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9324,3137,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9325,3137,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9326,3137,352);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9327,3137,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9328,3138,369);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9329,3138,418);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9330,3138,409);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9331,3138,420);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9332,3139,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9333,3139,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9334,3139,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9335,3139,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9336,3139,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9337,3139,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9338,3140,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9339,3140,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9340,3140,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9341,3140,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9342,3140,347);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9343,3140,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9344,3141,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9345,3141,431);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9346,3141,445);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9347,3141,371);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9348,3141,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9349,3142,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9350,3142,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9351,3142,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9352,3142,350);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9353,3143,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9354,3143,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9355,3143,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9356,3143,350);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9357,3143,374);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9358,3144,431);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9359,3144,519);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9360,3144,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9361,3144,409);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9362,3144,433);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9363,3145,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9364,3145,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9365,3146,477);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9366,3146,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9367,3146,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9368,3146,474);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9369,3147,386);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9370,3148,386);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9371,3148,374);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9372,3148,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9373,3149,520);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9374,3149,417);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9375,3150,362);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9376,3150,482);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9377,3150,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9378,3150,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9379,3150,459);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9380,3151,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9381,3151,336);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9382,3151,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9383,3151,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9384,3152,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9385,3152,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9386,3152,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9387,3152,336);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9388,3153,386);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9389,3153,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9390,3153,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9391,3154,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9392,3154,334);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9393,3155,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9394,3155,411);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9395,3155,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9396,3155,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9397,3155,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9398,3156,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9399,3156,371);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9400,3156,472);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9401,3156,521);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9402,3157,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9403,3157,434);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9404,3157,522);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9405,3157,345);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9406,3158,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9407,3158,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9408,3158,350);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9409,3158,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9410,3158,357);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9411,3159,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9412,3159,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9413,3159,336);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9414,3160,347);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9415,3160,349);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9416,3161,319);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9417,3161,461);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9418,3162,323);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9419,3162,422);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9420,3162,482);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9421,3162,467);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9422,3163,523);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9423,3163,352);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9424,3163,360);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9425,3163,457);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9426,3164,524);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9427,3164,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9428,3164,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9429,3165,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9430,3165,524);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9431,3165,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9432,3165,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9433,3165,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9434,3165,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9435,3165,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9436,3165,399);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9437,3166,435);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9438,3166,352);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9439,3166,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9440,3166,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9441,3167,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9442,3167,477);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9443,3167,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9444,3167,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9445,3167,352);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9446,3168,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9447,3168,356);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9448,3168,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9449,3168,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9450,3169,408);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9451,3169,472);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9452,3169,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9453,3169,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9454,3170,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9455,3170,372);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9456,3170,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9457,3171,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9458,3171,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9459,3171,457);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9460,3172,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9461,3172,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9462,3172,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9463,3172,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9464,3173,366);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9465,3173,510);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9466,3173,334);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9467,3174,413);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9468,3174,363);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9469,3175,471);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9470,3175,363);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9471,3175,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9472,3175,405);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9473,3176,413);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9474,3176,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9475,3176,460);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9476,3177,477);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9477,3177,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9478,3177,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9479,3177,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9480,3177,460);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9481,3178,344);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9482,3178,477);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9483,3178,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9484,3178,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9485,3178,341);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9486,3178,508);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9487,3179,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9488,3179,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9489,3179,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9490,3179,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9491,3179,324);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9492,3180,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9493,3180,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9494,3180,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9495,3180,349);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9496,3180,384);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9497,3181,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9498,3181,421);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9499,3181,469);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9500,3182,355);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9501,3182,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9502,3182,422);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9503,3182,351);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9504,3183,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9505,3183,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9506,3183,422);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9507,3183,351);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9508,3183,499);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9509,3184,386);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9510,3184,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9511,3184,354);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9512,3185,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9513,3185,390);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9514,3185,354);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9515,3186,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9516,3186,477);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9517,3186,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9518,3186,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9519,3186,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9520,3186,455);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9521,3187,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9522,3187,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9523,3187,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9524,3187,455);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9525,3188,477);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9526,3188,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9527,3188,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9528,3188,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9529,3188,480);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9530,3188,354);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9531,3189,431);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9532,3189,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9533,3189,335);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9534,3190,356);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9535,3190,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9536,3190,357);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9537,3191,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9538,3191,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9539,3191,356);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9540,3191,357);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9541,3192,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9542,3192,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9543,3192,345);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9544,3192,525);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9545,3193,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9546,3193,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9547,3193,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9548,3193,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9549,3193,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9550,3193,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9551,3193,399);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9552,3194,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9553,3194,349);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9554,3194,384);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9555,3195,337);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9556,3195,374);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9557,3196,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9558,3196,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9559,3196,323);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9560,3196,374);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9561,3197,360);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9562,3197,467);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9563,3197,374);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9564,3198,471);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9565,3198,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9566,3198,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9567,3198,405);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9568,3199,432);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9569,3199,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9570,3199,474);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9571,3200,344);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9572,3200,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9573,3200,357);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9574,3200,374);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9575,3200,397);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9576,3201,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9577,3201,395);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9578,3201,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9579,3201,350);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9580,3201,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9581,3201,469);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9582,3201,344);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9583,3202,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9584,3202,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9585,3203,369);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9586,3203,432);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9587,3203,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9588,3203,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9589,3204,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9590,3204,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9591,3204,336);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9592,3204,366);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9593,3205,526);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9594,3206,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9595,3206,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9596,3206,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9597,3206,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9598,3206,355);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9599,3207,436);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9600,3207,443);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9601,3207,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9602,3208,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9603,3208,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9604,3208,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9605,3208,362);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9606,3208,481);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9607,3209,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9608,3209,467);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9609,3210,355);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9610,3210,356);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9611,3210,405);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9612,3211,355);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9613,3211,348);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9614,3212,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9615,3212,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9616,3212,350);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9617,3212,336);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9618,3212,399);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9619,3212,499);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9620,3213,526);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9621,3213,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9622,3213,409);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9623,3214,386);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9624,3214,413);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9625,3214,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9626,3214,388);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9627,3215,477);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9628,3215,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9629,3215,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9630,3215,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9631,3216,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9632,3216,469);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9633,3216,324);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9634,3216,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9635,3217,422);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9636,3217,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9637,3217,490);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9638,3218,383);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9639,3218,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9640,3218,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9641,3218,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9642,3218,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9643,3218,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9644,3219,478);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9645,3219,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9646,3219,470);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9647,3219,352);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9648,3219,335);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9649,3220,413);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9650,3220,405);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9651,3220,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9652,3221,413);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9653,3221,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9654,3221,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9655,3222,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9656,3222,413);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9657,3222,350);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9658,3223,413);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9659,3223,337);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9660,3224,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9661,3224,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9662,3224,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9663,3224,351);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9664,3224,350);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9665,3224,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9666,3225,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9667,3225,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9668,3225,332);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9669,3225,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9670,3226,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9671,3226,337);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9672,3227,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9673,3227,405);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9674,3227,522);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9675,3228,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9676,3228,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9677,3228,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9678,3228,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9679,3228,361);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9680,3229,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9681,3229,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9682,3229,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9683,3230,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9684,3230,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9685,3230,390);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9686,3231,527);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9687,3231,446);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9688,3231,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9689,3232,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9690,3232,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9691,3232,332);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9692,3232,351);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9693,3233,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9694,3233,351);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9695,3234,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9696,3234,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9697,3234,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9698,3234,372);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9699,3234,481);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9700,3235,382);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9701,3235,433);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9702,3235,350);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9703,3236,347);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9704,3236,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9705,3236,528);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9706,3237,355);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9707,3237,488);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9708,3238,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9709,3238,355);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9710,3238,488);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9711,3239,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9712,3239,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9713,3239,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9714,3239,351);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9715,3239,350);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9716,3239,503);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9717,3239,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9718,3240,347);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9719,3240,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9720,3240,351);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9721,3240,350);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9722,3240,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9723,3241,383);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9724,3241,351);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9725,3241,457);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9726,3242,355);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9727,3242,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9728,3242,418);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9729,3243,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9730,3243,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9731,3243,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9732,3243,355);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9733,3244,446);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9734,3244,467);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9735,3245,527);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9736,3245,446);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9737,3246,355);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9738,3246,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9739,3247,356);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9740,3247,477);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9741,3247,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9742,3247,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9743,3247,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9744,3247,334);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9745,3247,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9746,3247,357);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9747,3248,477);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9748,3248,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9749,3248,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9750,3248,450);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9751,3248,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9752,3248,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9753,3248,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9754,3249,418);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9755,3249,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9756,3249,357);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9757,3250,386);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9758,3250,407);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9759,3250,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9760,3250,388);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9761,3251,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9762,3251,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9763,3251,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9764,3251,438);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9765,3251,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9766,3251,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9767,3252,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9768,3252,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9769,3252,374);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9770,3253,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9771,3253,355);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9772,3253,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9773,3253,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9774,3254,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9775,3254,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9776,3254,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9777,3255,418);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9778,3255,367);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9779,3255,357);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9780,3256,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9781,3256,319);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9782,3257,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9783,3257,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9784,3257,349);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9785,3257,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9786,3258,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9787,3258,323);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9788,3258,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9789,3258,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9790,3259,489);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9791,3260,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9792,3260,466);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9793,3260,334);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9794,3261,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9795,3261,466);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9796,3261,334);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9797,3261,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9798,3262,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9799,3262,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9800,3262,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9801,3262,419);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9802,3263,431);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9803,3263,419);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9804,3264,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9805,3264,462);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9806,3264,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9807,3265,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9808,3265,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9809,3265,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9810,3265,378);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9811,3266,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9812,3266,352);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9813,3266,433);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9814,3267,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9815,3267,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9816,3267,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9817,3267,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9818,3268,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9819,3268,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9820,3268,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9821,3268,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9822,3269,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9823,3269,436);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9824,3269,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9825,3269,518);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9826,3269,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9827,3269,409);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9828,3270,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9829,3270,436);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9830,3270,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9831,3270,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9832,3270,518);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9833,3270,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9834,3270,409);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9835,3271,448);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9836,3271,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9837,3271,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9838,3271,444);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9839,3272,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9840,3272,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9841,3272,337);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9842,3272,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9843,3272,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9844,3272,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9845,3273,382);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9846,3273,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9847,3273,409);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9848,3274,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9849,3274,409);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9850,3275,347);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9851,3275,328);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9852,3276,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9853,3276,477);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9854,3276,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9855,3276,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9856,3276,328);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9857,3276,374);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9858,3277,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9859,3277,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9860,3277,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9861,3277,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9862,3278,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9863,3278,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9864,3278,334);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9865,3279,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9866,3279,432);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9867,3279,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9868,3279,349);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9869,3280,432);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9870,3280,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9871,3280,490);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9872,3281,390);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9873,3281,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9874,3281,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9875,3281,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9876,3282,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9877,3282,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9878,3282,399);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9879,3282,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9880,3283,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9881,3283,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9882,3283,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9883,3283,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9884,3283,438);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9885,3283,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9886,3283,496);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9887,3284,323);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9888,3284,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9889,3285,323);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9890,3285,419);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9891,3286,413);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9892,3286,529);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9893,3286,337);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9894,3287,529);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9895,3287,337);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9896,3288,386);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9897,3288,383);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9898,3288,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9899,3289,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9900,3289,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9901,3289,332);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9902,3289,328);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9903,3289,357);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9904,3289,390);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9905,3289,427);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9906,3290,525);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9907,3290,383);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9908,3291,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9909,3291,383);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9910,3291,347);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9911,3291,525);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9912,3292,525);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9913,3292,383);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9914,3292,413);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9915,3293,347);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9916,3293,427);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9917,3293,337);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9918,3293,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9919,3294,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9920,3294,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9921,3294,356);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9922,3295,386);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9923,3295,468);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9924,3295,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9925,3296,415);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9926,3296,332);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9927,3297,381);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9928,3297,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9929,3297,367);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9930,3298,381);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9931,3298,332);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9932,3298,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9933,3299,464);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9934,3299,514);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9935,3300,529);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9936,3301,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9937,3301,361);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9938,3302,459);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9939,3302,390);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9940,3302,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9941,3303,459);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9942,3303,390);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9943,3303,420);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9944,3304,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9945,3304,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9946,3304,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9947,3305,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9948,3305,351);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9949,3306,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9950,3306,477);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9951,3306,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9952,3306,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9953,3306,349);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9954,3307,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9955,3307,349);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9956,3307,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9957,3308,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9958,3308,349);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9959,3308,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9960,3308,444);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9961,3309,364);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9962,3309,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9963,3309,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9964,3310,344);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9965,3310,356);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9966,3310,381);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9967,3310,357);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9968,3311,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9969,3311,344);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9970,3311,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9971,3311,381);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9972,3312,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9973,3312,352);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9974,3312,336);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9975,3313,344);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9976,3313,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9977,3313,530);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9978,3314,328);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9979,3314,456);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9980,3315,350);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9981,3315,490);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9982,3315,370);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9983,3316,413);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9984,3316,345);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9985,3317,431);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9986,3317,502);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9987,3317,352);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9988,3317,351);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9989,3317,434);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9990,3317,467);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9991,3318,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9992,3318,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9993,3318,482);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9994,3318,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9995,3318,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9996,3318,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9997,3318,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9998,3318,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
9999,3318,485);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10000,3319,332);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10001,3319,450);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10002,3319,357);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10003,3319,390);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10004,3320,332);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10005,3320,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10006,3320,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10007,3321,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10008,3321,413);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10009,3321,431);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10010,3321,520);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10011,3322,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10012,3322,431);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10013,3322,520);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10014,3323,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10015,3323,419);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10016,3323,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10017,3324,477);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10018,3324,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10019,3324,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10020,3324,531);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10021,3325,326);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10022,3325,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10023,3325,352);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10024,3326,411);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10025,3326,360);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10026,3326,357);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10027,3326,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10028,3327,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10029,3327,343);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10030,3327,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10031,3328,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10032,3328,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10033,3328,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10034,3328,465);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10035,3328,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10036,3329,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10037,3329,334);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10038,3330,471);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10039,3330,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10040,3330,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10041,3330,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10042,3330,405);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10043,3331,383);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10044,3331,482);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10045,3331,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10046,3332,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10047,3332,415);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10048,3332,438);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10049,3332,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10050,3333,369);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10051,3333,332);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10052,3334,384);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10053,3334,399);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10054,3335,413);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10055,3335,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10056,3335,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10057,3335,345);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10058,3336,415);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10059,3337,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10060,3337,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10061,3337,370);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10062,3337,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10063,3337,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10064,3338,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10065,3338,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10066,3338,332);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10067,3339,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10068,3339,431);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10069,3340,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10070,3340,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10071,3340,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10072,3340,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10073,3340,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10074,3341,347);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10075,3341,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10076,3341,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10077,3341,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10078,3342,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10079,3342,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10080,3342,384);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10081,3342,490);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10082,3342,436);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10083,3343,435);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10084,3343,413);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10085,3343,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10086,3344,347);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10087,3344,352);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10088,3345,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10089,3345,332);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10090,3345,490);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10091,3346,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10092,3346,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10093,3346,490);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10094,3347,480);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10095,3347,439);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10096,3347,324);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10097,3347,426);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10098,3348,413);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10099,3348,347);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10100,3348,352);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10101,3349,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10102,3349,460);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10103,3349,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10104,3350,439);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10105,3350,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10106,3350,345);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10107,3351,344);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10108,3351,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10109,3351,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10110,3351,357);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10111,3352,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10112,3352,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10113,3352,444);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10114,3353,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10115,3353,444);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10116,3354,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10117,3354,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10118,3354,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10119,3354,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10120,3354,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10121,3354,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10122,3355,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10123,3355,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10124,3355,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10125,3355,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10126,3355,334);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10127,3356,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10128,3356,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10129,3356,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10130,3356,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10131,3356,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10132,3356,418);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10133,3356,357);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10134,3357,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10135,3357,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10136,3357,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10137,3357,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10138,3357,418);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10139,3357,357);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10140,3358,469);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10141,3358,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10142,3358,361);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10143,3359,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10144,3359,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10145,3359,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10146,3359,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10147,3359,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10148,3359,350);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10149,3360,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10150,3360,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10151,3360,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10152,3360,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10153,3360,350);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10154,3360,374);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10155,3361,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10156,3361,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10157,3361,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10158,3361,408);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10159,3361,426);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10160,3361,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10161,3361,350);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10162,3361,481);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10163,3362,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10164,3362,464);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10165,3362,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10166,3362,336);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10167,3362,532);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10168,3363,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10169,3363,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10170,3363,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10171,3363,336);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10172,3363,457);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10173,3363,532);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10174,3364,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10175,3364,350);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10176,3365,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10177,3365,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10178,3365,350);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10179,3365,370);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10180,3366,477);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10181,3366,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10182,3366,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10183,3366,364);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10184,3366,336);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10185,3367,337);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10186,3367,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10187,3367,354);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10188,3367,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10189,3368,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10190,3368,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10191,3368,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10192,3368,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10193,3368,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10194,3369,340);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10195,3369,483);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10196,3369,360);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10197,3369,444);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10198,3370,340);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10199,3370,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10200,3370,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10201,3371,340);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10202,3371,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10203,3371,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10204,3371,455);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10205,3372,323);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10206,3372,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10207,3372,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10208,3373,348);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10209,3373,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10210,3373,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10211,3373,351);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10212,3374,473);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10213,3374,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10214,3374,384);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10215,3374,390);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10216,3375,477);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10217,3375,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10218,3375,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10219,3375,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10220,3375,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10221,3376,340);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10222,3376,366);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10223,3376,409);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10224,3377,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10225,3377,366);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10226,3377,378);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10227,3378,348);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10228,3378,366);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10229,3378,409);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10230,3379,386);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10231,3379,433);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10232,3379,520);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10233,3380,381);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10234,3380,418);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10235,3380,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10236,3381,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10237,3381,364);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10238,3381,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10239,3381,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10240,3381,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10241,3382,408);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10242,3382,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10243,3383,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10244,3383,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10245,3383,420);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10246,3384,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10247,3384,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10248,3384,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10249,3385,446);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10250,3385,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10251,3386,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10252,3386,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10253,3386,409);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10254,3387,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10255,3387,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10256,3387,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10257,3388,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10258,3388,441);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10259,3388,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10260,3389,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10261,3389,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10262,3389,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10263,3389,350);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10264,3390,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10265,3390,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10266,3390,533);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10267,3391,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10268,3391,533);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10269,3391,525);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10270,3392,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10271,3392,533);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10272,3393,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10273,3393,477);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10274,3393,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10275,3393,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10276,3393,533);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10277,3394,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10278,3394,434);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10279,3394,469);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10280,3394,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10281,3394,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10282,3395,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10283,3395,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10284,3395,390);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10285,3396,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10286,3396,381);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10287,3396,396);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10288,3397,356);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10289,3397,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10290,3397,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10291,3398,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10292,3398,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10293,3399,462);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10294,3400,534);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10295,3400,462);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10296,3401,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10297,3401,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10298,3401,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10299,3401,420);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10300,3401,360);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10301,3402,373);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10302,3402,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10303,3402,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10304,3402,492);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10305,3402,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10306,3402,351);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10307,3402,374);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10308,3403,373);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10309,3403,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10310,3403,492);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10311,3403,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10312,3403,351);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10313,3403,374);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10314,3404,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10315,3404,324);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10316,3404,397);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10317,3405,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10318,3405,357);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10319,3405,336);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10320,3405,535);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10321,3406,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10322,3406,535);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10323,3406,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10324,3406,336);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10325,3406,357);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10326,3407,435);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10327,3407,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10328,3408,435);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10329,3408,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10330,3409,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10331,3409,520);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10332,3409,417);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10333,3410,344);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10334,3410,341);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10335,3410,433);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10336,3410,508);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10337,3411,413);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10338,3411,351);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10339,3411,496);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10340,3412,386);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10341,3412,351);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10342,3412,496);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10343,3413,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10344,3413,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10345,3413,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10346,3413,351);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10347,3413,501);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10348,3414,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10349,3414,376);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10350,3414,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10351,3414,377);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10352,3415,383);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10353,3415,319);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10354,3415,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10355,3416,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10356,3416,431);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10357,3416,501);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10358,3417,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10359,3417,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10360,3417,395);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10361,3417,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10362,3417,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10363,3417,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10364,3418,477);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10365,3418,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10366,3418,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10367,3418,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10368,3418,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10369,3418,349);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10370,3418,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10371,3419,462);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10372,3419,516);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10373,3419,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10374,3420,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10375,3420,361);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10376,3420,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10377,3420,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10378,3421,369);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10379,3421,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10380,3421,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10381,3421,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10382,3422,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10383,3422,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10384,3422,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10385,3423,344);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10386,3423,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10387,3423,371);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10388,3423,345);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10389,3424,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10390,3424,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10391,3424,336);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10392,3424,386);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10393,3425,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10394,3425,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10395,3425,471);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10396,3425,477);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10397,3425,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10398,3425,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10399,3425,336);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10400,3425,499);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10401,3425,405);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10402,3426,363);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10403,3426,420);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10404,3427,412);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10405,3427,419);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10406,3428,369);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10407,3428,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10408,3428,332);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10409,3428,411);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10410,3429,436);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10411,3429,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10412,3430,436);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10413,3430,415);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10414,3430,397);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10415,3431,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10416,3431,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10417,3431,409);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10418,3432,330);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10419,3432,343);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10420,3432,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10421,3432,334);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10422,3432,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10423,3433,343);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10424,3433,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10425,3433,336);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10426,3433,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10427,3434,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10428,3434,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10429,3434,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10430,3434,374);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10431,3435,355);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10432,3435,361);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10433,3435,324);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10434,3435,409);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10435,3435,536);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10436,3435,389);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10437,3436,332);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10438,3436,507);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10439,3437,337);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10440,3437,319);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10441,3438,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10442,3438,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10443,3438,319);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10444,3439,386);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10445,3439,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10446,3439,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10447,3439,388);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10448,3440,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10449,3440,337);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10450,3440,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10451,3440,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10452,3441,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10453,3441,436);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10454,3441,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10455,3441,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10456,3441,405);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10457,3442,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10458,3442,366);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10459,3442,345);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10460,3443,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10461,3443,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10462,3443,371);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10463,3444,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10464,3444,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10465,3444,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10466,3444,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10467,3445,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10468,3445,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10469,3445,404);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10470,3445,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10471,3445,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10472,3445,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10473,3445,488);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10474,3446,386);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10475,3446,366);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10476,3446,354);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10477,3446,420);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10478,3447,366);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10479,3447,354);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10480,3447,420);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10481,3448,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10482,3448,381);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10483,3448,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10484,3449,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10485,3449,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10486,3449,469);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10487,3449,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10488,3449,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10489,3449,406);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10490,3450,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10491,3450,348);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10492,3450,413);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10493,3450,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10494,3451,413);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10495,3451,372);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10496,3452,413);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10497,3452,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10498,3452,350);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10499,3452,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10500,3453,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10501,3453,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10502,3453,350);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10503,3454,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10504,3454,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10505,3454,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10506,3454,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10507,3454,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10508,3454,336);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10509,3454,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10510,3455,413);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10511,3455,336);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10512,3455,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10513,3455,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10514,3456,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10515,3456,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10516,3456,356);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10517,3456,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10518,3457,450);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10519,3457,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10520,3457,357);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10521,3457,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10522,3458,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10523,3458,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10524,3458,384);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10525,3459,506);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10526,3459,444);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10527,3460,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10528,3460,506);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10529,3460,444);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10530,3461,415);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10531,3461,405);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10532,3462,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10533,3462,361);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10534,3462,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10535,3462,467);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10536,3463,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10537,3463,472);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10538,3464,483);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10539,3464,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10540,3464,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10541,3465,423);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10542,3466,386);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10543,3466,423);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10544,3466,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10545,3467,464);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10546,3467,423);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10547,3467,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10548,3468,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10549,3468,446);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10550,3468,350);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10551,3468,351);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10552,3468,407);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10553,3469,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10554,3469,355);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10555,3469,356);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10556,3469,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10557,3469,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10558,3469,350);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10559,3469,336);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10560,3470,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10561,3470,328);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10562,3470,363);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10563,3470,420);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10564,3471,537);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10565,3471,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10566,3471,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10567,3471,336);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10568,3471,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10569,3472,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10570,3472,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10571,3472,345);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10572,3473,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10573,3473,423);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10574,3473,469);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10575,3473,390);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10576,3473,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10577,3473,420);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10578,3474,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10579,3474,451);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10580,3474,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10581,3474,384);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10582,3475,451);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10583,3475,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10584,3475,384);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10585,3475,420);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10586,3476,355);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10587,3476,451);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10588,3476,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10589,3476,384);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10590,3477,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10591,3477,355);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10592,3477,451);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10593,3477,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10594,3477,384);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10595,3478,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10596,3478,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10597,3478,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10598,3478,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10599,3478,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10600,3478,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10601,3479,383);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10602,3479,430);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10603,3479,351);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10604,3480,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10605,3480,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10606,3480,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10607,3480,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10608,3480,481);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10609,3480,324);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10610,3481,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10611,3481,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10612,3481,409);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10613,3482,364);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10614,3482,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10615,3482,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10616,3482,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10617,3482,514);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10618,3482,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10619,3482,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10620,3483,383);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10621,3483,351);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10622,3483,354);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10623,3484,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10624,3484,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10625,3484,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10626,3484,378);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10627,3484,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10628,3485,408);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10629,3485,422);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10630,3486,449);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10631,3486,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10632,3486,426);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10633,3487,477);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10634,3487,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10635,3487,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10636,3487,516);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10637,3487,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10638,3488,454);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10639,3488,437);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10640,3489,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10641,3489,353);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10642,3489,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10643,3489,354);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10644,3489,443);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10645,3490,373);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10646,3490,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10647,3490,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10648,3490,374);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10649,3491,452);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10650,3491,464);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10651,3492,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10652,3492,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10653,3492,466);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10654,3492,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10655,3492,334);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10656,3492,405);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10657,3493,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10658,3493,347);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10659,3493,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10660,3493,466);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10661,3493,334);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10662,3493,405);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10663,3494,422);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10664,3494,357);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10665,3495,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10666,3495,389);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10667,3495,457);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10668,3496,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10669,3496,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10670,3496,389);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10671,3496,457);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10672,3497,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10673,3497,435);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10674,3497,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10675,3498,364);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10676,3498,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10677,3498,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10678,3499,431);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10679,3499,479);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10680,3500,343);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10681,3500,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10682,3500,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10683,3500,384);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10684,3501,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10685,3501,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10686,3501,384);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10687,3502,454);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10688,3502,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10689,3502,418);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10690,3502,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10691,3503,326);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10692,3503,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10693,3504,362);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10694,3504,420);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10695,3505,422);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10696,3505,370);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10697,3505,458);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10698,3505,459);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10699,3505,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10700,3506,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10701,3506,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10702,3506,340);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10703,3506,341);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10704,3506,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10705,3506,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10706,3506,461);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10707,3507,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10708,3507,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10709,3507,341);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10710,3507,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10711,3507,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10712,3507,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10713,3507,461);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10714,3508,436);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10715,3508,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10716,3508,334);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10717,3509,477);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10718,3509,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10719,3509,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10720,3509,494);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10721,3510,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10722,3510,340);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10723,3510,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10724,3510,490);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10725,3511,363);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10726,3511,457);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10727,3512,381);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10728,3512,363);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10729,3513,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10730,3513,344);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10731,3513,381);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10732,3513,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10733,3513,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10734,3514,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10735,3514,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10736,3514,384);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10737,3514,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10738,3514,420);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10739,3515,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10740,3515,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10741,3515,384);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10742,3515,354);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10743,3515,420);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10744,3516,401);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10745,3516,433);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10746,3517,401);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10747,3517,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10748,3518,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10749,3518,459);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10750,3518,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10751,3519,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10752,3519,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10753,3519,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10754,3519,334);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10755,3519,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10756,3519,336);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10757,3519,420);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10758,3519,517);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10759,3520,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10760,3520,367);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10761,3521,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10762,3521,381);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10763,3521,490);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10764,3521,409);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10765,3522,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10766,3522,367);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10767,3522,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10768,3522,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10769,3522,326);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10770,3523,408);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10771,3523,381);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10772,3523,335);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10773,3524,362);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10774,3524,332);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10775,3524,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10776,3524,459);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10777,3525,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10778,3525,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10779,3525,356);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10780,3525,465);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10781,3526,334);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10782,3526,538);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10783,3526,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10784,3526,323);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10785,3527,472);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10786,3527,521);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10787,3528,472);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10788,3528,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10789,3528,521);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10790,3529,477);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10791,3529,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10792,3529,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10793,3530,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10794,3530,477);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10795,3530,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10796,3530,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10797,3531,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10798,3531,382);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10799,3531,477);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10800,3531,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10801,3531,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10802,3532,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10803,3532,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10804,3532,477);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10805,3532,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10806,3532,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10807,3533,356);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10808,3533,477);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10809,3533,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10810,3533,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10811,3533,328);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10812,3534,468);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10813,3534,477);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10814,3534,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10815,3534,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10816,3534,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10817,3534,336);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10818,3535,477);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10819,3535,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10820,3535,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10821,3535,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10822,3535,336);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10823,3535,366);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10824,3535,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10825,3535,539);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10826,3536,540);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10827,3536,477);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10828,3536,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10829,3536,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10830,3536,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10831,3536,323);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10832,3536,469);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10833,3537,477);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10834,3537,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10835,3537,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10836,3537,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10837,3537,490);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10838,3537,445);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10839,3538,477);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10840,3538,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10841,3538,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10842,3538,345);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10843,3539,349);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10844,3540,349);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10845,3540,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10846,3541,332);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10847,3541,349);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10848,3541,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10849,3542,510);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10850,3542,337);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10851,3543,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10852,3543,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10853,3543,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10854,3543,439);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10855,3544,454);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10856,3545,454);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10857,3545,504);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10858,3545,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10859,3545,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10860,3546,541);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10861,3546,454);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10862,3547,541);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10863,3547,382);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10864,3548,450);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10865,3549,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10866,3549,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10867,3550,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10868,3550,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10869,3550,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10870,3551,323);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10871,3551,382);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10872,3551,450);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10873,3552,367);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10874,3552,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10875,3553,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10876,3554,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10877,3554,386);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10878,3554,415);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10879,3554,381);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10880,3555,436);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10881,3555,381);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10882,3555,518);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10883,3555,409);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10884,3556,381);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10885,3556,476);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10886,3557,381);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10887,3557,374);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10888,3557,389);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10889,3558,381);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10890,3558,516);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10891,3559,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10892,3559,459);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10893,3560,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10894,3560,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10895,3561,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10896,3561,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10897,3561,364);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10898,3561,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10899,3561,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10900,3561,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10901,3562,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10902,3562,364);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10903,3562,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10904,3562,336);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10905,3563,326);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10906,3563,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10907,3563,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10908,3564,486);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10909,3564,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10910,3564,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10911,3564,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10912,3565,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10913,3565,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10914,3565,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10915,3566,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10916,3566,337);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10917,3566,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10918,3566,438);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10919,3566,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10920,3566,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10921,3567,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10922,3567,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10923,3567,469);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10924,3568,362);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10925,3568,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10926,3568,469);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10927,3569,343);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10928,3569,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10929,3570,343);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10930,3570,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10931,3570,469);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10932,3571,343);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10933,3571,520);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10934,3571,417);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10935,3572,343);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10936,3572,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10937,3572,336);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10938,3572,366);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10939,3572,539);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10940,3573,343);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10941,3573,384);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10942,3573,433);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10943,3574,343);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10944,3574,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10945,3574,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10946,3574,351);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10947,3574,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10948,3575,343);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10949,3575,531);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10950,3576,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10951,3576,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10952,3576,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10953,3576,343);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10954,3576,418);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10955,3577,343);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10956,3577,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10957,3577,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10958,3577,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10959,3577,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10960,3577,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10961,3578,343);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10962,3578,351);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10963,3578,467);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10964,3578,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10965,3579,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10966,3579,492);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10967,3579,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10968,3579,351);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10969,3580,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10970,3580,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10971,3580,492);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10972,3580,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10973,3580,351);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10974,3581,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10975,3581,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10976,3581,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10977,3582,435);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10978,3582,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10979,3582,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10980,3582,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10981,3583,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10982,3583,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10983,3583,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10984,3584,362);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10985,3584,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10986,3585,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10987,3585,405);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10988,3586,454);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10989,3586,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10990,3586,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10991,3587,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10992,3587,364);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10993,3587,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10994,3587,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10995,3588,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10996,3588,417);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10997,3589,344);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10998,3589,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
10999,3589,345);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11000,3590,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11001,3590,350);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11002,3590,469);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11003,3590,344);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11004,3591,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11005,3591,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11006,3591,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11007,3591,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11008,3591,421);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11009,3592,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11010,3592,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11011,3592,454);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11012,3592,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11013,3593,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11014,3593,423);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11015,3593,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11016,3593,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11017,3593,364);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11018,3593,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11019,3593,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11020,3594,344);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11021,3594,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11022,3594,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11023,3594,357);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11024,3595,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11025,3595,336);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11026,3595,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11027,3595,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11028,3596,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11029,3596,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11030,3596,334);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11031,3596,538);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11032,3597,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11033,3597,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11034,3597,349);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11035,3598,341);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11036,3598,328);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11037,3599,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11038,3599,438);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11039,3599,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11040,3600,542);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11041,3600,390);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11042,3601,340);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11043,3601,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11044,3602,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11045,3602,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11046,3602,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11047,3602,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11048,3602,350);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11049,3602,485);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11050,3602,461);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11051,3603,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11052,3603,415);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11053,3603,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11054,3603,487);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11055,3603,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11056,3603,485);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11057,3604,464);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11058,3605,487);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11059,3606,487);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11060,3606,405);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11061,3607,498);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11062,3607,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11063,3608,390);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11064,3608,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11065,3608,437);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11066,3608,496);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11067,3608,543);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11068,3609,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11069,3609,414);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11070,3610,427);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11071,3610,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11072,3610,399);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11073,3610,544);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11074,3611,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11075,3611,471);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11076,3611,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11077,3611,405);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11078,3612,446);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11079,3612,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11080,3613,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11081,3613,401);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11082,3613,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11083,3614,478);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11084,3614,335);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11085,3615,478);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11086,3615,334);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11087,3615,335);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11088,3616,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11089,3616,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11090,3616,478);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11091,3616,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11092,3616,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11093,3616,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11094,3616,335);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11095,3616,461);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11096,3617,478);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11097,3617,471);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11098,3617,335);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11099,3617,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11100,3617,405);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11101,3618,471);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11102,3618,507);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11103,3618,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11104,3618,405);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11105,3619,471);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11106,3619,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11107,3619,405);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11108,3620,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11109,3620,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11110,3620,405);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11111,3621,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11112,3621,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11113,3621,405);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11114,3621,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11115,3622,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11116,3622,366);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11117,3622,405);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11118,3622,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11119,3623,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11120,3623,366);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11121,3623,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11122,3623,405);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11123,3624,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11124,3624,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11125,3624,357);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11126,3625,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11127,3625,433);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11128,3626,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11129,3626,350);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11130,3626,433);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11131,3627,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11132,3627,433);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11133,3627,519);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11134,3628,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11135,3628,337);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11136,3628,447);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11137,3628,433);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11138,3629,386);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11139,3629,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11140,3630,386);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11141,3630,328);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11142,3631,386);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11143,3631,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11144,3631,369);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11145,3632,386);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11146,3632,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11147,3633,386);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11148,3633,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11149,3633,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11150,3633,388);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11151,3634,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11152,3634,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11153,3634,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11154,3635,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11155,3635,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11156,3635,440);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11157,3635,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11158,3636,323);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11159,3636,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11160,3636,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11161,3636,545);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11162,3637,386);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11163,3637,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11164,3637,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11165,3637,388);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11166,3638,386);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11167,3638,364);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11168,3638,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11169,3638,388);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11170,3638,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11171,3639,460);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11172,3640,382);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11173,3640,460);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11174,3641,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11175,3641,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11176,3641,337);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11177,3641,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11178,3642,337);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11179,3642,473);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11180,3642,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11181,3643,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11182,3643,469);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11183,3643,420);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11184,3643,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11185,3644,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11186,3644,384);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11187,3645,503);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11188,3645,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11189,3645,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11190,3645,374);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11191,3646,366);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11192,3646,503);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11193,3646,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11194,3646,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11195,3646,374);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11196,3647,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11197,3647,363);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11198,3648,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11199,3648,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11200,3648,490);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11201,3649,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11202,3649,360);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11203,3649,324);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11204,3649,399);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11205,3649,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11206,3650,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11207,3650,386);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11208,3650,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11209,3650,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11210,3650,388);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11211,3650,350);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11212,3650,490);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11213,3650,370);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11214,3651,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11215,3651,386);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11216,3651,404);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11217,3651,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11218,3651,388);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11219,3651,350);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11220,3651,490);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11221,3651,370);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11222,3652,404);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11223,3652,476);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11224,3653,337);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11225,3653,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11226,3653,357);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11227,3654,516);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11228,3654,472);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11229,3655,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11230,3655,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11231,3655,516);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11232,3655,455);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11233,3656,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11234,3656,398);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11235,3656,390);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11236,3657,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11237,3657,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11238,3657,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11239,3658,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11240,3658,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11241,3658,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11242,3658,351);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11243,3658,374);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11244,3659,332);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11245,3659,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11246,3659,411);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11247,3659,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11248,3659,374);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11249,3660,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11250,3660,470);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11251,3660,352);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11252,3660,374);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11253,3661,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11254,3661,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11255,3661,374);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11256,3662,435);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11257,3662,413);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11258,3662,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11259,3663,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11260,3663,413);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11261,3663,418);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11262,3663,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11263,3664,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11264,3664,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11265,3664,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11266,3665,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11267,3665,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11268,3665,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11269,3665,362);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11270,3666,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11271,3666,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11272,3666,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11273,3666,376);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11274,3666,377);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11275,3667,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11276,3667,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11277,3667,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11278,3667,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11279,3667,367);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11280,3668,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11281,3668,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11282,3669,482);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11283,3670,482);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11284,3670,417);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11285,3671,482);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11286,3671,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11287,3671,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11288,3672,436);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11289,3672,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11290,3672,479);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11291,3673,436);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11292,3673,355);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11293,3673,488);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11294,3674,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11295,3674,482);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11296,3674,336);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11297,3675,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11298,3675,482);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11299,3675,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11300,3675,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11301,3676,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11302,3676,482);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11303,3676,367);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11304,3677,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11305,3677,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11306,3677,337);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11307,3677,482);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11308,3677,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11309,3677,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11310,3678,356);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11311,3678,437);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11312,3679,474);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11313,3680,469);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11314,3680,474);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11315,3681,469);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11316,3681,474);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11317,3681,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11318,3682,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11319,3682,378);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11320,3682,469);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11321,3682,474);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11322,3683,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11323,3683,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11324,3683,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11325,3683,378);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11326,3683,326);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11327,3684,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11328,3684,469);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11329,3685,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11330,3685,469);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11331,3685,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11332,3686,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11333,3686,469);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11334,3687,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11335,3687,469);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11336,3687,488);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11337,3688,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11338,3688,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11339,3688,488);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11340,3689,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11341,3689,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11342,3689,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11343,3689,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11344,3689,461);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11345,3690,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11346,3690,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11347,3690,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11348,3690,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11349,3690,399);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11350,3690,461);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11351,3691,542);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11352,3691,493);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11353,3691,390);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11354,3692,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11355,3692,460);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11356,3692,444);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11357,3693,482);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11358,3693,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11359,3693,460);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11360,3694,348);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11361,3694,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11362,3694,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11363,3695,348);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11364,3695,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11365,3696,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11366,3696,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11367,3697,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11368,3697,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11369,3697,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11370,3697,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11371,3697,334);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11372,3697,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11373,3697,336);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11374,3697,517);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11375,3698,446);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11376,3698,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11377,3699,349);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11378,3699,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11379,3699,352);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11380,3699,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11381,3700,352);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11382,3700,334);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11383,3701,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11384,3701,352);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11385,3701,361);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11386,3702,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11387,3702,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11388,3702,352);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11389,3702,443);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11390,3703,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11391,3703,352);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11392,3703,433);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11393,3704,386);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11394,3704,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11395,3704,388);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11396,3705,386);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11397,3705,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11398,3705,388);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11399,3705,419);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11400,3706,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11401,3706,386);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11402,3706,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11403,3706,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11404,3706,388);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11405,3706,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11406,3707,386);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11407,3707,448);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11408,3707,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11409,3707,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11410,3707,388);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11411,3707,444);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11412,3708,448);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11413,3708,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11414,3708,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11415,3708,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11416,3708,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11417,3708,444);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11418,3709,504);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11419,3709,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11420,3709,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11421,3710,504);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11422,3710,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11423,3710,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11424,3710,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11425,3711,504);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11426,3711,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11427,3711,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11428,3711,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11429,3711,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11430,3712,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11431,3712,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11432,3712,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11433,3713,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11434,3713,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11435,3713,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11436,3714,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11437,3714,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11438,3714,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11439,3715,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11440,3715,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11441,3715,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11442,3715,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11443,3716,356);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11444,3716,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11445,3716,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11446,3716,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11447,3717,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11448,3717,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11449,3717,356);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11450,3718,356);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11451,3718,336);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11452,3718,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11453,3719,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11454,3719,507);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11455,3720,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11456,3720,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11457,3720,348);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11458,3720,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11459,3721,467);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11460,3721,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11461,3722,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11462,3722,467);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11463,3723,347);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11464,3723,467);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11465,3724,328);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11466,3724,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11467,3725,495);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11468,3725,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11469,3726,451);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11470,3726,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11471,3726,384);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11472,3726,405);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11473,3726,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11474,3727,344);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11475,3727,356);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11476,3727,357);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11477,3727,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11478,3728,362);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11479,3728,479);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11480,3728,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11481,3729,373);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11482,3729,362);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11483,3729,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11484,3729,374);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11485,3729,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11486,3730,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11487,3730,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11488,3730,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11489,3730,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11490,3730,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11491,3731,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11492,3731,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11493,3731,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11494,3731,421);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11495,3732,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11496,3732,378);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11497,3732,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11498,3733,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11499,3733,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11500,3733,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11501,3733,414);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11502,3733,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11503,3734,413);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11504,3734,337);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11505,3734,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11506,3735,348);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11507,3735,413);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11508,3735,450);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11509,3735,434);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11510,3736,413);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11511,3736,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11512,3736,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11513,3736,469);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11514,3737,413);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11515,3737,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11516,3737,384);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11517,3738,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11518,3738,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11519,3738,413);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11520,3739,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11521,3739,413);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11522,3739,490);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11523,3740,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11524,3740,462);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11525,3740,490);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11526,3741,462);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11527,3741,349);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11528,3741,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11529,3742,462);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11530,3742,500);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11531,3742,458);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11532,3742,459);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11533,3742,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11534,3743,534);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11535,3743,462);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11536,3744,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11537,3744,349);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11538,3745,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11539,3745,349);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11540,3745,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11541,3746,435);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11542,3746,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11543,3746,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11544,3747,471);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11545,3747,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11546,3747,420);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11547,3747,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11548,3747,405);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11549,3748,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11550,3748,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11551,3748,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11552,3749,373);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11553,3749,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11554,3749,374);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11555,3750,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11556,3751,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11557,3751,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11558,3752,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11559,3752,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11560,3752,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11561,3753,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11562,3753,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11563,3753,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11564,3753,357);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11565,3754,546);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11566,3754,434);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11567,3754,366);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11568,3755,413);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11569,3755,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11570,3755,415);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11571,3756,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11572,3756,415);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11573,3757,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11574,3757,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11575,3757,351);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11576,3758,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11577,3758,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11578,3758,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11579,3758,425);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11580,3758,351);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11581,3758,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11582,3759,383);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11583,3759,547);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11584,3759,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11585,3760,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11586,3760,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11587,3761,356);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11588,3761,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11589,3761,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11590,3762,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11591,3762,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11592,3763,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11593,3764,330);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11594,3764,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11595,3764,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11596,3764,334);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11597,3765,330);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11598,3765,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11599,3765,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11600,3765,334);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11601,3765,496);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11602,3766,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11603,3766,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11604,3766,336);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11605,3766,496);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11606,3767,450);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11607,3767,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11608,3767,496);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11609,3768,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11610,3768,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11611,3768,494);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11612,3768,438);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11613,3768,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11614,3768,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11615,3768,469);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11616,3769,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11617,3769,324);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11618,3770,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11619,3770,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11620,3770,324);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11621,3771,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11622,3771,363);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11623,3772,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11624,3772,495);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11625,3773,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11626,3773,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11627,3773,336);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11628,3773,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11629,3774,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11630,3774,459);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11631,3775,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11632,3775,360);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11633,3775,467);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11634,3775,374);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11635,3776,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11636,3776,367);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11637,3777,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11638,3777,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11639,3777,467);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11640,3777,384);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11641,3778,435);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11642,3778,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11643,3778,409);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11644,3779,449);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11645,3779,426);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11646,3780,435);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11647,3780,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11648,3780,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11649,3780,409);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11650,3781,435);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11651,3781,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11652,3781,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11653,3781,409);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11654,3781,354);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11655,3782,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11656,3782,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11657,3782,351);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11658,3783,355);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11659,3783,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11660,3783,351);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11661,3784,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11662,3784,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11663,3784,416);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11664,3784,399);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11665,3784,484);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11666,3785,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11667,3785,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11668,3785,355);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11669,3785,416);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11670,3785,399);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11671,3785,484);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11672,3786,355);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11673,3787,355);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11674,3787,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11675,3787,364);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11676,3787,351);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11677,3788,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11678,3788,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11679,3788,364);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11680,3788,351);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11681,3789,355);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11682,3789,399);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11683,3789,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11684,3790,355);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11685,3790,413);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11686,3790,411);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11687,3791,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11688,3791,411);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11689,3791,460);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11690,3792,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11691,3792,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11692,3792,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11693,3792,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11694,3792,460);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11695,3793,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11696,3793,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11697,3793,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11698,3793,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11699,3793,490);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11700,3794,434);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11701,3794,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11702,3794,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11703,3795,364);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11704,3795,319);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11705,3796,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11706,3796,364);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11707,3796,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11708,3796,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11709,3796,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11710,3796,319);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11711,3796,474);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11712,3797,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11713,3797,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11714,3797,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11715,3797,474);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11716,3798,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11717,3798,370);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11718,3798,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11719,3798,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11720,3799,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11721,3799,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11722,3800,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11723,3800,490);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11724,3800,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11725,3801,399);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11726,3801,490);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11727,3802,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11728,3802,490);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11729,3803,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11730,3803,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11731,3803,490);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11732,3803,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11733,3804,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11734,3804,383);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11735,3804,450);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11736,3804,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11737,3805,383);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11738,3805,374);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11739,3805,389);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11740,3806,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11741,3806,383);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11742,3806,364);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11743,3806,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11744,3806,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11745,3807,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11746,3807,383);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11747,3807,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11748,3807,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11749,3808,383);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11750,3808,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11751,3808,400);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11752,3808,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11753,3808,336);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11754,3809,344);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11755,3809,383);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11756,3809,332);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11757,3809,450);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11758,3810,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11759,3810,344);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11760,3810,418);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11761,3810,332);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11762,3810,457);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11763,3811,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11764,3811,351);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11765,3811,384);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11766,3811,457);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11767,3812,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11768,3812,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11769,3812,469);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11770,3812,457);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11771,3813,546);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11772,3813,469);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11773,3813,457);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11774,3814,424);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11775,3814,440);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11776,3814,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11777,3815,401);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11778,3815,440);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11779,3816,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11780,3816,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11781,3816,440);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11782,3817,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11783,3817,467);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11784,3817,384);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11785,3818,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11786,3818,431);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11787,3818,467);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11788,3819,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11789,3819,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11790,3820,415);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11791,3820,397);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11792,3821,415);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11793,3821,397);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11794,3821,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11795,3822,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11796,3822,350);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11797,3822,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11798,3822,357);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11799,3823,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11800,3823,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11801,3823,357);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11802,3823,389);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11803,3824,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11804,3824,418);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11805,3824,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11806,3824,357);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11807,3825,516);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11808,3825,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11809,3825,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11810,3826,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11811,3826,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11812,3826,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11813,3826,516);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11814,3826,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11815,3827,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11816,3827,412);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11817,3827,516);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11818,3827,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11819,3828,412);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11820,3828,374);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11821,3828,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11822,3829,443);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11823,3830,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11824,3830,443);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11825,3831,477);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11826,3831,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11827,3831,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11828,3831,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11829,3832,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11830,3832,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11831,3832,335);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11832,3833,442);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11833,3833,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11834,3833,443);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11835,3833,444);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11836,3834,443);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11837,3834,334);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11838,3835,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11839,3835,443);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11840,3835,334);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11841,3836,404);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11842,3836,523);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11843,3836,450);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11844,3836,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11845,3836,360);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11846,3836,357);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11847,3837,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11848,3837,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11849,3837,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11850,3837,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11851,3838,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11852,3838,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11853,3838,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11854,3839,405);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11855,3839,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11856,3840,405);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11857,3840,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11858,3841,470);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11859,3841,352);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11860,3841,405);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11861,3841,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11862,3842,326);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11863,3842,405);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11864,3843,341);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11865,3843,405);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11866,3844,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11867,3844,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11868,3844,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11869,3844,405);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11870,3845,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11871,3845,390);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11872,3845,405);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11873,3845,354);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11874,3846,396);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11875,3846,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11876,3846,390);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11877,3846,354);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11878,3847,509);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11879,3847,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11880,3847,396);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11881,3848,433);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11882,3848,444);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11883,3848,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11884,3849,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11885,3849,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11886,3849,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11887,3849,481);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11888,3849,324);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11889,3850,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11890,3850,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11891,3850,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11892,3850,481);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11893,3850,496);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11894,3851,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11895,3851,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11896,3851,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11897,3851,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11898,3851,481);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11899,3851,350);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11900,3852,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11901,3852,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11902,3852,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11903,3852,481);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11904,3852,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11905,3852,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11906,3852,391);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11907,3853,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11908,3853,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11909,3853,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11910,3853,471);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11911,3853,481);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11912,3853,345);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11913,3853,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11914,3853,405);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11915,3854,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11916,3854,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11917,3854,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11918,3854,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11919,3854,431);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11920,3854,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11921,3854,481);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11922,3855,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11923,3855,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11924,3855,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11925,3855,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11926,3855,481);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11927,3856,340);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11928,3856,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11929,3856,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11930,3856,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11931,3856,481);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11932,3857,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11933,3857,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11934,3857,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11935,3857,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11936,3857,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11937,3857,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11938,3858,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11939,3858,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11940,3858,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11941,3858,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11942,3858,390);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11943,3859,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11944,3859,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11945,3859,419);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11946,3860,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11947,3860,514);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11948,3860,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11949,3861,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11950,3861,352);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11951,3861,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11952,3862,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11953,3862,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11954,3862,457);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11955,3863,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11956,3863,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11957,3863,374);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11958,3864,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11959,3864,367);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11960,3864,426);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11961,3865,369);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11962,3865,420);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11963,3866,404);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11964,3866,420);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11965,3867,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11966,3867,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11967,3867,363);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11968,3867,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11969,3867,420);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11970,3868,477);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11971,3868,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11972,3868,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11973,3868,376);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11974,3868,420);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11975,3868,377);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11976,3869,376);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11977,3869,420);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11978,3869,377);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11979,3870,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11980,3870,376);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11981,3870,377);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11982,3871,376);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11983,3871,465);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11984,3871,377);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11985,3872,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11986,3872,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11987,3872,465);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11988,3872,361);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11989,3873,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11990,3873,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11991,3873,361);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11992,3874,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11993,3874,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11994,3874,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11995,3874,523);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11996,3874,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11997,3874,360);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11998,3874,453);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
11999,3875,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12000,3875,371);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12001,3875,425);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12002,3875,426);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12003,3876,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12004,3876,341);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12005,3876,371);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12006,3876,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12007,3877,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12008,3877,371);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12009,3877,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12010,3877,335);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12011,3878,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12012,3878,323);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12013,3878,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12014,3878,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12015,3878,371);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12016,3878,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12017,3878,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12018,3878,511);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12019,3878,512);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12020,3879,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12021,3879,503);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12022,3879,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12023,3879,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12024,3879,371);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12025,3879,374);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12026,3880,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12027,3880,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12028,3880,371);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12029,3880,487);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12030,3880,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12031,3881,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12032,3881,487);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12033,3881,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12034,3881,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12035,3882,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12036,3882,343);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12037,3882,487);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12038,3882,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12039,3883,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12040,3883,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12041,3883,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12042,3883,351);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12043,3884,337);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12044,3885,337);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12045,3885,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12046,3886,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12047,3886,361);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12048,3886,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12049,3887,353);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12050,3887,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12051,3887,354);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12052,3888,353);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12053,3888,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12054,3888,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12055,3888,354);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12056,3888,469);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12057,3889,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12058,3889,332);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12059,3889,411);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12060,3889,354);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12061,3890,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12062,3890,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12063,3890,354);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12064,3891,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12065,3891,431);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12066,3891,354);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12067,3892,347);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12068,3892,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12069,3892,389);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12070,3893,347);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12071,3893,389);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12072,3894,436);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12073,3894,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12074,3894,347);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12075,3894,411);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12076,3894,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12077,3895,347);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12078,3895,513);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12079,3896,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12080,3896,347);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12081,3896,406);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12082,3896,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12083,3896,469);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12084,3897,347);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12085,3897,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12086,3898,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12087,3898,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12088,3898,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12089,3898,404);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12090,3898,347);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12091,3898,439);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12092,3898,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12093,3899,408);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12094,3899,345);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12095,3899,439);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12096,3900,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12097,3900,367);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12098,3900,345);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12099,3900,439);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12100,3901,383);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12101,3901,345);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12102,3902,527);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12103,3902,345);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12104,3903,477);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12105,3903,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12106,3903,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12107,3903,411);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12108,3903,345);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12109,3904,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12110,3904,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12111,3904,384);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12112,3904,345);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12113,3905,431);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12114,3905,324);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12115,3905,345);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12116,3906,514);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12117,3906,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12118,3906,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12119,3906,345);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12120,3907,383);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12121,3907,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12122,3907,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12123,3907,345);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12124,3908,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12125,3908,345);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12126,3909,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12127,3909,345);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12128,3910,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12129,3910,345);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12130,3911,335);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12131,3911,345);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12132,3912,444);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12133,3912,345);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12134,3913,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12135,3913,378);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12136,3913,444);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12137,3913,345);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12138,3914,355);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12139,3914,444);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12140,3914,488);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12141,3915,483);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12142,3915,443);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12143,3915,444);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12144,3915,442);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12145,3916,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12146,3916,326);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12147,3916,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12148,3916,382);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12149,3916,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12150,3916,444);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12151,3917,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12152,3917,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12153,3917,350);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12154,3917,444);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12155,3917,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12156,3918,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12157,3918,367);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12158,3918,444);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12159,3918,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12160,3918,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12161,3918,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12162,3918,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12163,3919,433);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12164,3919,444);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12165,3920,446);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12166,3920,440);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12167,3920,433);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12168,3921,446);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12169,3921,440);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12170,3921,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12171,3922,446);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12172,3922,440);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12173,3923,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12174,3923,446);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12175,3924,332);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12176,3924,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12177,3924,319);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12178,3925,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12179,3925,332);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12180,3925,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12181,3926,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12182,3926,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12183,3926,332);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12184,3927,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12185,3927,427);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12186,3927,332);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12187,3927,414);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12188,3928,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12189,3928,477);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12190,3928,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12191,3928,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12192,3928,332);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12193,3928,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12194,3929,503);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12195,3929,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12196,3929,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12197,3929,332);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12198,3929,337);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12199,3929,405);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12200,3930,386);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12201,3930,366);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12202,3930,332);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12203,3930,354);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12204,3930,420);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12205,3931,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12206,3931,332);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12207,3931,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12208,3931,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12209,3932,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12210,3932,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12211,3932,378);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12212,3932,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12213,3932,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12214,3933,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12215,3933,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12216,3933,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12217,3933,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12218,3934,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12219,3934,374);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12220,3935,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12221,3935,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12222,3935,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12223,3935,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12224,3935,405);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12225,3935,458);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12226,3935,459);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12227,3935,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12228,3936,383);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12229,3936,415);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12230,3936,357);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12231,3936,458);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12232,3936,459);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12233,3936,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12234,3937,415);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12235,3937,357);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12236,3937,458);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12237,3937,459);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12238,3937,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12239,3938,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12240,3938,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12241,3938,472);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12242,3938,458);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12243,3938,459);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12244,3938,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12245,3939,548);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12246,3939,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12247,3939,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12248,3939,324);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12249,3939,384);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12250,3940,548);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12251,3940,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12252,3940,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12253,3940,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12254,3940,324);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12255,3940,433);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12256,3940,519);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12257,3941,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12258,3941,548);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12259,3941,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12260,3941,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12261,3941,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12262,3941,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12263,3941,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12264,3941,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12265,3941,324);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12266,3942,548);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12267,3942,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12268,3942,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12269,3942,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12270,3942,324);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12271,3942,384);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12272,3943,548);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12273,3943,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12274,3943,473);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12275,3943,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12276,3943,324);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12277,3944,394);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12278,3944,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12279,3945,394);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12280,3945,449);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12281,3945,367);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12282,3945,390);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12283,3946,394);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12284,3946,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12285,3946,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12286,3947,394);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12287,3947,351);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12288,3947,467);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12289,3947,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12290,3948,394);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12291,3948,349);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12292,3948,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12293,3949,394);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12294,3949,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12295,3949,371);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12296,3949,390);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12297,3950,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12298,3950,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12299,3950,394);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12300,3950,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12301,3951,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12302,3951,434);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12303,3951,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12304,3952,372);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12305,3952,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12306,3952,468);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12307,3953,372);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12308,3953,465);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12309,3953,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12310,3953,468);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12311,3954,436);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12312,3954,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12313,3954,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12314,3955,436);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12315,3955,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12316,3955,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12317,3956,436);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12318,3956,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12319,3956,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12320,3957,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12321,3957,436);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12322,3957,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12323,3957,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12324,3958,436);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12325,3958,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12326,3958,411);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12327,3958,465);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12328,3959,435);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12329,3959,419);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12330,3960,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12331,3960,418);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12332,3960,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12333,3960,419);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12334,3961,402);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12335,3961,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12336,3961,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12337,3962,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12338,3962,402);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12339,3962,492);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12340,3962,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12341,3962,351);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12342,3963,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12343,3963,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12344,3963,492);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12345,3963,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12346,3963,351);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12347,3964,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12348,3965,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12349,3965,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12350,3965,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12351,3965,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12352,3966,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12353,3966,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12354,3966,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12355,3966,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12356,3967,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12357,3967,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12358,3967,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12359,3967,465);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12360,3968,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12361,3968,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12362,3968,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12363,3969,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12364,3969,480);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12365,3970,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12366,3970,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12367,3970,480);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12368,3971,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12369,3971,378);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12370,3971,480);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12371,3971,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12372,3972,480);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12373,3972,363);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12374,3973,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12375,3973,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12376,3973,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12377,3973,431);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12378,3973,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12379,3974,348);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12380,3974,422);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12381,3975,422);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12382,3975,326);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12383,3976,422);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12384,3976,457);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12385,3977,422);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12386,3977,357);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12387,3977,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12388,3978,422);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12389,3978,418);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12390,3978,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12391,3978,357);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12392,3979,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12393,3979,422);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12394,3979,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12395,3979,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12396,3980,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12397,3980,422);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12398,3980,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12399,3980,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12400,3980,374);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12401,3981,435);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12402,3981,422);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12403,3982,435);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12404,3982,422);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12405,3982,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12406,3983,422);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12407,3983,507);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12408,3984,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12409,3984,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12410,3984,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12411,3984,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12412,3984,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12413,3984,457);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12414,3985,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12415,3985,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12416,3985,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12417,3985,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12418,3985,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12419,3986,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12420,3986,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12421,3986,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12422,3986,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12423,3986,398);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12424,3986,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12425,3987,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12426,3987,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12427,3987,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12428,3987,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12429,3988,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12430,3988,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12431,3988,347);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12432,3988,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12433,3989,347);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12434,3989,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12435,3989,336);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12436,3989,384);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12437,3989,522);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12438,3990,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12439,3990,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12440,3990,336);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12441,3990,384);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12442,3990,522);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12443,3991,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12444,3991,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12445,3991,336);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12446,3991,384);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12447,3991,522);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12448,3991,457);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12449,3992,332);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12450,3992,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12451,3992,336);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12452,3992,384);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12453,3992,522);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12454,3993,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12455,3993,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12456,3993,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12457,3994,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12458,3994,356);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12459,3994,407);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12460,3995,407);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12461,3995,469);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12462,3995,474);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12463,3996,407);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12464,3996,459);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12465,3997,407);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12466,3997,350);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12467,3997,490);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12468,3997,370);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12469,3998,446);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12470,3998,369);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12471,3998,407);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12472,3999,340);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12473,4000,340);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12474,4000,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12475,4001,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12476,4001,340);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12477,4001,350);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12478,4002,340);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12479,4002,471);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12480,4002,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12481,4002,405);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12482,4003,340);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12483,4003,408);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12484,4004,340);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12485,4004,409);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12486,4005,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12487,4005,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12488,4005,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12489,4005,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12490,4005,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12491,4005,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12492,4006,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12493,4006,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12494,4006,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12495,4006,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12496,4006,465);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12497,4006,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12498,4007,527);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12499,4007,446);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12500,4007,465);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12501,4008,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12502,4008,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12503,4008,465);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12504,4008,320);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12505,4009,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12506,4009,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12507,4009,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12508,4009,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12509,4009,465);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12510,4010,446);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12511,4010,465);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12512,4011,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12513,4011,465);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12514,4011,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12515,4012,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12516,4012,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12517,4012,465);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12518,4013,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12519,4013,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12520,4013,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12521,4014,357);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12522,4014,459);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12523,4015,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12524,4015,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12525,4015,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12526,4015,350);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12527,4016,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12528,4016,459);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12529,4017,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12530,4017,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12531,4017,459);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12532,4018,356);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12533,4018,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12534,4018,459);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12535,4019,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12536,4019,326);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12537,4019,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12538,4019,466);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12539,4019,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12540,4019,334);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12541,4019,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12542,4019,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12543,4020,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12544,4020,326);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12545,4020,370);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12546,4020,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12547,4020,466);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12548,4020,334);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12549,4020,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12550,4021,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12551,4021,370);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12552,4021,418);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12553,4021,357);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12554,4022,370);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12555,4022,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12556,4022,433);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12557,4022,519);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12558,4023,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12559,4023,503);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12560,4023,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12561,4023,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12562,4023,374);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12563,4023,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12564,4023,491);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12565,4024,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12566,4024,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12567,4024,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12568,4024,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12569,4024,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12570,4025,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12571,4025,383);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12572,4025,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12573,4025,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12574,4025,364);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12575,4026,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12576,4026,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12577,4026,364);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12578,4026,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12579,4026,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12580,4027,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12581,4027,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12582,4027,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12583,4027,364);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12584,4027,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12585,4027,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12586,4028,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12587,4028,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12588,4028,341);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12589,4028,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12590,4028,364);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12591,4029,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12592,4029,483);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12593,4030,348);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12594,4030,483);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12595,4030,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12596,4030,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12597,4030,336);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12598,4031,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12599,4031,423);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12600,4031,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12601,4032,423);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12602,4032,472);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12603,4032,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12604,4032,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12605,4033,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12606,4033,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12607,4033,423);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12608,4033,350);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12609,4033,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12610,4034,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12611,4034,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12612,4034,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12613,4034,362);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12614,4035,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12615,4035,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12616,4035,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12617,4035,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12618,4035,361);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12619,4036,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12620,4036,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12621,4036,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12622,4036,351);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12623,4036,350);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12624,4036,499);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12625,4037,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12626,4037,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12627,4037,363);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12628,4037,334);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12629,4037,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12630,4037,357);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12631,4038,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12632,4038,523);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12633,4038,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12634,4038,360);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12635,4039,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12636,4039,337);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12637,4039,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12638,4040,436);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12639,4040,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12640,4040,415);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12641,4041,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12642,4041,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12643,4041,350);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12644,4041,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12645,4042,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12646,4042,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12647,4042,384);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12648,4042,390);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12649,4043,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12650,4043,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12651,4043,384);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12652,4043,390);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12653,4044,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12654,4044,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12655,4044,497);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12656,4044,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12657,4045,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12658,4045,477);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12659,4045,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12660,4045,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12661,4045,497);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12662,4046,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12663,4046,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12664,4046,497);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12665,4047,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12666,4047,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12667,4047,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12668,4047,471);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12669,4047,336);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12670,4047,499);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12671,4047,405);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12672,4048,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12673,4048,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12674,4048,471);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12675,4048,347);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12676,4048,336);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12677,4048,499);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12678,4048,405);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12679,4049,431);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12680,4049,477);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12681,4049,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12682,4049,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12683,4049,324);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12684,4050,344);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12685,4050,477);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12686,4050,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12687,4050,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12688,4050,389);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12689,4051,477);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12690,4051,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12691,4051,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12692,4051,416);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12693,4052,477);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12694,4052,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12695,4052,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12696,4052,424);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12697,4052,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12698,4053,477);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12699,4053,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12700,4053,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12701,4053,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12702,4053,337);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12703,4053,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12704,4053,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12705,4054,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12706,4054,477);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12707,4054,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12708,4054,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12709,4054,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12710,4054,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12711,4055,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12712,4055,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12713,4055,347);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12714,4055,477);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12715,4055,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12716,4055,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12717,4055,390);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12718,4056,477);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12719,4056,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12720,4056,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12721,4056,363);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12722,4057,489);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12723,4057,477);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12724,4057,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12725,4057,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12726,4058,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12727,4058,477);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12728,4058,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12729,4058,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12730,4058,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12731,4059,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12732,4059,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12733,4059,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12734,4060,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12735,4060,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12736,4061,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12737,4061,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12738,4061,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12739,4061,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12740,4062,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12741,4062,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12742,4062,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12743,4062,349);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12744,4062,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12745,4063,337);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12746,4063,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12747,4063,450);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12748,4063,397);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12749,4064,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12750,4064,489);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12751,4064,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12752,4065,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12753,4065,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12754,4065,472);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12755,4065,489);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12756,4066,367);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12757,4066,472);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12758,4066,489);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12759,4066,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12760,4067,435);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12761,4067,367);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12762,4067,409);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12763,4068,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12764,4068,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12765,4068,367);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12766,4069,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12767,4069,456);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12768,4070,464);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12769,4070,416);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12770,4071,464);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12771,4071,324);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12772,4071,374);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12773,4072,418);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12774,4072,464);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12775,4072,357);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12776,4073,464);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12777,4073,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12778,4074,362);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12779,4074,464);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12780,4075,362);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12781,4075,477);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12782,4075,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12783,4075,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12784,4076,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12785,4076,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12786,4076,464);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12787,4076,390);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12788,4077,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12789,4077,332);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12790,4077,464);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12791,4077,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12792,4077,374);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12793,4078,418);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12794,4078,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12795,4078,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12796,4079,527);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12797,4080,527);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12798,4080,440);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12799,4081,361);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12800,4081,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12801,4081,324);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12802,4081,409);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12803,4081,536);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12804,4082,549);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12805,4082,456);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12806,4082,433);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12807,4083,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12808,4083,549);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12809,4083,456);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12810,4083,336);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12811,4083,433);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12812,4084,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12813,4084,389);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12814,4085,364);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12815,4085,450);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12816,4085,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12817,4085,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12818,4085,506);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12819,4086,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12820,4086,324);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12821,4086,384);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12822,4086,444);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12823,4087,506);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12824,4087,444);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12825,4087,345);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12826,4087,374);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12827,4088,540);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12828,4088,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12829,4088,469);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12830,4088,323);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12831,4089,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12832,4089,465);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12833,4089,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12834,4090,483);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12835,4090,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12836,4090,418);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12837,4090,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12838,4091,462);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12839,4091,382);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12840,4091,514);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12841,4092,337);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12842,4092,514);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12843,4092,374);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12844,4093,418);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12845,4093,514);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12846,4093,425);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12847,4093,459);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12848,4094,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12849,4094,514);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12850,4094,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12851,4095,436);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12852,4095,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12853,4095,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12854,4095,514);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12855,4096,386);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12856,4096,514);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12857,4097,413);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12858,4097,514);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12859,4097,483);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12860,4098,473);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12861,4098,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12862,4098,514);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12863,4099,332);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12864,4099,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12865,4099,361);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12866,4099,324);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12867,4099,409);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12868,4099,536);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12869,4100,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12870,4100,361);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12871,4100,324);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12872,4100,409);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12873,4100,536);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12874,4101,361);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12875,4101,324);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12876,4101,472);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12877,4101,409);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12878,4101,536);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12879,4102,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12880,4102,361);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12881,4102,367);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12882,4102,324);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12883,4102,409);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12884,4102,536);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12885,4103,344);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12886,4103,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12887,4103,362);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12888,4103,337);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12889,4104,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12890,4104,344);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12891,4104,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12892,4104,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12893,4104,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12894,4105,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12895,4105,344);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12896,4105,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12897,4105,433);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12898,4105,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12899,4106,343);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12900,4106,386);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12901,4106,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12902,4106,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12903,4106,344);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12904,4106,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12905,4106,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12906,4107,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12907,4107,344);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12908,4107,413);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12909,4107,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12910,4107,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12911,4108,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12912,4108,347);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12913,4108,382);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12914,4108,477);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12915,4108,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12916,4108,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12917,4109,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12918,4109,332);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12919,4109,384);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12920,4110,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12921,4110,411);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12922,4110,465);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12923,4110,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12924,4111,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12925,4111,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12926,4111,411);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12927,4111,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12928,4112,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12929,4112,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12930,4112,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12931,4112,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12932,4113,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12933,4113,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12934,4113,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12935,4113,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12936,4113,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12937,4113,481);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12938,4114,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12939,4114,324);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12940,4114,405);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12941,4115,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12942,4115,464);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12943,4115,411);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12944,4115,469);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12945,4116,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12946,4116,509);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12947,4116,324);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12948,4117,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12949,4117,378);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12950,4117,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12951,4117,433);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12952,4117,519);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12953,4118,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12954,4118,519);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12955,4118,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12956,4118,409);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12957,4118,433);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12958,4119,323);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12959,4119,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12960,4119,467);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12961,4120,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12962,4120,462);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12963,4120,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12964,4120,516);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12965,4120,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12966,4121,454);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12967,4121,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12968,4121,335);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12969,4122,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12970,4122,392);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12971,4123,537);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12972,4123,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12973,4123,469);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12974,4123,444);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12975,4124,503);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12976,4124,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12977,4124,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12978,4124,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12979,4124,396);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12980,4125,386);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12981,4125,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12982,4125,398);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12983,4126,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12984,4126,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12985,4126,438);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12986,4126,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12987,4126,491);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12988,4127,394);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12989,4127,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12990,4127,405);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12991,4128,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12992,4128,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12993,4128,367);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12994,4128,426);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12995,4129,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12996,4129,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12997,4129,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12998,4129,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
12999,4129,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13000,4129,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13001,4130,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13002,4130,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13003,4130,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13004,4130,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13005,4130,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13006,4130,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13007,4131,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13008,4131,469);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13009,4131,474);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13010,4132,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13011,4132,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13012,4132,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13013,4132,336);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13014,4133,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13015,4133,419);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13016,4133,336);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13017,4134,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13018,4134,364);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13019,4134,450);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13020,4134,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13021,4135,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13022,4135,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13023,4135,425);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13024,4135,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13025,4136,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13026,4136,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13027,4136,409);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13028,4137,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13029,4137,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13030,4137,336);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13031,4137,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13032,4138,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13033,4138,373);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13034,4138,366);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13035,4138,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13036,4138,374);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13037,4138,405);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13038,4139,500);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13039,4140,500);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13040,4140,328);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13041,4141,462);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13042,4141,500);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13043,4141,516);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13044,4141,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13045,4142,386);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13046,4142,500);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13047,4142,520);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13048,4143,386);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13049,4143,520);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13050,4143,415);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13051,4144,489);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13052,4144,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13053,4144,363);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13054,4145,489);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13055,4145,408);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13056,4145,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13057,4146,489);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13058,4146,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13059,4146,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13060,4147,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13061,4147,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13062,4147,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13063,4147,378);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13064,4147,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13065,4147,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13066,4148,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13067,4148,423);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13068,4148,469);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13069,4149,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13070,4149,337);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13071,4149,438);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13072,4149,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13073,4149,398);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13074,4150,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13075,4150,398);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13076,4150,490);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13077,4151,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13078,4151,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13079,4151,398);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13080,4151,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13081,4152,330);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13082,4152,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13083,4152,398);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13084,4152,334);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13085,4153,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13086,4153,398);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13087,4154,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13088,4154,373);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13089,4154,451);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13090,4154,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13091,4154,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13092,4154,384);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13093,4154,374);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13094,4155,454);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13095,4155,373);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13096,4155,529);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13097,4155,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13098,4155,374);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13099,4156,373);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13100,4156,349);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13101,4156,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13102,4156,324);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13103,4156,374);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13104,4157,445);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13105,4157,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13106,4157,420);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13107,4158,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13108,4158,445);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13109,4158,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13110,4159,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13111,4159,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13112,4160,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13113,4160,381);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13114,4160,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13115,4161,381);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13116,4161,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13117,4162,344);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13118,4162,415);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13119,4162,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13120,4162,341);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13121,4162,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13122,4162,508);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13123,4162,503);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13124,4163,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13125,4163,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13126,4163,344);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13127,4163,352);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13128,4163,508);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13129,4164,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13130,4164,381);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13131,4165,381);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13132,4165,474);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13133,4166,436);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13134,4166,381);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13135,4166,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13136,4166,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13137,4167,436);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13138,4167,413);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13139,4167,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13140,4167,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13141,4168,436);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13142,4168,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13143,4168,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13144,4168,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13145,4169,381);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13146,4169,439);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13147,4169,501);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13148,4170,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13149,4170,381);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13150,4170,378);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13151,4171,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13152,4171,381);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13153,4171,480);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13154,4172,381);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13155,4172,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13156,4172,374);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13157,4173,468);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13158,4173,381);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13159,4173,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13160,4174,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13161,4174,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13162,4174,490);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13163,4175,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13164,4175,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13165,4175,334);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13166,4176,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13167,4176,334);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13168,4176,457);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13169,4177,355);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13170,4177,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13171,4177,334);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13172,4178,344);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13173,4178,355);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13174,4178,341);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13175,4179,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13176,4179,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13177,4179,384);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13178,4180,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13179,4180,496);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13180,4181,376);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13181,4181,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13182,4181,377);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13183,4182,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13184,4182,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13185,4182,335);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13186,4183,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13187,4183,356);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13188,4183,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13189,4183,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13190,4183,336);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13191,4184,527);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13192,4184,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13193,4185,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13194,4185,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13195,4185,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13196,4186,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13197,4186,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13198,4187,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13199,4187,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13200,4187,348);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13201,4188,352);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13202,4188,469);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13203,4188,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13204,4189,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13205,4189,343);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13206,4189,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13207,4190,343);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13208,4190,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13209,4190,336);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13210,4191,343);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13211,4191,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13212,4191,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13213,4191,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13214,4192,343);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13215,4192,443);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13216,4192,334);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13217,4193,343);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13218,4193,458);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13219,4193,459);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13220,4193,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13221,4194,343);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13222,4194,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13223,4194,360);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13224,4195,343);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13225,4195,462);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13226,4195,516);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13227,4195,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13228,4196,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13229,4196,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13230,4196,343);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13231,4196,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13232,4196,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13233,4196,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13234,4196,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13235,4196,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13236,4197,343);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13237,4197,480);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13238,4197,374);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13239,4198,477);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13240,4198,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13241,4198,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13242,4198,480);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13243,4198,374);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13244,4199,439);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13245,4199,384);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13246,4199,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13247,4200,513);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13248,4200,360);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13249,4200,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13250,4201,498);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13251,4201,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13252,4201,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13253,4202,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13254,4202,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13255,4202,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13256,4202,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13257,4202,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13258,4202,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13259,4203,500);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13260,4203,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13261,4203,458);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13262,4203,459);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13263,4203,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13264,4204,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13265,4204,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13266,4204,345);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13267,4205,364);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13268,4205,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13269,4205,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13270,4205,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13271,4206,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13272,4206,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13273,4206,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13274,4206,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13275,4206,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13276,4206,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13277,4207,364);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13278,4207,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13279,4207,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13280,4207,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13281,4207,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13282,4207,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13283,4207,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13284,4208,369);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13285,4208,335);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13286,4208,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13287,4209,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13288,4209,371);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13289,4209,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13290,4210,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13291,4210,349);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13292,4210,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13293,4211,334);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13294,4211,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13295,4212,460);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13296,4212,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13297,4213,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13298,4213,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13299,4213,373);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13300,4213,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13301,4213,374);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13302,4213,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13303,4214,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13304,4214,351);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13305,4214,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13306,4214,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13307,4215,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13308,4215,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13309,4215,351);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13310,4215,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13311,4216,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13312,4216,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13313,4216,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13314,4216,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13315,4216,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13316,4216,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13317,4216,405);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13318,4216,399);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13319,4217,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13320,4217,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13321,4217,459);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13322,4218,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13323,4218,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13324,4218,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13325,4218,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13326,4218,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13327,4218,319);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13328,4219,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13329,4219,435);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13330,4220,366);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13331,4220,435);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13332,4220,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13333,4221,366);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13334,4221,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13335,4221,409);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13336,4222,366);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13337,4222,463);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13338,4223,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13339,4223,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13340,4223,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13341,4223,350);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13342,4223,336);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13343,4223,499);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13344,4224,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13345,4224,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13346,4224,366);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13347,4224,361);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13348,4225,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13349,4225,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13350,4225,366);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13351,4225,390);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13352,4226,366);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13353,4226,364);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13354,4226,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13355,4226,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13356,4226,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13357,4226,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13358,4227,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13359,4227,366);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13360,4227,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13361,4227,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13362,4228,366);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13363,4228,486);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13364,4228,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13365,4228,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13366,4229,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13367,4229,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13368,4229,367);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13369,4230,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13370,4230,323);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13371,4230,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13372,4230,357);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13373,4230,512);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13374,4231,361);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13375,4231,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13376,4232,432);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13377,4232,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13378,4232,361);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13379,4233,413);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13380,4233,361);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13381,4234,489);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13382,4234,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13383,4235,489);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13384,4235,381);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13385,4235,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13386,4236,489);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13387,4236,413);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13388,4236,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13389,4237,386);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13390,4237,413);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13391,4237,351);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13392,4237,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13393,4238,386);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13394,4238,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13395,4238,351);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13396,4239,413);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13397,4239,364);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13398,4239,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13399,4240,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13400,4240,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13401,4240,413);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13402,4240,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13403,4240,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13404,4241,413);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13405,4241,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13406,4241,324);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13407,4242,413);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13408,4242,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13409,4242,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13410,4242,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13411,4243,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13412,4243,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13413,4243,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13414,4243,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13415,4244,356);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13416,4244,413);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13417,4244,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13418,4244,334);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13419,4244,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13420,4244,357);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13421,4245,408);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13422,4245,413);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13423,4245,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13424,4245,335);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13425,4246,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13426,4246,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13427,4246,413);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13428,4246,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13429,4246,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13430,4246,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13431,4247,355);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13432,4247,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13433,4247,413);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13434,4247,351);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13435,4248,355);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13436,4248,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13437,4248,465);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13438,4248,351);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13439,4249,332);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13440,4249,450);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13441,4249,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13442,4249,357);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13443,4249,390);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13444,4250,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13445,4250,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13446,4250,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13447,4250,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13448,4250,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13449,4250,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13450,4251,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13451,4251,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13452,4251,335);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13453,4252,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13454,4252,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13455,4252,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13456,4252,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13457,4252,351);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13458,4253,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13459,4253,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13460,4253,457);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13461,4254,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13462,4254,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13463,4254,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13464,4254,362);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13465,4254,465);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13466,4255,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13467,4255,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13468,4255,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13469,4255,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13470,4255,457);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13471,4256,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13472,4256,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13473,4256,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13474,4256,347);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13475,4256,457);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13476,4257,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13477,4257,456);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13478,4257,457);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13479,4258,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13480,4258,440);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13481,4258,350);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13482,4258,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13483,4258,382);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13484,4259,356);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13485,4259,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13486,4259,334);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13487,4259,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13488,4259,357);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13489,4260,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13490,4260,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13491,4260,435);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13492,4260,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13493,4260,350);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13494,4260,409);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13495,4261,435);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13496,4261,472);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13497,4262,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13498,4262,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13499,4262,472);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13500,4262,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13501,4263,467);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13502,4263,409);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13503,4264,439);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13504,4264,501);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13505,4265,458);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13506,4265,501);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13507,4265,459);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13508,4265,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13509,4266,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13510,4266,439);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13511,4266,501);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13512,4267,383);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13513,4267,355);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13514,4267,501);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13515,4268,355);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13516,4268,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13517,4268,332);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13518,4268,351);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13519,4268,501);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13520,4269,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13521,4269,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13522,4269,466);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13523,4269,334);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13524,4269,405);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13525,4269,501);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13526,4270,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13527,4270,501);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13528,4271,446);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13529,4271,501);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13530,4272,439);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13531,4272,335);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13532,4272,324);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13533,4272,426);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13534,4272,480);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13535,4273,480);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13536,4273,439);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13537,4273,324);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13538,4273,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13539,4273,426);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13540,4274,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13541,4274,415);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13542,4274,486);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13543,4274,438);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13544,4274,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13545,4274,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13546,4274,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13547,4274,550);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13548,4275,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13549,4275,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13550,4275,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13551,4275,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13552,4276,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13553,4276,469);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13554,4276,474);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13555,4277,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13556,4277,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13557,4277,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13558,4278,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13559,4278,486);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13560,4278,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13561,4278,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13562,4279,468);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13563,4279,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13564,4279,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13565,4280,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13566,4280,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13567,4280,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13568,4280,421);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13569,4281,348);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13570,4281,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13571,4282,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13572,4282,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13573,4282,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13574,4282,443);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13575,4283,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13576,4283,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13577,4283,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13578,4283,469);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13579,4283,501);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13580,4284,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13581,4284,337);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13582,4285,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13583,4285,341);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13584,4285,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13585,4285,351);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13586,4286,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13587,4286,458);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13588,4286,459);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13589,4286,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13590,4287,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13591,4287,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13592,4287,384);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13593,4288,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13594,4288,341);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13595,4288,328);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13596,4289,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13597,4289,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13598,4289,402);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13599,4289,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13600,4290,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13601,4290,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13602,4290,402);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13603,4290,405);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13604,4291,503);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13605,4291,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13606,4291,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13607,4291,402);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13608,4291,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13609,4292,436);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13610,4292,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13611,4292,518);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13612,4292,409);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13613,4293,436);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13614,4293,337);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13615,4293,518);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13616,4293,409);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13617,4294,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13618,4294,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13619,4295,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13620,4295,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13621,4295,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13622,4295,407);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13623,4295,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13624,4295,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13625,4295,399);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13626,4296,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13627,4296,355);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13628,4296,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13629,4296,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13630,4296,444);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13631,4297,386);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13632,4297,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13633,4297,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13634,4297,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13635,4297,388);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13636,4298,386);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13637,4298,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13638,4298,477);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13639,4298,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13640,4298,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13641,4298,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13642,4298,388);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13643,4299,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13644,4299,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13645,4299,473);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13646,4300,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13647,4300,372);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13648,4300,473);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13649,4300,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13650,4301,476);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13651,4301,473);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13652,4301,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13653,4302,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13654,4302,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13655,4302,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13656,4302,473);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13657,4303,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13658,4303,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13659,4303,350);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13660,4303,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13661,4304,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13662,4304,473);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13663,4304,390);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13664,4305,436);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13665,4305,473);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13666,4305,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13667,4305,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13668,4306,382);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13669,4306,473);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13670,4306,460);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13671,4307,337);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13672,4307,473);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13673,4308,473);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13674,4308,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13675,4308,469);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13676,4309,427);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13677,4309,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13678,4310,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13679,4310,427);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13680,4310,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13681,4311,469);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13682,4311,324);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13683,4312,469);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13684,4312,384);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13685,4313,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13686,4313,324);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13687,4314,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13688,4314,418);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13689,4314,336);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13690,4315,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13691,4315,418);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13692,4316,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13693,4316,418);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13694,4316,374);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13695,4317,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13696,4317,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13697,4317,418);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13698,4317,378);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13699,4318,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13700,4318,378);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13701,4318,372);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13702,4318,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13703,4318,384);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13704,4319,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13705,4319,328);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13706,4320,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13707,4320,361);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13708,4320,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13709,4321,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13710,4321,361);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13711,4321,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13712,4321,374);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13713,4322,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13714,4322,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13715,4322,361);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13716,4322,490);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13717,4323,349);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13718,4323,440);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13719,4323,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13720,4324,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13721,4324,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13722,4324,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13723,4325,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13724,4325,381);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13725,4325,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13726,4326,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13727,4326,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13728,4326,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13729,4327,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13730,4327,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13731,4327,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13732,4328,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13733,4328,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13734,4328,332);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13735,4328,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13736,4329,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13737,4329,364);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13738,4329,351);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13739,4330,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13740,4330,364);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13741,4330,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13742,4331,450);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13743,4331,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13744,4332,386);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13745,4332,408);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13746,4332,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13747,4332,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13748,4332,388);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13749,4333,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13750,4333,344);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13751,4333,386);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13752,4333,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13753,4333,388);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13754,4334,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13755,4334,351);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13756,4335,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13757,4335,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13758,4335,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13759,4335,336);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13760,4335,469);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13761,4336,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13762,4336,405);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13763,4336,522);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13764,4337,355);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13765,4337,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13766,4337,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13767,4337,351);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13768,4338,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13769,4338,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13770,4338,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13771,4338,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13772,4339,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13773,4339,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13774,4339,469);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13775,4339,324);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13776,4340,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13777,4340,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13778,4340,469);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13779,4340,324);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13780,4341,402);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13781,4341,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13782,4341,469);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13783,4341,324);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13784,4342,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13785,4342,469);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13786,4342,324);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13787,4342,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13788,4343,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13789,4343,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13790,4343,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13791,4343,341);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13792,4343,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13793,4344,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13794,4344,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13795,4344,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13796,4345,386);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13797,4345,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13798,4346,386);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13799,4346,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13800,4346,409);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13801,4347,386);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13802,4347,416);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13803,4348,386);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13804,4348,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13805,4348,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13806,4348,466);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13807,4348,334);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13808,4348,405);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13809,4349,328);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13810,4349,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13811,4349,551);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13812,4350,446);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13813,4350,332);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13814,4350,450);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13815,4350,514);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13816,4350,551);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13817,4351,446);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13818,4351,450);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13819,4351,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13820,4351,514);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13821,4351,551);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13822,4352,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13823,4352,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13824,4352,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13825,4353,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13826,4353,332);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13827,4353,411);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13828,4353,350);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13829,4353,374);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13830,4354,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13831,4354,347);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13832,4354,433);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13833,4354,444);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13834,4355,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13835,4355,356);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13836,4355,418);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13837,4355,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13838,4355,336);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13839,4355,420);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13840,4355,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13841,4356,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13842,4356,411);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13843,4356,490);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13844,4356,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13845,4357,383);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13846,4357,381);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13847,4357,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13848,4358,381);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13849,4358,335);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13850,4358,344);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13851,4358,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13852,4359,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13853,4359,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13854,4360,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13855,4360,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13856,4360,378);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13857,4360,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13858,4361,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13859,4361,363);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13860,4361,420);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13861,4362,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13862,4362,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13863,4362,363);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13864,4362,420);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13865,4363,477);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13866,4363,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13867,4363,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13868,4363,451);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13869,4363,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13870,4363,384);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13871,4363,420);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13872,4363,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13873,4364,386);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13874,4364,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13875,4364,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13876,4364,391);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13877,4365,386);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13878,4365,399);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13879,4366,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13880,4366,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13881,4366,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13882,4366,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13883,4366,399);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13884,4367,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13885,4367,356);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13886,4367,418);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13887,4367,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13888,4367,336);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13889,4367,399);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13890,4367,420);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13891,4368,356);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13892,4368,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13893,4368,336);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13894,4368,420);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13895,4369,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13896,4369,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13897,4369,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13898,4369,374);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13899,4370,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13900,4370,326);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13901,4370,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13902,4370,382);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13903,4370,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13904,4370,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13905,4371,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13906,4371,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13907,4371,364);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13908,4371,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13909,4372,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13910,4372,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13911,4372,332);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13912,4372,351);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13913,4372,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13914,4373,382);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13915,4373,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13916,4373,367);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13917,4373,357);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13918,4374,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13919,4374,472);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13920,4375,353);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13921,4375,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13922,4375,354);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13923,4376,465);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13924,4376,443);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13925,4376,334);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13926,4377,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13927,4377,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13928,4377,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13929,4377,465);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13930,4377,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13931,4378,396);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13932,4378,465);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13933,4378,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13934,4379,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13935,4379,366);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13936,4379,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13937,4380,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13938,4380,431);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13939,4380,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13940,4380,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13941,4381,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13942,4381,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13943,4381,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13944,4381,481);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13945,4381,531);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13946,4382,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13947,4382,323);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13948,4382,434);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13949,4382,531);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13950,4383,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13951,4383,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13952,4383,439);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13953,4383,336);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13954,4383,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13955,4384,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13956,4384,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13957,4384,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13958,4385,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13959,4385,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13960,4386,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13961,4386,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13962,4386,482);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13963,4386,319);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13964,4387,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13965,4387,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13966,4387,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13967,4387,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13968,4387,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13969,4387,374);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13970,4388,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13971,4388,427);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13972,4388,349);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13973,4388,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13974,4388,374);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13975,4389,332);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13976,4389,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13977,4390,340);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13978,4390,383);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13979,4390,332);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13980,4391,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13981,4391,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13982,4391,332);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13983,4391,390);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13984,4391,420);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13985,4392,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13986,4392,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13987,4392,332);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13988,4392,465);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13989,4392,490);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13990,4393,330);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13991,4393,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13992,4393,332);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13993,4393,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13994,4393,334);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13995,4394,347);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13996,4394,396);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13997,4394,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13998,4394,474);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
13999,4395,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14000,4395,347);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14001,4395,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14002,4395,528);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14003,4396,347);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14004,4396,337);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14005,4396,473);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14006,4396,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14007,4397,435);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14008,4397,347);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14009,4397,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14010,4398,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14011,4398,454);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14012,4399,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14013,4399,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14014,4399,404);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14015,4399,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14016,4399,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14017,4399,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14018,4400,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14019,4400,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14020,4400,386);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14021,4400,404);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14022,4400,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14023,4400,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14024,4400,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14025,4401,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14026,4401,341);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14027,4401,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14028,4401,351);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14029,4402,348);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14030,4402,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14031,4402,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14032,4403,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14033,4403,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14034,4403,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14035,4403,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14036,4404,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14037,4404,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14038,4404,425);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14039,4404,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14040,4405,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14041,4405,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14042,4405,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14043,4405,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14044,4406,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14045,4406,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14046,4406,439);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14047,4407,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14048,4407,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14049,4407,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14050,4407,364);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14051,4407,481);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14052,4407,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14053,4407,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14054,4408,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14055,4408,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14056,4408,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14057,4408,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14058,4408,481);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14059,4408,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14060,4408,469);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14061,4409,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14062,4409,516);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14063,4409,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14064,4410,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14065,4410,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14066,4410,361);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14067,4410,324);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14068,4410,409);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14069,4410,536);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14070,4411,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14071,4411,405);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14072,4411,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14073,4412,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14074,4412,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14075,4412,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14076,4412,347);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14077,4412,357);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14078,4412,535);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14079,4413,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14080,4413,535);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14081,4413,364);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14082,4413,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14083,4413,336);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14084,4413,357);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14085,4414,462);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14086,4414,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14087,4414,384);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14088,4414,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14089,4415,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14090,4415,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14091,4415,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14092,4415,466);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14093,4415,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14094,4415,334);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14095,4416,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14096,4416,427);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14097,4416,332);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14098,4416,357);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14099,4416,390);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14100,4416,328);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14101,4417,546);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14102,4417,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14103,4417,357);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14104,4417,434);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14105,4417,324);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14106,4417,496);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14107,4418,344);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14108,4418,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14109,4418,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14110,4418,357);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14111,4418,530);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14112,4424,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14113,4424,409);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14114,4424,457);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14115,4425,503);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14116,4425,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14117,4425,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14118,4425,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14119,4426,383);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14120,4426,355);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14121,4426,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14122,4427,435);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14123,4427,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14124,4427,409);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14125,4428,408);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14126,4428,335);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14127,4428,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14128,4429,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14129,4429,336);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14130,4429,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14131,4429,366);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14132,4429,539);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14133,4430,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14134,4430,381);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14135,4430,450);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14136,4430,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14137,4431,457);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14138,4431,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14139,4432,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14140,4432,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14141,4432,490);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14142,4432,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14143,4432,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14144,4433,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14145,4433,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14146,4433,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14147,4433,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14148,4433,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14149,4433,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14150,4433,490);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14151,4434,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14152,4434,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14153,4434,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14154,4434,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14155,4434,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14156,4435,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14157,4435,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14158,4435,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14159,4435,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14160,4435,350);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14161,4436,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14162,4436,366);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14163,4436,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14164,4436,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14165,4436,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14166,4437,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14167,4437,366);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14168,4438,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14169,4438,467);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14170,4439,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14171,4439,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14172,4439,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14173,4439,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14174,4440,383);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14175,4440,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14176,4440,324);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14177,4440,511);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14178,4441,436);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14179,4441,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14180,4441,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14181,4441,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14182,4441,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14183,4442,423);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14184,4442,411);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14185,4443,482);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14186,4443,444);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14187,4443,423);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14188,4444,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14189,4444,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14190,4444,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14191,4444,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14192,4444,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14193,4444,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14194,4445,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14195,4445,357);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14196,4445,389);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14197,4446,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14198,4446,454);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14199,4446,350);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14200,4446,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14201,4447,476);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14202,4447,390);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14203,4447,457);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14204,4448,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14205,4448,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14206,4448,390);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14207,4448,457);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14208,4449,435);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14209,4449,422);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14210,4449,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14211,4450,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14212,4450,415);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14213,4450,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14214,4450,450);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14215,4450,386);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14216,4451,355);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14217,4451,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14218,4452,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14219,4452,482);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14220,4452,334);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14221,4453,482);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14222,4453,490);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14223,4454,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14224,4454,351);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14225,4454,491);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14226,4454,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14227,4455,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14228,4455,345);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14229,4456,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14230,4456,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14231,4456,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14232,4456,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14233,4457,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14234,4457,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14235,4457,319);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14236,4458,537);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14237,4459,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14238,4459,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14239,4459,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14240,4459,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14241,4459,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14242,4460,504);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14243,4460,500);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14244,4460,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14245,4460,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14246,4461,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14247,4461,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14248,4461,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14249,4461,431);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14250,4461,479);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14251,4462,537);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14252,4462,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14253,4462,458);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14254,4462,459);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14255,4462,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14256,4463,343);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14257,4463,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14258,4463,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14259,4463,319);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14260,4464,552);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14261,4464,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14262,4465,552);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14263,4465,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14264,4466,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14265,4466,348);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14266,4466,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14267,4466,424);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14268,4466,386);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14269,4466,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14270,4466,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14271,4466,343);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14272,4467,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14273,4467,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14274,4467,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14275,4467,343);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14276,4467,337);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14277,4468,386);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14278,4468,373);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14279,4468,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14280,4468,388);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14281,4468,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14282,4468,374);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14283,4468,444);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14284,4469,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14285,4469,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14286,4469,470);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14287,4469,352);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14288,4469,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14289,4470,435);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14290,4470,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14291,4470,466);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14292,4470,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14293,4470,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14294,4470,334);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14295,4470,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14296,4470,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14297,4471,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14298,4471,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14299,4471,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14300,4471,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14301,4471,455);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14302,4472,363);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14303,4472,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14304,4473,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14305,4473,444);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14306,4473,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14307,4473,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14308,4473,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14309,4473,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14310,4474,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14311,4474,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14312,4474,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14313,4474,361);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14314,4475,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14315,4475,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14316,4475,361);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14317,4475,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14318,4476,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14319,4476,381);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14320,4476,498);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14321,4476,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14322,4477,381);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14323,4477,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14324,4477,319);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14325,4478,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14326,4478,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14327,4478,381);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14328,4478,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14329,4478,334);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14330,4478,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14331,4478,336);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14332,4478,517);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14333,4479,355);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14334,4479,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14335,4479,336);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14336,4479,539);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14337,4479,366);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14338,4480,332);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14339,4480,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14340,4480,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14341,4480,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14342,4481,332);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14343,4481,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14344,4481,461);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14345,4482,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14346,4482,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14347,4482,465);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14348,4482,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14349,4483,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14350,4483,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14351,4483,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14352,4483,399);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14353,4484,323);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14354,4485,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14355,4485,364);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14356,4485,336);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14357,4486,408);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14358,4486,415);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14359,4486,503);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14360,4486,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14361,4486,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14362,4487,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14363,4487,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14364,4487,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14365,4487,413);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14366,4488,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14367,4488,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14368,4488,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14369,4489,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14370,4489,466);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14371,4489,334);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14372,4489,374);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14373,4490,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14374,4490,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14375,4490,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14376,4490,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14377,4491,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14378,4491,411);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14379,4491,324);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14380,4491,384);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14381,4492,364);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14382,4492,367);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14383,4492,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14384,4493,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14385,4493,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14386,4493,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14387,4493,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14388,4493,367);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14389,4494,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14390,4494,344);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14391,4494,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14392,4494,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14393,4494,433);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14394,4495,344);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14395,4495,425);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14396,4495,433);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14397,4495,417);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14398,4496,332);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14399,4496,357);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14400,4496,390);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14401,4496,433);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14402,4497,549);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14403,4497,456);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14404,4497,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14405,4497,433);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14406,4498,381);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14407,4498,352);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14408,4498,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14409,4499,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14410,4499,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14411,4499,464);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14412,4500,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14413,4500,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14414,4501,477);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14415,4501,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14416,4501,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14417,4501,464);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14418,4501,463);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14419,4501,336);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14420,4501,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14421,4502,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14422,4502,462);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14423,4502,516);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14424,4502,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14425,4502,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14426,4503,383);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14427,4503,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14428,4503,332);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14429,4503,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14430,4504,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14431,4504,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14432,4504,323);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14433,4505,332);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14434,4505,474);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14435,4506,332);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14436,4506,360);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14437,4506,467);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14438,4507,408);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14439,4507,332);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14440,4507,335);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14441,4508,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14442,4508,335);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14443,4508,384);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14444,4509,324);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14445,4509,405);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14446,4510,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14447,4510,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14448,4510,374);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14449,4511,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14450,4511,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14451,4511,416);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14452,4511,399);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14453,4511,484);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14454,4511,503);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14455,4511,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14456,4511,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14457,4512,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14458,4512,382);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14459,4512,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14460,4513,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14461,4513,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14462,4513,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14463,4513,357);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14464,4514,386);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14465,4514,351);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14466,4515,386);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14467,4515,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14468,4515,349);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14469,4515,384);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14470,4516,386);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14471,4516,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14472,4516,434);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14473,4516,522);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14474,4517,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14475,4517,486);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14476,4517,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14477,4517,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14478,4518,361);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14479,4518,324);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14480,4518,409);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14481,4518,490);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14482,4518,536);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14483,4519,434);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14484,4520,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14485,4520,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14486,4520,336);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14487,4520,434);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14488,4521,415);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14489,4521,357);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14490,4521,324);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14491,4522,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14492,4522,479);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14493,4522,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14494,4523,443);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14495,4523,409);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14496,4524,435);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14497,4525,435);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14498,4525,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14499,4526,430);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14500,4527,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14501,4527,399);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14502,4527,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14503,4528,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14504,4528,383);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14505,4528,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14506,4529,328);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14507,4529,456);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14508,4529,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14509,4530,413);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14510,4530,328);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14511,4530,456);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14512,4531,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14513,4531,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14514,4532,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14515,4532,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14516,4533,394);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14517,4533,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14518,4533,510);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14519,4534,383);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14520,4534,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14521,4534,351);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14522,4535,323);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14523,4535,382);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14524,4536,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14525,4536,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14526,4536,349);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14527,4536,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14528,4536,481);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14529,4537,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14530,4537,337);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14531,4537,457);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14532,4538,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14533,4538,438);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14534,4538,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14535,4538,501);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14536,4539,413);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14537,4539,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14538,4539,349);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14539,4540,413);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14540,4540,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14541,4540,469);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14542,4540,324);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14543,4541,413);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14544,4541,341);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14545,4541,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14546,4542,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14547,4542,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14548,4542,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14549,4542,528);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14550,4543,548);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14551,4543,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14552,4543,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14553,4543,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14554,4543,324);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14555,4543,384);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14556,4544,356);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14557,4544,343);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14558,4544,328);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14559,4545,436);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14560,4545,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14561,4545,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14562,4546,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14563,4546,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14564,4546,361);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14565,4546,324);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14566,4546,409);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14567,4546,536);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14568,4547,330);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14569,4547,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14570,4547,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14571,4547,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14572,4547,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14573,4547,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14574,4547,334);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14575,4548,421);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14576,4548,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14577,4548,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14578,4548,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14579,4548,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14580,4549,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14581,4549,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14582,4549,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14583,4550,503);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14584,4550,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14585,4550,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14586,4550,337);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14587,4550,405);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14588,4551,446);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14589,4551,337);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14590,4551,450);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14591,4551,411);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14592,4552,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14593,4552,356);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14594,4552,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14595,4553,356);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14596,4553,347);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14597,4553,409);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14598,4553,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14599,4553,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14600,4554,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14601,4554,439);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14602,4555,478);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14603,4555,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14604,4555,335);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14605,4555,384);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14606,4556,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14607,4556,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14608,4556,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14609,4556,350);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14610,4556,336);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14611,4557,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14612,4557,364);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14613,4557,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14614,4557,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14615,4557,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14616,4558,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14617,4558,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14618,4558,515);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14619,4559,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14620,4559,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14621,4559,386);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14622,4559,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14623,4559,336);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14624,4559,553);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14625,4560,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14626,4560,361);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14627,4560,324);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14628,4560,409);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14629,4560,536);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14630,4561,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14631,4561,337);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14632,4561,396);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14633,4561,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14634,4562,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14635,4562,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14636,4562,441);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14637,4563,413);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14638,4563,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14639,4563,441);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14640,4564,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14641,4564,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14642,4565,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14643,4565,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14644,4565,418);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14645,4566,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14646,4566,323);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14647,4566,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14648,4566,374);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14649,4567,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14650,4567,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14651,4567,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14652,4567,374);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14653,4568,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14654,4568,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14655,4568,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14656,4568,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14657,4569,483);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14658,4569,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14659,4570,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14660,4570,431);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14661,4570,502);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14662,4570,352);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14663,4571,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14664,4571,467);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14665,4572,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14666,4572,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14667,4572,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14668,4572,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14669,4573,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14670,4573,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14671,4573,460);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14672,4574,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14673,4574,364);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14674,4574,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14675,4575,504);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14676,4575,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14677,4575,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14678,4575,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14679,4576,504);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14680,4576,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14681,4576,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14682,4576,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14683,4577,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14684,4577,472);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14685,4577,455);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14686,4578,413);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14687,4578,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14688,4578,472);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14689,4578,455);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14690,4579,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14691,4579,415);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14692,4579,381);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14693,4579,438);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14694,4579,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14695,4580,381);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14696,4580,360);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14697,4580,467);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14698,4580,374);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14699,4581,381);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14700,4581,406);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14701,4581,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14702,4582,451);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14703,4582,381);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14704,4582,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14705,4582,384);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14706,4583,476);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14707,4583,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14708,4583,367);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14709,4584,394);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14710,4584,510);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14711,4584,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14712,4585,462);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14713,4585,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14714,4585,418);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14715,4585,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14716,4585,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14717,4586,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14718,4586,349);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14719,4586,384);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14720,4586,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14721,4587,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14722,4587,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14723,4587,533);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14724,4588,415);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14725,4588,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14726,4588,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14727,4588,357);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14728,4589,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14729,4589,323);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14730,4589,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14731,4589,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14732,4590,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14733,4590,531);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14734,4591,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14735,4591,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14736,4591,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14737,4591,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14738,4592,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14739,4592,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14740,4592,460);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14741,4593,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14742,4593,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14743,4593,460);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14744,4594,546);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14745,4594,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14746,4594,434);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14747,4594,469);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14748,4595,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14749,4595,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14750,4595,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14751,4595,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14752,4595,431);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14753,4595,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14754,4595,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14755,4595,481);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14756,4596,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14757,4596,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14758,4596,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14759,4596,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14760,4596,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14761,4596,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14762,4597,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14763,4597,441);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14764,4598,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14765,4598,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14766,4599,413);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14767,4599,507);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14768,4600,413);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14769,4600,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14770,4600,363);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14771,4600,334);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14772,4600,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14773,4600,357);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14774,4601,413);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14775,4601,467);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14776,4601,409);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14777,4602,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14778,4602,323);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14779,4602,413);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14780,4602,374);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14781,4603,413);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14782,4603,364);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14783,4603,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14784,4603,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14785,4604,413);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14786,4604,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14787,4604,334);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14788,4604,350);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14789,4604,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14790,4604,496);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14791,4605,413);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14792,4605,361);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14793,4605,324);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14794,4605,472);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14795,4605,409);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14796,4605,536);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14797,4606,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14798,4606,413);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14799,4606,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14800,4606,460);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14801,4607,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14802,4607,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14803,4607,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14804,4607,518);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14805,4608,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14806,4608,512);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14807,4609,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14808,4609,319);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14809,4610,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14810,4610,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14811,4610,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14812,4611,381);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14813,4611,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14814,4611,344);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14815,4611,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14816,4612,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14817,4612,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14818,4612,489);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14819,4613,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14820,4613,449);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14821,4613,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14822,4613,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14823,4613,336);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14824,4614,462);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14825,4614,516);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14826,4614,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14827,4614,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14828,4615,365);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14829,4615,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14830,4615,472);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14831,4615,515);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14832,4616,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14833,4616,425);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14834,4616,426);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14835,4617,402);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14836,4617,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14837,4617,352);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14838,4617,336);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14839,4618,344);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14840,4618,341);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14841,4618,419);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14842,4618,508);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14843,4619,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14844,4619,355);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14845,4619,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14846,4619,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14847,4619,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14848,4620,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14849,4620,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14850,4620,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14851,4620,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14852,4620,444);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14853,4620,453);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14854,4621,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14855,4621,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14856,4621,364);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14857,4621,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14858,4621,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14859,4621,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14860,4622,449);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14861,4622,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14862,4622,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14863,4622,426);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14864,4623,503);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14865,4623,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14866,4623,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14867,4623,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14868,4623,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14869,4624,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14870,4624,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14871,4624,406);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14872,4624,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14873,4624,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14874,4625,367);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14875,4625,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14876,4625,475);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14877,4626,364);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14878,4626,398);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14879,4627,332);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14880,4627,398);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14881,4628,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14882,4628,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14883,4628,414);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14884,4628,398);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14885,4629,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14886,4629,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14887,4629,477);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14888,4629,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14889,4629,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14890,4630,477);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14891,4630,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14892,4630,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14893,4630,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14894,4631,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14895,4631,477);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14896,4631,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14897,4631,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14898,4631,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14899,4631,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14900,4631,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14901,4632,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14902,4632,400);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14903,4632,477);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14904,4632,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14905,4632,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14906,4632,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14907,4632,336);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14908,4633,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14909,4633,477);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14910,4633,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14911,4633,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14912,4633,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14913,4633,350);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14914,4633,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14915,4634,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14916,4634,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14917,4635,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14918,4635,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14919,4636,356);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14920,4636,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14921,4637,446);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14922,4637,514);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14923,4638,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14924,4638,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14925,4638,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14926,4638,514);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14927,4639,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14928,4639,366);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14929,4639,501);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14930,4639,455);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14931,4640,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14932,4640,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14933,4640,501);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14934,4641,351);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14935,4641,496);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14936,4641,501);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14937,4642,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14938,4642,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14939,4642,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14940,4642,357);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14941,4642,400);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14942,4643,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14943,4643,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14944,4643,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14945,4643,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14946,4643,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14947,4643,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14948,4643,481);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14949,4643,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14950,4644,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14951,4644,367);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14952,4645,373);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14953,4645,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14954,4645,362);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14955,4645,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14956,4645,374);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14957,4646,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14958,4646,520);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14959,4646,417);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14960,4647,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14961,4647,436);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14962,4647,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14963,4647,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14964,4647,518);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14965,4647,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14966,4647,409);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14967,4648,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14968,4648,409);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14969,4648,469);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14970,4649,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14971,4649,401);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14972,4649,411);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14973,4650,406);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14974,4650,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14975,4650,357);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14976,4650,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14977,4651,404);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14978,4651,374);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14979,4652,431);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14980,4652,437);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14981,4652,324);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14982,4652,496);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14983,4652,543);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14984,4653,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14985,4653,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14986,4653,355);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14987,4653,454);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14988,4653,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14989,4654,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14990,4654,340);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14991,4654,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14992,4655,340);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14993,4655,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14994,4655,469);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14995,4656,330);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14996,4656,340);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14997,4656,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14998,4656,334);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
14999,4656,490);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15000,4657,340);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15001,4657,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15002,4658,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15003,4658,337);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15004,4658,438);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15005,4658,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15006,4658,409);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15007,4659,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15008,4659,474);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15009,4659,461);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15010,4660,331);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15011,4660,474);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15012,4660,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15013,4661,436);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15014,4661,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15015,4661,457);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15016,4662,436);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15017,4662,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15018,4662,514);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15019,4663,412);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15020,4663,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15021,4663,350);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15022,4663,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15023,4664,348);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15024,4664,347);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15025,4664,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15026,4664,350);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15027,4665,347);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15028,4665,366);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15029,4666,348);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15030,4666,347);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15031,4666,450);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15032,4666,434);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15033,4667,527);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15034,4667,335);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15035,4668,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15036,4668,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15037,4668,335);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15038,4668,390);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15039,4669,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15040,4669,423);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15041,4669,367);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15042,4670,332);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15043,4670,423);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15044,4670,335);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15045,4671,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15046,4671,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15047,4671,471);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15048,4671,423);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15049,4671,336);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15050,4671,499);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15051,4671,405);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15052,4672,423);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15053,4672,429);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15054,4673,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15055,4673,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15056,4673,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15057,4673,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15058,4673,363);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15059,4673,420);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15060,4674,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15061,4674,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15062,4674,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15063,4674,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15064,4674,457);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15065,4675,344);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15066,4675,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15067,4675,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15068,4675,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15069,4676,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15070,4676,431);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15071,4676,444);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15072,4677,401);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15073,4677,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15074,4678,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15075,4678,376);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15076,4678,377);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15077,4679,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15078,4679,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15079,4679,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15080,4679,431);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15081,4679,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15082,4680,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15083,4680,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15084,4680,383);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15085,4680,356);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15086,4680,393);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15087,4681,431);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15088,4681,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15089,4681,324);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15090,4682,358);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15091,4682,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15092,4682,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15093,4683,357);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15094,4683,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15095,4683,389);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15096,4684,459);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15097,4685,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15098,4685,366);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15099,4685,438);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15100,4685,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15101,4685,459);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15102,4686,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15103,4686,378);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15104,4686,360);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15105,4686,467);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15106,4686,374);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15107,4687,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15108,4687,378);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15109,4687,328);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15110,4687,342);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15111,4687,335);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15112,4688,549);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15113,4688,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15114,4688,456);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15115,4688,433);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15116,4689,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15117,4689,343);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15118,4689,350);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15119,4690,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15120,4690,430);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15121,4690,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15122,4690,351);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15123,4691,337);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15124,4691,450);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15125,4691,473);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15126,4691,397);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15127,4692,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15128,4692,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15129,4692,407);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15130,4692,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15131,4692,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15132,4693,334);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15133,4693,322);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15134,4693,458);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15135,4693,389);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15136,4693,459);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15137,4693,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15138,4694,410);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15139,4694,368);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15140,4694,321);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15141,4694,481);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15142,4695,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15143,4695,411);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15144,4695,361);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15145,4696,477);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15146,4696,403);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15147,4696,359);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15148,4696,422);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15149,4696,458);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15150,4696,459);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15151,4696,385);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15152,4697,500);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15153,4697,324);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15154,4697,374);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15155,4698,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15156,4698,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15157,4698,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15158,4698,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15159,4698,457);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15160,4699,348);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15161,4699,482);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15162,4700,448);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15163,4700,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15164,4700,443);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15165,4700,444);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15166,4701,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15167,4701,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15168,4701,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15169,4701,421);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15170,4701,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15171,4702,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15172,4702,418);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15173,4702,405);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15174,4703,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15175,4703,386);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15176,4703,464);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15177,4703,387);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15178,4703,388);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15179,4703,350);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15180,4703,490);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15181,4703,370);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15182,4704,418);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15183,4704,465);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15184,4704,318);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15185,4705,332);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15186,4705,465);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15187,4705,421);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15188,4706,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15189,4706,317);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15190,4706,465);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15191,4706,469);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15192,4707,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15193,4707,465);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15194,4707,384);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15195,4708,338);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15196,4708,367);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15197,4708,384);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15198,4709,363);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15199,4709,354);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15200,4710,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15201,4710,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15202,4710,454);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15203,4710,354);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15204,4711,507);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15205,4711,354);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15206,4712,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15207,4712,319);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15208,4712,354);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15209,4713,507);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15210,4713,416);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15211,4714,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15212,4714,482);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15213,4714,328);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15214,4715,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15215,4715,362);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15216,4715,415);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15217,4715,375);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15218,4715,337);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15219,4716,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15220,4716,362);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15221,4716,415);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15222,4716,337);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15223,4716,379);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15224,4717,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15225,4717,362);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15226,4717,415);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15227,4717,337);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15228,4717,371);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15229,4718,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15230,4718,371);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15231,4718,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15232,4718,460);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15233,4718,380);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15234,4719,473);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15235,4719,333);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15236,4719,480);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15237,4720,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15238,4720,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15239,4720,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15240,4720,473);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15241,4721,329);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15242,4721,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15243,4721,386);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15244,4721,350);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15245,4721,336);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15246,4721,499);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15247,4722,386);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15248,4722,339);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15249,4722,346);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15250,4722,327);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15251,4723,325);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15252,4723,316);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15253,4723,323);
INSERT INTO public.saiban_kanji_radicals (id,kanji_id,radical_id) VALUES (
15254,4723,475);
