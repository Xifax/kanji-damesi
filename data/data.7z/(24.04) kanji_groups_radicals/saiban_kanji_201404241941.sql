﻿INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2419,'一',483,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2420,'二',483,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2421,'三',483,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2422,'四',483,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2423,'五',483,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2424,'六',484,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2425,'七',484,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2426,'八',484,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2427,'九',484,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2428,'十',484,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2429,'百',485,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2430,'千',485,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2431,'万',485,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2432,'億',485,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2433,'兆',485,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2434,'円',486,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2435,'時',486,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2436,'寺',486,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2437,'日',486,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2438,'月',486,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2439,'火',487,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2440,'水',487,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2441,'木',487,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2442,'金',487,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2443,'土',487,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2444,'曜',488,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2445,'週',488,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2446,'年',488,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2447,'分',488,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2448,'何',488,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2449,'先',489,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2450,'今',489,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2451,'来',489,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2452,'行',489,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2453,'帰',489,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2454,'大',490,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2455,'中',490,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2456,'小',490,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2457,'少',490,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2458,'多',490,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2459,'上',491,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2460,'下',491,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2461,'右',491,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2462,'左',491,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2463,'方',491,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2464,'人',492,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2465,'入',492,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2466,'出',492,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2467,'外',492,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2468,'内',492,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2469,'本',493,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2470,'休',493,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2471,'体',493,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2472,'力',493,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2473,'協',493,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2474,'目',494,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2475,'口',494,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2476,'耳',494,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2477,'手',494,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2478,'足',494,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2479,'山',495,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2480,'川',495,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2481,'空',495,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2482,'海',495,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2483,'毎',495,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2484,'石',496,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2485,'田',496,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2486,'花',496,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2487,'林',496,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2488,'森',496,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2489,'男',497,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2490,'女',497,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2491,'子',497,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2492,'供',497,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2493,'好',497,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2494,'私',498,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2495,'友',498,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2496,'達',498,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2497,'家',498,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2498,'客',498,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2499,'元',499,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2500,'天',499,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2501,'気',499,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2502,'雨',499,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2503,'雪',499,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2504,'青',500,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2505,'晴',500,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2506,'明',500,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2507,'暗',500,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2508,'昨',500,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2509,'東',501,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2510,'西',501,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2511,'南',501,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2512,'北',501,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2513,'向',501,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2514,'門',502,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2515,'開',502,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2516,'閉',502,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2517,'聞',502,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2518,'間',502,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2519,'高',503,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2520,'安',503,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2521,'低',503,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2522,'最',503,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2523,'初',503,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2524,'前',504,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2525,'後',504,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2526,'午',504,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2527,'牛',504,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2528,'半',504,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2529,'朝',505,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2530,'昼',505,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2531,'晩',505,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2532,'夜',505,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2533,'夕',505,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2534,'食',506,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2535,'飲',506,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2536,'飯',506,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2537,'買',506,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2538,'見',506,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2539,'言',507,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2540,'話',507,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2541,'読',507,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2542,'語',507,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2543,'英',507,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2544,'文',508,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2545,'字',508,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2546,'漢',508,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2547,'書',508,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2548,'覚',508,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2549,'会',509,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2550,'合',509,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2551,'社',509,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2552,'員',509,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2553,'満',509,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2554,'仕',510,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2555,'事',510,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2556,'故',510,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2557,'工',510,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2558,'場',510,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2559,'電',511,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2560,'車',511,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2561,'駅',511,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2562,'交',511,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2563,'通',511,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2564,'道',512,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2565,'路',512,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2566,'地',512,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2567,'図',512,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2568,'他',512,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2569,'止',513,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2570,'歩',513,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2571,'走',513,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2572,'渡',513,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2573,'度',513,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2574,'近',514,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2575,'遠',514,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2576,'長',514,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2577,'短',514,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2578,'広',514,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2579,'全',515,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2580,'部',515,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2581,'国',515,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2582,'世',515,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2583,'界',515,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2584,'白',516,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2585,'黒',516,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2586,'赤',516,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2587,'銀',516,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2588,'鉄',516,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2589,'肉',517,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2590,'魚',517,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2591,'野',517,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2592,'菜',517,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2593,'屋',517,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2594,'米',518,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2595,'茶',518,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2596,'味',518,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2597,'未',518,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2598,'末',518,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2599,'料',519,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2600,'理',519,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2601,'解',519,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2602,'有',519,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2603,'無',519,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2604,'作',520,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2605,'使',520,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2606,'用',520,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2607,'費',520,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2608,'消',520,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2609,'売',521,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2610,'店',521,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2611,'商',521,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2612,'品',521,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2613,'販',521,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2614,'階',522,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2615,'段',522,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2616,'値',522,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2617,'価',522,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2618,'格',522,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2619,'春',523,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2620,'夏',523,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2621,'秋',523,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2622,'冬',523,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2623,'季',523,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2624,'暑',524,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2625,'熱',524,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2626,'寒',524,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2627,'暖',524,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2628,'温',524,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2629,'台',525,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2630,'風',525,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2631,'情',525,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2632,'報',525,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2633,'告',525,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2634,'新',526,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2635,'古',526,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2636,'昔',526,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2637,'良',526,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2638,'悪',526,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2639,'心',527,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2640,'思',527,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2641,'忘',527,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2642,'考',527,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2643,'決',527,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2644,'知',528,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2645,'才',528,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2646,'能',528,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2647,'可',528,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2648,'不',528,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2649,'郵',529,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2650,'便',529,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2651,'局',529,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2652,'番',529,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2653,'号',529,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2654,'住',530,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2655,'所',530,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2656,'氏',530,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2657,'名',530,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2658,'各',530,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2659,'県',531,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2660,'市',531,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2661,'町',531,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2662,'村',531,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2663,'区',531,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2664,'丁',532,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2665,'京',532,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2666,'都',532,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2667,'様',532,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2668,'御',532,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2669,'荷',533,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2670,'物',533,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2671,'重',533,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2672,'軽',533,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2673,'量',533,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2674,'配',534,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2675,'送',534,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2676,'受',534,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2677,'取',534,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2678,'届',534,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2679,'待',535,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2680,'持',535,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2681,'打',535,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2682,'投',535,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2683,'役',535,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2684,'生',536,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2685,'性',536,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2686,'産',536,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2687,'活',536,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2688,'徒',536,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2689,'学',537,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2690,'校',537,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2691,'教',537,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2692,'育',537,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2693,'制',537,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2694,'勉',538,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2695,'強',538,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2696,'弱',538,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2697,'引',538,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2698,'押',538,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2699,'練',539,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2700,'習',539,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2701,'慣',539,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2702,'研',539,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2703,'究',539,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2704,'試',540,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2705,'験',540,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2706,'質',540,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2707,'問',540,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2708,'題',540,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2709,'簡',541,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2710,'単',541,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2711,'複',541,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2712,'雑',541,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2713,'難',541,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2714,'点',542,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2715,'数',542,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2716,'回',542,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2717,'個',542,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2718,'枚',542,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2719,'勝',543,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2720,'負',543,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2721,'担',543,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2722,'当',543,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2723,'然',543,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2724,'法',544,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2725,'律',544,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2726,'規',544,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2727,'則',544,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2728,'施',544,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2729,'経',545,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2730,'済',545,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2731,'営',545,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2732,'株',545,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2733,'式',545,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2734,'企',546,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2735,'業',546,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2736,'利',546,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2737,'益',546,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2738,'収',546,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2739,'技',547,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2740,'術',547,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2741,'芸',547,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2742,'製',547,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2743,'造',547,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2744,'必',548,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2745,'要',548,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2746,'求',548,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2747,'請',548,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2748,'額',548,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2749,'計',549,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2750,'算',549,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2751,'差',549,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2752,'割',549,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2753,'残',549,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2754,'支',550,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2755,'払',550,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2756,'返',550,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2757,'借',550,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2758,'貸',550,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2759,'申',551,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2760,'込',551,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2761,'期',551,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2762,'限',551,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2763,'急',551,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2764,'切',552,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2765,'符',552,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2766,'券',552,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2767,'賃',552,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2768,'代',552,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2769,'指',553,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2770,'定',553,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2771,'予',553,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2772,'約',553,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2773,'束',553,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2774,'変',554,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2775,'化',554,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2776,'更',554,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2777,'増',554,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2778,'減',554,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2779,'乗',555,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2780,'降',555,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2781,'着',555,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2782,'脱',555,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2783,'税',555,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2784,'立',556,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2785,'座',556,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2786,'席',556,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2787,'欠',556,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2788,'次',556,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2789,'運',557,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2790,'転',557,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2791,'移',557,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2792,'動',557,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2793,'働',557,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2794,'早',558,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2795,'速',558,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2796,'遅',558,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2797,'始',558,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2798,'終',558,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2799,'現',559,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2800,'在',559,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2801,'実',559,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2802,'過',559,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2803,'去',559,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2804,'発',560,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2805,'表',560,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2806,'紙',560,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2807,'絵',560,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2808,'誌',560,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2809,'音',561,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2810,'楽',561,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2811,'薬',561,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2812,'歌',561,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2813,'欲',561,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2814,'映',562,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2815,'画',562,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2816,'面',562,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2817,'写',562,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2818,'真',562,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2819,'色',563,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2820,'形',563,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2821,'型',563,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2822,'種',563,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2823,'類',563,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2824,'直',564,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2825,'接',564,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2826,'線',564,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2827,'角',564,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2828,'曲',564,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2829,'共',565,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2830,'同',565,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2831,'違',565,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2832,'似',565,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2833,'以',565,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2834,'旅',566,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2835,'館',566,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2836,'宿',566,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2837,'泊',566,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2838,'遊',566,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2839,'和',567,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2840,'洋',567,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2841,'服',567,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2842,'室',567,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2843,'窓',567,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2844,'父',568,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2845,'母',568,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2846,'親',568,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2847,'族',568,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2848,'歳',568,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2849,'姉',569,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2850,'妹',569,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2851,'兄',569,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2852,'弟',569,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2853,'第',569,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2854,'娘',570,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2855,'息',570,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2856,'若',570,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2857,'者',570,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2858,'彼',570,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2859,'結',571,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2860,'婚',571,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2861,'果',571,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2862,'課',571,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2863,'効',571,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2864,'自',572,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2865,'由',572,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2866,'信',572,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2867,'依',572,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2868,'頼',572,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2869,'民',573,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2870,'主',573,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2871,'義',573,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2872,'議',573,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2873,'論',573,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2874,'賛',574,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2875,'反',574,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2876,'対',574,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2877,'応',574,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2878,'答',574,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2879,'特',575,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2880,'別',575,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2881,'専',575,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2882,'般',575,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2883,'的',575,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2884,'普',576,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2885,'並',576,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2886,'平',576,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2887,'均',576,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2888,'等',576,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2889,'病',577,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2890,'院',577,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2891,'医',577,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2892,'歯',577,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2893,'科',577,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2894,'死',578,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2895,'亡',578,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2896,'忙',578,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2897,'疲',578,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2898,'痛',578,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2899,'禁',579,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2900,'煙',579,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2901,'酒',579,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2902,'酔',579,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2903,'杯',579,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2904,'危',580,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2905,'険',580,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2906,'保',580,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2907,'証',580,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2908,'存',580,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2909,'注',581,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2910,'意',581,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2911,'確',581,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2912,'認',581,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2913,'率',581,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2914,'機',582,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2915,'械',582,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2916,'器',582,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2917,'材',582,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2918,'具',582,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2919,'基',583,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2920,'準',583,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2921,'備',583,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2922,'設',583,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2923,'説',583,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2924,'公',584,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2925,'園',584,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2926,'祭',584,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2927,'察',584,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2928,'際',584,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2929,'飛',585,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2930,'航',585,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2931,'船',585,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2932,'港',585,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2933,'島',585,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2934,'完',586,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2935,'成',586,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2936,'功',586,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2937,'失',586,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2938,'敗',586,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2939,'原',587,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2940,'因',587,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2941,'資',587,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2942,'源',587,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2943,'願',587,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2944,'正',588,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2945,'異',588,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2946,'常',588,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2947,'識',588,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2948,'非',588,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2949,'調',589,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2950,'整',589,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2951,'節',589,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2952,'査',589,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2953,'検',589,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2954,'提',590,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2955,'案',590,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2956,'示',590,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2957,'票',590,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2958,'標',590,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2959,'連',591,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2960,'絡',591,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2961,'続',591,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2962,'相',591,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2963,'談',591,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2964,'記',592,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2965,'憶',592,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2966,'録',592,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2967,'登',592,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2968,'秒',592,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2969,'関',593,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2970,'係',593,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2971,'状',593,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2972,'況',593,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2973,'態',593,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2974,'政',594,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2975,'治',594,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2976,'府',594,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2977,'党',594,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2978,'策',594,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2979,'選',595,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2980,'挙',595,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2981,'択',595,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2982,'候',595,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2983,'補',595,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2984,'首',596,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2985,'脳',596,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2986,'悩',596,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2987,'頭',596,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2988,'顔',596,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2989,'改',597,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2990,'革',597,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2991,'命',597,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2992,'令',597,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2993,'領',597,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2994,'組',598,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2995,'織',598,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2996,'進',598,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2997,'推',598,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2998,'拡',598,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
2999,'責',599,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3000,'任',599,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3001,'辞',599,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3002,'委',599,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3003,'託',599,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3004,'勤',600,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3005,'務',600,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3006,'従',600,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3007,'雇',600,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3008,'績',600,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3009,'募',601,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3010,'集',601,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3011,'採',601,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3012,'給',601,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3013,'需',601,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3014,'卒',602,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3015,'就',602,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3016,'職',602,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3017,'退',602,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3018,'屈',602,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3019,'契',603,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3020,'渉',603,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3021,'妥',603,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3022,'条',603,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3023,'件',603,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3024,'参',604,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3025,'惨',604,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3026,'加',604,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3027,'追',604,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3028,'盟',604,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3029,'比',605,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3030,'較',605,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3031,'批',605,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3032,'判',605,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3033,'評',605,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3034,'感',606,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3035,'想',606,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3036,'像',606,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3037,'象',606,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3038,'抽',606,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3039,'障',607,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3040,'修',607,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3041,'傷',607,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3042,'換',607,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3043,'替',607,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3044,'災',608,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3045,'害',608,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3046,'被',608,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3047,'破',608,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3048,'壊',608,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3049,'救',609,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3050,'助',609,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3051,'援',609,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3052,'派',609,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3053,'遣',609,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3054,'警',610,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3055,'官',610,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3056,'管',610,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3057,'犯',610,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3058,'罪',610,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3059,'盗',611,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3060,'殺',611,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3061,'奪',611,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3062,'逮',611,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3063,'捕',611,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3064,'逃',612,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3065,'挑',612,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3066,'戦',612,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3067,'争',612,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3068,'競',612,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3069,'混',613,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3070,'乱',613,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3071,'紛',613,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3072,'統',613,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3073,'総',613,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3074,'探',614,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3075,'捜',614,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3076,'捨',614,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3077,'拾',614,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3078,'索',614,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3079,'湖',615,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3080,'池',615,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3081,'深',615,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3082,'浅',615,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3083,'落',615,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3084,'泳',616,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3085,'波',616,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3086,'流',616,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3087,'洪',616,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3088,'崩',616,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3089,'洗',617,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3090,'油',617,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3091,'浮',617,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3092,'沈',617,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3093,'没',617,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3094,'将',618,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3095,'永',618,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3096,'久',618,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3097,'氷',618,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3098,'河',618,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3099,'冷',619,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3100,'凍',619,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3101,'庫',619,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3102,'蔵',619,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3103,'臓',619,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3104,'快',620,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3105,'適',620,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3106,'摘',620,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3107,'涼',620,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3108,'湿',620,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3109,'汚',621,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3110,'染',621,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3111,'排',621,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3112,'廃',621,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3113,'棄',621,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3114,'景',622,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3115,'影',622,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3116,'響',622,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3117,'環',622,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3118,'境',622,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3119,'観',623,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3120,'光',623,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3121,'測',623,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3122,'太',623,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3123,'陽',623,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3124,'宇',624,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3125,'宙',624,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3126,'星',624,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3127,'衛',624,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3128,'球',624,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3129,'雲',625,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3130,'曇',625,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3131,'震',625,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3132,'振',625,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3133,'揺',625,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3134,'神',626,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3135,'秘',626,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3136,'密',626,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3137,'精',626,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3138,'厳',626,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3139,'貴',627,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3140,'遺',627,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3141,'跡',627,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3142,'奇',627,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3143,'寄',627,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3144,'歴',628,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3145,'史',628,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3146,'紀',628,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3147,'王',628,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3148,'宝',628,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3149,'建',629,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3150,'築',629,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3151,'構',629,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3152,'橋',629,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3153,'柱',629,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3154,'位',630,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3155,'置',630,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3156,'距',630,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3157,'離',630,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3158,'停',630,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3159,'周',631,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3160,'辺',631,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3161,'囲',631,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3162,'範',631,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3163,'隣',631,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3164,'黄',632,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3165,'横',632,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3166,'断',632,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3167,'継',632,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3168,'幅',632,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3169,'欧',633,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3170,'州',633,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3171,'陸',633,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3172,'極',633,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3173,'端',633,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3174,'訪',634,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3175,'房',634,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3176,'諸',634,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3177,'緒',634,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3178,'緑',634,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3179,'貨',635,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3180,'貿',635,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3181,'易',635,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3182,'輸',635,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3183,'輪',635,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3184,'往',636,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3185,'復',636,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3186,'繰',636,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3187,'操',636,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3188,'縦',636,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3189,'渋',637,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3190,'滞',637,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3191,'帯',637,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3192,'携',637,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3193,'併',637,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3194,'留',638,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3195,'守',638,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3196,'宅',638,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3197,'宛',638,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3198,'戻',638,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3199,'起',639,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3200,'寝',639,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3201,'静',639,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3202,'暇',639,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3203,'趣',639,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3204,'両',640,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3205,'片',640,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3206,'側',640,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3207,'裏',640,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3208,'項',640,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3209,'印',641,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3210,'刷',641,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3211,'刊',641,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3212,'冊',641,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3213,'版',641,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3214,'詳',642,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3215,'細',642,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3216,'掲',642,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3217,'載',642,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3218,'積',642,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3219,'翻',643,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3220,'訳',643,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3221,'誤',643,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3222,'訂',643,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3223,'討',643,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3224,'塗',644,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3225,'添',644,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3226,'付',644,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3227,'属',644,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3228,'貼',644,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3229,'省',645,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3230,'略',645,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3231,'概',645,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3232,'念',645,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3233,'含',645,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3234,'順',646,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3235,'序',646,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3236,'逆',646,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3237,'列',646,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3238,'例',646,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3239,'余',647,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3240,'途',647,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3241,'除',647,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3242,'削',647,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3243,'剰',647,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3244,'即',648,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3245,'既',648,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3246,'刻',648,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3247,'締',648,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3248,'緩',648,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3249,'栄',649,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3250,'養',649,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3251,'豊',649,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3252,'富',649,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3253,'副',649,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3254,'苦',650,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3255,'労',650,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3256,'困',650,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3257,'貧',650,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3258,'乏',650,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3259,'甘',651,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3260,'辛',651,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3261,'幸',651,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3262,'福',651,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3263,'祉',651,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3264,'塩',652,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3265,'砂',652,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3266,'糖',652,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3267,'漠',652,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3268,'模',652,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3269,'農',653,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3270,'濃',653,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3271,'漁',653,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3272,'薄',653,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3273,'厚',653,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3274,'圧',654,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3275,'迫',654,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3276,'縮',654,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3277,'伸',654,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3278,'倍',654,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3279,'超',655,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3280,'越',655,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3281,'抜',655,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3282,'昇',655,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3283,'膨',655,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3284,'札',656,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3285,'礼',656,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3286,'謝',656,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3287,'射',656,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3288,'程',656,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3289,'優',657,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3290,'秀',657,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3291,'透',657,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3292,'誘',657,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3293,'導',657,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3294,'希',658,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3295,'望',658,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3296,'志',658,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3297,'努',658,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3298,'怒',658,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3299,'独',659,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3300,'身',659,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3301,'占',659,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3302,'拠',659,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3303,'処',659,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3304,'仲',660,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3305,'介',660,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3306,'紹',660,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3307,'招',660,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3308,'照',660,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3309,'夫',661,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3310,'婦',661,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3311,'妻',661,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3312,'奥',661,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3313,'互',661,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3314,'皆',662,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3315,'我',662,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3316,'誰',662,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3317,'齢',662,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3318,'籍',662,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3319,'愛',663,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3320,'恋',663,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3321,'誕',663,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3322,'延',663,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3323,'祝',663,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3324,'純',664,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3325,'粋',664,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3326,'夢',664,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3327,'錯',664,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3328,'慎',664,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3329,'泣',665,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3330,'涙',665,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3331,'笑',665,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3332,'喜',665,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3333,'恥',665,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3334,'弁',666,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3335,'護',666,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3336,'士',666,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3337,'看',666,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3338,'患',666,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3339,'肯',667,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3340,'否',667,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3341,'述',667,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3342,'裁',667,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3343,'訴',667,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3344,'迷',668,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3345,'惑',668,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3346,'域',668,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3347,'疑',668,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3348,'謎',668,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3349,'著',669,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3350,'権',669,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3351,'侵',669,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3352,'偽',669,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3353,'為',669,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3354,'贈',670,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3355,'賠',670,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3356,'償',670,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3357,'賞',670,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3358,'与',670,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3359,'財',671,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3360,'貯',671,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3361,'預',671,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3362,'融',671,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3363,'隔',671,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3364,'了',672,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3365,'承',672,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3366,'納',672,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3367,'得',672,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3368,'損',672,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3369,'燃',673,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3370,'焼',673,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3371,'燥',673,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3372,'乾',673,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3373,'幹',673,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3374,'酸',674,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3375,'素',674,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3376,'炭',674,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3377,'岩',674,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3378,'岸',674,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3379,'庭',675,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3380,'桜',675,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3381,'咲',675,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3382,'吹',675,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3383,'散',675,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3384,'植',676,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3385,'根',676,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3386,'板',676,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3387,'草',676,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3388,'葉',676,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3389,'呼',677,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3390,'吸',677,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3391,'及',677,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3392,'扱',677,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3393,'級',677,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3394,'胸',678,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3395,'腹',678,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3396,'腰',678,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3397,'肺',678,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3398,'胃',678,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3399,'皿',679,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3400,'血',679,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3401,'液',679,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3402,'溶',679,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3403,'容',679,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3404,'背',680,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3405,'骨',680,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3406,'滑',680,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3407,'折',680,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3408,'析',680,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3409,'健',681,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3410,'康',681,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3411,'診',681,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3412,'珍',681,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3413,'療',681,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3414,'毒',682,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3415,'菌',682,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3416,'症',682,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3417,'清',682,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3418,'潔',682,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3419,'監',683,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3420,'督',683,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3421,'撮',683,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3422,'描',683,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3423,'躍',683,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3424,'再',684,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3425,'編',684,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3426,'放',684,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3427,'視',684,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3428,'聴',684,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3429,'衣',685,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3430,'装',685,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3431,'仮',685,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3432,'鏡',685,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3433,'銅',685,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3434,'演',686,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3435,'劇',686,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3436,'悲',686,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3437,'団',686,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3438,'固',686,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3439,'美',687,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3440,'博',687,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3441,'展',687,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3442,'催',687,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3443,'促',687,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3444,'典',688,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3445,'殊',688,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3446,'徴',688,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3447,'微',688,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3448,'妙',688,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3449,'免',689,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3450,'許',689,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3451,'訓',689,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3452,'詞',689,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3453,'司',689,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3454,'購',690,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3455,'講',690,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3456,'師',690,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3457,'授',690,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3458,'伝',690,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3459,'鳥',691,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3460,'鳴',691,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3461,'声',691,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3462,'卵',691,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3463,'匹',691,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3464,'犬',692,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3465,'馬',692,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3466,'駐',692,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3467,'騒',692,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3468,'飼',692,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3469,'刺',693,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3470,'激',693,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3471,'興',693,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3472,'奮',693,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3473,'驚',693,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3474,'至',694,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3475,'致',694,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3476,'到',694,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3477,'倒',694,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3478,'債',694,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3479,'斜',695,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3480,'傾',695,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3481,'坂',695,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3482,'狭',695,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3483,'徐',695,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3484,'硬',696,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3485,'軟',696,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3486,'柔',696,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3487,'緊',696,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3488,'張',696,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3489,'衝',697,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3490,'突',697,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3491,'触',697,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3492,'壁',697,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3493,'避',697,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3494,'軍',698,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3495,'隊',698,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3496,'墜',698,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3497,'兵',698,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3498,'核',698,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3499,'武',699,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3500,'銃',699,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3501,'充',699,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3502,'弾',699,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3503,'丸',699,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3504,'攻',700,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3505,'撃',700,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3506,'爆',700,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3507,'暴',700,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3508,'襲',700,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3509,'絶',701,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3510,'滅',701,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3511,'防',701,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3512,'妨',701,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3513,'嫌',701,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3514,'撤',702,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3515,'徹',702,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3516,'底',702,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3517,'抵',702,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3518,'抗',702,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3519,'敵',703,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3520,'脅',703,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3521,'威',703,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3522,'勢',703,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3523,'姿',703,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3524,'恐',704,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3525,'怖',704,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3526,'竜',704,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3527,'巨',704,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3528,'拒',704,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3529,'糸',705,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3530,'系',705,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3531,'孫',705,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3532,'絹',705,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3533,'綿',705,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3534,'網',706,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3535,'綱',706,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3536,'縄',706,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3537,'繊',706,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3538,'維',706,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3539,'刀',707,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3540,'刃',707,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3541,'忍',707,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3542,'耐',707,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3543,'矢',707,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3544,'弓',708,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3545,'弦',708,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3546,'弧',708,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3547,'孤',708,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3548,'爪',708,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3549,'旧',709,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3550,'児',709,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3551,'乳',709,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3552,'幼',709,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3553,'幻',709,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3554,'妊',710,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3555,'娠',710,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3556,'姓',710,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3557,'嫁',710,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3558,'姫',710,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3559,'机',711,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3560,'棚',711,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3561,'棒',711,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3562,'柄',711,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3563,'枠',711,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3564,'枝',712,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3565,'枯',712,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3566,'樹',712,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3567,'朽',712,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3568,'巧',712,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3569,'針',713,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3570,'釣',713,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3571,'鍵',713,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3572,'鋼',713,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3573,'鉱',713,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3574,'鋭',714,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3575,'鈍',714,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3576,'鎖',714,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3577,'鎮',714,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3578,'鈴',714,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3579,'谷',715,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3580,'浴',715,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3581,'沿',715,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3582,'浜',715,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3583,'沖',715,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3584,'江',716,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3585,'沢',716,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3586,'湾',716,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3587,'潜',716,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3588,'津',716,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3589,'濯',717,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3590,'浄',717,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3591,'湯',717,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3592,'沸',717,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3593,'騰',717,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3594,'浸',718,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3595,'溝',718,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3596,'滝',718,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3597,'沼',718,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3598,'泉',718,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3599,'豆',719,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3600,'麦',719,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3601,'畑',719,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3602,'耕',719,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3603,'耗',719,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3604,'虫',720,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3605,'毛',720,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3606,'尾',720,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3607,'皮',720,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3608,'髪',720,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3609,'舌',721,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3610,'鼻',721,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3611,'肩',721,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3612,'眼',721,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3613,'眠',721,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3614,'羽',722,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3615,'翌',722,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3616,'翼',722,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3617,'扇',722,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3618,'扉',722,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3619,'戸',723,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3620,'居',723,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3621,'据',723,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3622,'掘',723,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3623,'堀',723,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3624,'畳',724,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3625,'床',724,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3626,'庁',724,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3627,'麻',724,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3628,'腐',724,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3629,'玉',725,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3630,'皇',725,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3631,'聖',725,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3632,'呈',725,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3633,'善',725,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3634,'君',726,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3635,'郡',726,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3636,'俺',726,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3637,'僕',726,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3638,'撲',726,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3639,'老',727,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3640,'孝',727,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3641,'寿',727,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3642,'尊',727,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3643,'敬',727,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3644,'仏',728,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3645,'宗',728,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3646,'崇',728,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3647,'坊',728,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3648,'城',728,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3649,'葬',729,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3650,'儀',729,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3651,'犠',729,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3652,'牲',729,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3653,'冠',729,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3654,'臣',730,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3655,'臨',730,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3656,'閣',730,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3657,'僚',730,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3658,'寮',730,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3659,'憲',731,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3660,'審',731,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3661,'宣',731,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3662,'誓',731,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3663,'誉',731,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3664,'貝',732,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3665,'貢',732,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3666,'貫',732,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3667,'賀',732,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3668,'旦',732,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3669,'竹',733,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3670,'筆',733,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3671,'箱',733,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3672,'袋',733,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3673,'裂',733,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3674,'筒',734,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3675,'笛',734,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3676,'筋',734,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3677,'簿',734,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3678,'帳',734,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3679,'己',735,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3680,'包',735,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3681,'抱',735,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3682,'砲',735,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3683,'砕',735,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3684,'句',736,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3685,'拘',736,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3686,'旬',736,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3687,'殉',736,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3688,'殖',736,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3689,'井',737,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3690,'丼',737,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3691,'麺',737,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3692,'煮',737,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3693,'箸',737,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3694,'干',738,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3695,'汗',738,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3696,'汁',738,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3697,'滴',738,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3698,'浪',738,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3699,'粉',739,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3700,'粒',739,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3701,'粘',739,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3702,'糧',739,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3703,'粧',739,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3704,'羊',740,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3705,'祥',740,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3706,'群',740,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3707,'鮮',740,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3708,'鯨',740,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3709,'玄',741,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3710,'畜',741,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3711,'蓄',741,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3712,'華',741,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3713,'菓',741,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3714,'暮',742,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3715,'墓',742,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3716,'幕',742,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3717,'布',742,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3718,'巾',742,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3719,'俳',743,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3720,'拝',743,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3721,'抑',743,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3722,'仰',743,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3723,'迎',743,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3724,'拍',744,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3725,'把',744,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3726,'握',744,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3727,'掃',744,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3728,'拭',744,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3729,'控',745,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3730,'措',745,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3731,'揚',745,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3732,'拓',745,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3733,'括',745,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3734,'詩',746,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3735,'謡',746,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3736,'誇',746,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3737,'訟',746,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3738,'詐',746,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3739,'誠',747,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3740,'盛',747,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3741,'盆',747,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3742,'盤',747,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3743,'衆',747,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3744,'召',748,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3745,'昭',748,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3746,'哲',748,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3747,'啓',748,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3748,'克',748,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3749,'穴',749,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3750,'又',749,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3751,'双',749,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3752,'丈',749,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3753,'央',749,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3754,'缶',750,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3755,'詰',750,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3756,'吉',750,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3757,'舎',750,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3758,'舗',750,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3759,'香',751,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3760,'冒',751,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3761,'帽',751,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3762,'唱',751,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3763,'晶',751,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3764,'章',752,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3765,'彰',752,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3766,'彫',752,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3767,'彩',752,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3768,'艶',752,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3769,'旨',753,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3770,'脂',753,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3771,'肪',753,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3772,'肥',753,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3773,'胴',753,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3774,'肌',754,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3775,'腕',754,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3776,'脇',754,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3777,'脚',754,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3778,'脈',754,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3779,'矛',755,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3780,'盾',755,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3781,'循',755,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3782,'倉',755,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3783,'創',755,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3784,'斉',756,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3785,'剤',756,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3786,'刈',756,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3787,'剣',756,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3788,'倹',756,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3789,'刑',757,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3790,'罰',757,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3791,'署',757,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3792,'賭',757,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3793,'賊',757,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3794,'凶',758,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3795,'囚',758,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3796,'圏',758,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3797,'巻',758,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3798,'拳',758,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3799,'芝',759,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3800,'茂',759,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3801,'戒',759,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3802,'伐',759,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3803,'幾',759,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3804,'稲',760,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3805,'稼',760,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3806,'秩',760,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3807,'称',760,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3808,'稿',760,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3809,'穏',761,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3810,'隠',761,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3811,'陰',761,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3812,'陥',761,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3813,'陶',761,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3814,'郊',762,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3815,'邸',762,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3816,'邦',762,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3817,'却',762,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3818,'卸',762,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3819,'吐',763,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3820,'壮',763,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3821,'荘',763,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3822,'亭',763,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3823,'豪',763,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3824,'堂',764,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3825,'堅',764,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3826,'賢',764,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3827,'覧',764,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3828,'寛',764,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3829,'里',765,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3830,'埋',765,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3831,'累',765,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3832,'塁',765,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3833,'墨',765,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3834,'童',766,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3835,'瞳',766,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3836,'瞬',766,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3837,'睡',766,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3838,'垂',766,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3839,'尺',767,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3840,'尽',767,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3841,'釈',767,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3842,'尻',767,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3843,'尿',767,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3844,'層',768,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3845,'履',768,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3846,'覆',768,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3847,'覇',768,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3848,'薦',768,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3849,'頃',769,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3850,'須',769,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3851,'頂',769,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3852,'頑',769,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3853,'顧',769,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3854,'頻',770,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3855,'顕',770,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3856,'煩',770,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3857,'賄',770,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3858,'賂',770,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3859,'祖',771,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3860,'狙',771,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3861,'粗',771,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3862,'阻',771,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3863,'宜',771,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3864,'勇',772,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3865,'敢',772,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3866,'牧',772,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3867,'敷',772,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3868,'繁',772,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3869,'敏',773,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3870,'侮',773,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3871,'悔',773,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3872,'悼',773,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3873,'卓',773,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3874,'舞',774,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3875,'踊',774,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3876,'踏',774,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3877,'跳',774,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3878,'蹴',774,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3879,'踪',775,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3880,'践',775,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3881,'桟',775,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3882,'銭',775,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3883,'貪',775,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3884,'寸',776,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3885,'封',776,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3886,'掛',776,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3887,'街',776,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3888,'衡',776,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3889,'徳',777,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3890,'径',777,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3891,'征',777,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3892,'遂',777,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3893,'逐',777,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3894,'還',778,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3895,'巡',778,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3896,'逸',778,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3897,'迅',778,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3898,'迭',778,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3899,'歓',779,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3900,'勧',779,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3901,'稚',779,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3902,'雅',779,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3903,'羅',779,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3904,'雄',780,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3905,'雌',780,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3906,'獲',780,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3907,'穫',780,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3908,'隻',780,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3909,'唯',781,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3910,'堆',781,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3911,'准',781,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3912,'焦',781,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3913,'礁',781,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3914,'烈',782,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3915,'黙',782,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3916,'熟',782,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3917,'蒸',782,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3918,'勲',782,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3919,'庶',783,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3920,'廊',783,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3921,'郷',783,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3922,'郎',783,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3923,'朗',783,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3924,'恩',784,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3925,'恵',784,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3926,'忠',784,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3927,'憩',784,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3928,'懸',784,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3929,'慰',785,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3930,'懲',785,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3931,'慈',785,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3932,'磁',785,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3933,'滋',785,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3934,'宮',786,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3935,'殿',786,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3936,'穀',786,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3937,'殻',786,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3938,'殴',786,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3939,'鬼',787,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3940,'魔',787,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3941,'魅',787,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3942,'魂',787,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3943,'醜',787,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3944,'雷',788,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3945,'霧',788,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3946,'霜',788,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3947,'零',788,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3948,'雰',788,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3949,'露',789,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3950,'霊',789,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3951,'幽',789,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3952,'荒',789,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3953,'慌',789,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3954,'哀',790,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3955,'衰',790,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3956,'衷',790,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3957,'喪',790,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3958,'懐',790,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3959,'祈',791,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3960,'禅',791,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3961,'裸',791,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3962,'裕',791,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3963,'俗',791,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3964,'呂',792,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3965,'侶',792,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3966,'僧',792,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3967,'憎',792,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3968,'曽',792,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3969,'是',793,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3970,'堤',793,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3971,'礎',793,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3972,'旋',793,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3973,'疎',793,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3974,'軒',794,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3975,'軌',794,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3976,'陣',794,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3977,'揮',794,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3978,'輝',794,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3979,'軸',795,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3980,'轄',795,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3981,'斬',795,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3982,'暫',795,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3983,'輩',795,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3984,'陳',796,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3985,'棟',796,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3986,'欄',796,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3987,'槽',796,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3988,'遭',796,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3989,'遇',797,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3990,'偶',797,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3991,'隅',797,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3992,'愚',797,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3993,'甲',797,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3994,'飾',798,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3995,'飽',798,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3996,'飢',798,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3997,'餓',798,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3998,'餌',798,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
3999,'炎',799,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4000,'淡',799,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4001,'灯',799,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4002,'炉',799,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4003,'炊',799,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4004,'灰',800,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4005,'噴',800,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4006,'憤',800,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4007,'慨',800,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4008,'悟',800,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4009,'惜',801,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4010,'恨',801,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4011,'惧',801,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4012,'恒',801,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4013,'垣',801,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4014,'冗',802,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4015,'丹',802,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4016,'凡',802,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4017,'汎',802,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4018,'帆',802,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4019,'執',803,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4020,'摯',803,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4021,'掌',803,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4022,'摩',803,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4023,'擦',803,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4024,'伴',804,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4025,'奏',804,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4026,'奉',804,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4027,'俸',804,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4028,'泰',804,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4029,'伏',805,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4030,'献',805,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4031,'駄',805,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4032,'駆',805,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4033,'騎',805,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4034,'佐',806,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4035,'偵',806,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4036,'倫',806,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4037,'傍',806,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4038,'傑',806,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4039,'侍',807,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4040,'俵',807,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4041,'伺',807,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4042,'俊',807,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4043,'唆',807,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4044,'韓',808,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4045,'緯',808,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4046,'偉',808,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4047,'偏',808,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4048,'遍',808,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4049,'紫',809,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4050,'縁',809,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4051,'紋',809,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4052,'絞',809,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4053,'縛',809,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4054,'紳',810,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4055,'縫',810,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4056,'紡',810,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4057,'紺',810,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4058,'糾',810,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4059,'叫',811,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4060,'呪',811,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4061,'嘆',811,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4062,'喫',811,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4063,'奨',811,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4064,'甚',812,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4065,'堪',812,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4066,'勘',812,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4067,'励',812,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4068,'劣',812,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4069,'昆',813,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4070,'蚊',813,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4071,'蛇',813,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4072,'蛍',813,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4073,'蛮',813,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4074,'虹',814,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4075,'紅',814,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4076,'蜂',814,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4077,'蜜',814,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4078,'巣',814,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4079,'牙',815,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4080,'邪',815,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4081,'虎',815,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4082,'鹿',815,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4083,'麗',815,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4084,'豚',816,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4085,'鶏',816,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4086,'熊',816,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4087,'鶴',816,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4088,'亀',816,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4089,'怪',817,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4090,'獣',817,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4091,'猛',817,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4092,'狩',817,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4093,'猟',817,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4094,'猫',818,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4095,'猿',818,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4096,'狂',818,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4097,'獄',818,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4098,'猶',818,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4099,'慮',819,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4100,'虚',819,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4101,'虐',819,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4102,'虜',819,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4103,'尋',819,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4104,'兼',820,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4105,'廉',820,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4106,'鎌',820,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4107,'謙',820,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4108,'遜',820,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4109,'怠',821,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4110,'慢',821,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4111,'漫',821,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4112,'潮',821,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4113,'瀬',821,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4114,'泥',822,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4115,'濁',822,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4116,'靴',822,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4117,'磨',822,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4118,'暦',822,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4119,'氾',823,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4120,'濫',823,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4121,'溺',823,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4122,'汽',823,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4123,'潟',823,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4124,'漂',824,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4125,'潤',824,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4126,'澄',824,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4127,'漏',824,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4128,'湧',824,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4129,'漬',825,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4130,'潰',825,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4131,'泡',825,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4132,'渦',825,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4133,'禍',825,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4134,'渓',826,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4135,'浦',826,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4136,'涯',826,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4137,'洞',826,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4138,'窟',826,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4139,'舟',827,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4140,'舶',827,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4141,'艦',827,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4142,'艇',827,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4143,'廷',827,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4144,'旗',828,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4145,'欺',828,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4146,'棋',828,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4147,'碁',828,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4148,'駒',828,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4149,'闘',829,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4150,'閥',829,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4151,'閲',829,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4152,'闇',829,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4153,'閑',829,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4154,'窒',830,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4155,'窮',830,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4156,'窃',830,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4157,'赦',830,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4158,'嚇',830,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4159,'呉',831,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4160,'娯',831,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4161,'奴',831,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4162,'隷',831,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4163,'粛',831,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4164,'如',832,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4165,'妃',832,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4166,'嬢',832,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4167,'譲',832,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4168,'壌',832,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4169,'嫉',833,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4170,'妬',833,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4171,'婿',833,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4172,'宴',833,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4173,'妄',833,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4174,'栽',834,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4175,'培',834,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4176,'陪',834,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4177,'剖',834,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4178,'剥',834,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4179,'松',835,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4180,'杉',835,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4181,'梅',835,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4182,'桃',835,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4183,'柿',835,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4184,'芽',836,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4185,'茎',836,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4186,'苗',836,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4187,'芋',836,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4188,'菊',836,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4189,'鉢',837,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4190,'鍋',837,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4191,'鉛',837,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4192,'鐘',837,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4193,'鍛',837,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4194,'銘',838,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4195,'鑑',838,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4196,'錬',838,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4197,'錠',838,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4198,'綻',838,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4199,'挨',839,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4200,'拶',839,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4201,'披',839,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4202,'挿',839,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4203,'搬',839,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4204,'擁',840,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4205,'扶',840,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4206,'抹',840,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4207,'挟',840,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4208,'摂',840,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4209,'捉',841,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4210,'拐',841,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4211,'拉',841,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4212,'拷',841,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4213,'搾',841,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4214,'搭',842,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4215,'塔',842,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4216,'塀',842,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4217,'坑',842,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4218,'壇',842,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4219,'丘',843,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4220,'岳',843,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4221,'崖',843,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4222,'嵐',843,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4223,'柵',843,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4224,'峠',844,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4225,'峰',844,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4226,'峡',844,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4227,'岬',844,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4228,'岐',844,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4229,'架',845,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4230,'枕',845,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4231,'朴',845,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4232,'赴',845,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4233,'訃',845,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4234,'某',846,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4235,'媒',846,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4236,'謀',846,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4237,'詮',846,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4238,'栓',846,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4239,'該',847,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4240,'諾',847,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4241,'詣',847,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4242,'謹',847,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4243,'僅',847,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4244,'諦',848,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4245,'諮',848,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4246,'譜',848,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4247,'諭',848,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4248,'愉',848,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4249,'曖',849,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4250,'昧',849,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4251,'眺',849,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4252,'瞭',849,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4253,'隙',849,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4254,'惰',850,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4255,'堕',850,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4256,'随',850,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4257,'陛',850,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4258,'郭',850,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4259,'帝',851,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4260,'后',851,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4261,'匠',851,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4262,'匿',851,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4263,'厄',851,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4264,'疾',852,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4265,'疫',852,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4266,'痴',852,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4267,'痢',852,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4268,'癒',852,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4269,'癖',853,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4270,'痩',853,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4271,'痕',853,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4272,'凝',853,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4273,'擬',853,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4274,'鼓',854,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4275,'膜',854,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4276,'胞',854,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4277,'胆',854,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4278,'肢',854,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4279,'盲',855,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4280,'腸',855,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4281,'肝',855,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4282,'腫',855,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4283,'瘍',855,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4284,'肘',856,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4285,'膝',856,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4286,'股',856,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4287,'胎',856,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4288,'腺',856,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4289,'袖',857,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4290,'裾',857,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4291,'襟',857,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4292,'唇',857,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4293,'辱',857,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4294,'串',858,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4295,'餅',858,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4296,'煎',858,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4297,'膳',858,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4298,'繕',858,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4299,'酢',859,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4300,'酬',859,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4301,'醒',859,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4302,'酷',859,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4303,'苛',859,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4304,'酪',860,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4305,'醸',860,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4306,'酵',860,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4307,'酎',860,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4308,'酌',860,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4309,'臭',861,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4310,'嗅',861,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4311,'匂',861,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4312,'勾',861,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4313,'叱',861,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4314,'尚',862,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4315,'肖',862,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4316,'宵',862,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4317,'硝',862,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4318,'硫',862,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4319,'伯',863,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4320,'叔',863,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4321,'寂',863,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4322,'戚',863,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4323,'那',863,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4324,'沃',864,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4325,'妖',864,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4326,'沙',864,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4327,'汰',864,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4328,'泌',864,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4329,'傘',865,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4330,'爽',865,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4331,'采',865,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4332,'羨',865,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4333,'羞',865,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4334,'吟',866,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4335,'喚',866,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4336,'嘱',866,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4337,'喩',866,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4338,'嘲',866,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4339,'喝',867,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4340,'渇',867,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4341,'褐',867,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4342,'葛',867,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4343,'藤',867,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4344,'亜',868,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4345,'旺',868,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4346,'班',868,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4347,'斑',868,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4348,'璧',868,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4349,'貌',869,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4350,'懇',869,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4351,'墾',869,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4352,'睦',869,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4353,'寧',869,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4354,'遮',870,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4355,'蔽',870,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4356,'蔑',870,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4357,'萎',870,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4358,'凄',870,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4359,'卑',871,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4360,'碑',871,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4361,'倣',871,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4362,'傲',871,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4363,'緻',871,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4364,'玩',872,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4365,'弄',872,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4366,'奔',872,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4367,'弊',872,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4368,'幣',872,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4369,'塞',873,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4370,'塾',873,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4371,'挫',873,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4372,'捻',873,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4373,'勃',873,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4374,'枢',874,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4375,'桁',874,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4376,'憧',874,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4377,'憬',874,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4378,'慄',874,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4379,'拙',875,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4380,'捗',875,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4381,'頓',875,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4382,'屯',875,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4383,'矯',875,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4384,'但',876,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4385,'且',876,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4386,'箇',876,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4387,'賓',876,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4388,'寡',876,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4389,'芯',877,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4390,'愁',877,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4391,'悠',877,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4392,'憾',877,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4393,'臆',877,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4394,'遷',878,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4395,'遡',878,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4396,'遵',878,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4397,'逝',878,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4398,'弔',878,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4399,'朱',879,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4400,'珠',879,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4401,'漆',879,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4402,'坪',879,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4403,'填',879,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4404,'哺',880,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4405,'唾',880,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4406,'喉',880,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4407,'頬',880,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4408,'顎',880,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4409,'腎',881,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4410,'膚',881,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4411,'眉',881,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4412,'髄',881,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4413,'骸',881,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4414,'蓋',882,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4415,'辣',882,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4416,'憂',882,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4417,'鬱',882,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4418,'彙',882,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4424,'阪',884,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4425,'奈',884,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4426,'梨',884,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4427,'栃',884,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4428,'茨',884,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4429,'岡',885,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4430,'媛',885,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4431,'阜',885,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4432,'畿',885,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4433,'戴',885,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4434,'埼',886,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4435,'椅',886,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4436,'崎',886,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4437,'仙',886,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4438,'柳',886,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4439,'唄',887,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4440,'稽',887,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4441,'褒',887,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4442,'罵',887,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4443,'篤',887,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4444,'墳',888,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4445,'塚',888,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4446,'弥',888,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4447,'隆',888,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4448,'陵',888,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4449,'漸',889,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4450,'淫',889,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4451,'刹',889,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4452,'籠',889,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4453,'箋',889,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4454,'脊',890,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4455,'椎',890,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4456,'梗',890,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4457,'咽',890,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4458,'臼',890,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4459,'畔',891,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4460,'舷',891,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4461,'賦',891,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4462,'毀',891,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4463,'錮',891,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4464,'瓦',892,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4465,'瓶',892,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4466,'釜',892,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4467,'鋳',892,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4468,'窯',892,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4469,'藩',893,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4470,'薪',893,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4471,'藻',893,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4472,'芳',893,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4473,'薫',893,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4474,'貞',894,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4475,'淑',894,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4476,'婆',894,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4477,'姻',894,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4478,'嫡',894,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4479,'剛',895,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4480,'慕',895,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4481,'恭',895,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4482,'悦',895,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4483,'暁',895,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4484,'乙',896,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4485,'丙',896,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4486,'款',896,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4487,'謄',896,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4488,'抄',896,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4489,'宰',897,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4490,'吏',897,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4491,'罷',897,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4492,'劾',897,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4493,'勅',897,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4494,'唐',898,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4495,'庸',898,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4496,'慶',898,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4497,'麓',898,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4498,'楼',898,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4499,'蚕',899,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4500,'桑',899,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4501,'繭',899,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4502,'藍',899,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4503,'穂',899,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4504,'乞',900,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4505,'忌',900,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4506,'怨',900,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4507,'恣',900,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4508,'冶',900,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4509,'尼',901,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4510,'棺',901,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4511,'斎',901,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4512,'享',901,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4513,'冥',901,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4514,'琴',902,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4515,'瑠',902,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4516,'璃',902,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4517,'伎',902,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4518,'戯',902,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4519,'凹',903,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4520,'凸',903,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4521,'壱',903,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4522,'弐',903,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4523,'厘',903,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4524,'斤',904,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4525,'斥',904,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4526,'斗',904,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4527,'升',904,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4528,'租',904,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4529,'楷',905,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4530,'諧',905,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4531,'仁',905,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4532,'佳',905,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4533,'儒',905,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4534,'叙',906,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4535,'孔',906,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4536,'頒',906,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4537,'附',906,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4538,'痘',906,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4539,'詔',907,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4540,'謁',907,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4541,'詠',907,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4542,'塑',907,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4543,'塊',907,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4544,'錦',908,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4545,'畏',908,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4546,'虞',908,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4547,'韻',908,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4548,'賜',908,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4549,'曹',909,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4550,'尉',909,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4551,'爵',909,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4552,'帥',909,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4553,'逓',909,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4554,'侯',910,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4555,'翁',910,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4556,'嗣',910,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4557,'朕',910,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4558,'畝',910,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4559,'璽',911,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4560,'嘘',911,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4561,'噂',911,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4562,'喋',911,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4563,'諜',911,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4564,'叶',912,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4565,'哨',912,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4566,'咤',912,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4567,'喧',912,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4568,'嘩',912,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4569,'吠',913,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4570,'噛',913,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4571,'叩',913,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4572,'噌',913,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4573,'嗜',913,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4574,'咳',914,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4575,'呟',914,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4576,'眩',914,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4577,'嘔',914,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4578,'謳',914,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4579,'嬉',915,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4580,'婉',915,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4581,'娩',915,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4582,'姪',915,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4583,'甥',915,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4584,'濡',916,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4585,'溢',916,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4586,'溜',916,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4587,'汲',916,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4588,'涜',916,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4589,'洩',917,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4590,'沌',917,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4591,'漕',917,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4592,'渚',917,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4593,'堵',917,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4594,'淘',918,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4595,'瀕',918,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4596,'沫',918,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4597,'泄',918,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4598,'沐',918,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4599,'誹',919,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4600,'謗',919,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4601,'詭',919,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4602,'詫',919,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4603,'訣',919,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4604,'諺',920,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4605,'謔',920,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4606,'儲',920,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4607,'賑',920,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4608,'眈',920,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4609,'梱',921,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4610,'杖',921,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4611,'棲',921,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4612,'柑',921,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4613,'橘',921,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4614,'檻',922,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4615,'柩',922,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4616,'桶',922,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4617,'襖',922,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4618,'禄',922,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4619,'揃',923,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4620,'撫',923,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4621,'捧',923,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4622,'揉',923,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4623,'捺',923,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4624,'挽',924,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4625,'拗',924,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4626,'閃',924,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4627,'悶',924,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4628,'闊',924,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4629,'紐',925,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4630,'綴',925,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4631,'絆',925,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4632,'縞',925,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4633,'綺',925,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4634,'只',926,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4635,'呆',926,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4636,'吊',926,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4637,'狼',926,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4638,'狽',926,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4639,'癌',927,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4640,'痺',927,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4641,'疹',927,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4642,'膏',927,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4643,'顆',927,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4644,'肋',928,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4645,'腔',928,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4646,'腱',928,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4647,'膿',928,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4648,'脆',928,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4649,'罠',929,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4650,'冤',929,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4651,'牢',929,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4652,'髭',929,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4653,'剃',929,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4654,'炒',930,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4655,'灼',930,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4656,'熾',930,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4657,'焚',930,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4658,'厨',930,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4659,'巷',931,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4660,'倦',931,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4661,'隈',931,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4662,'猥',931,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4663,'覗',931,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4664,'迂',932,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4665,'辿',932,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4666,'遥',932,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4667,'冴',932,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4668,'凌',932,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4669,'駕',933,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4670,'憑',933,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4671,'騙',933,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4672,'馳',933,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4673,'贅',933,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4674,'隕',934,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4675,'彗',934,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4676,'焉',934,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4677,'昏',934,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4678,'晦',934,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4679,'歪',935,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4680,'稀',935,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4681,'些',935,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4682,'莫',935,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4683,'蒙',935,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4684,'几',936,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4685,'凱',936,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4686,'碗',936,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4687,'礫',936,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4688,'塵',936,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4689,'釘',937,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4690,'斡',937,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4691,'醤',937,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4692,'饉',937,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4693,'毅',937,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4694,'頁',938,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4695,'罫',938,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4696,'繋',938,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4697,'舵',938,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4698,'埠',938,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4699,'竿',939,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4700,'鯉',939,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4701,'暢',939,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4702,'屑',939,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4703,'蟻',939,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4704,'恍',940,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4705,'惚',940,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4706,'愕',940,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4707,'怯',940,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4708,'劫',940,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4709,'彷',941,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4710,'彿',941,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4711,'徘',941,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4712,'徊',941,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4713,'斐',941,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4714,'箔',942,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4715,'濤',942,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4716,'疇',942,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4717,'躊',942,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4718,'躇',942,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4719,'醍',943,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4720,'醐',943,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4721,'珊',943,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4722,'瑚',943,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
INSERT INTO public.saiban_kanji (id,front,group_id,on,kun,gloss,nanori,jlpt,grade,strokes,processed) VALUES (
4723,'托',943,NULL,NULL,NULL,NULL,NULL,NULL,NULL,false);
