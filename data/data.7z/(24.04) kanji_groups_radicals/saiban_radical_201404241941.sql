﻿INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
316,'一',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
317,'二',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
318,'儿',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
319,'囗',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
320,'五',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
321,'ハ',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
322,'亠',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
323,'乙',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
324,'匕',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
325,'ノ',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
326,'九',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
327,'十',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
328,'白',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
329,'｜',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
330,'音',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
331,'⺅',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
332,'心',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
333,'日',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
334,'立',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
335,'冫',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
336,'冂',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
337,'寸',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
338,'土',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
339,'月',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
340,'火',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
341,'水',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
342,'木',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
343,'金',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
344,'ヨ',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
345,'隹',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
346,'口',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
347,'辶',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
348,'干',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
349,'刀',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
350,'亅',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
351,'𠆢',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
352,'米',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
353,'行',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
354,'彳',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
355,'刂',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
356,'巾',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
357,'冖',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
358,'大',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
359,'小',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
360,'夕',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
361,'卜',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
362,'工',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
363,'方',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
364,'人',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
365,'入',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
366,'山',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
367,'力',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
368,'目',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
369,'耳',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
370,'手',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
371,'足',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
372,'川',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
373,'穴',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
374,'宀',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
375,'氵',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
376,'母',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
377,'毋',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
378,'石',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
379,'田',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
380,'⺾',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
381,'女',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
382,'子',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
383,'禾',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
384,'厶',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
385,'又',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
386,'王',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
387,'并',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
388,'羊',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
389,'豕',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
390,'夂',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
391,'元',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
392,'气',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
393,'丶',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
394,'雨',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
395,'青',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
396,'西',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
397,'爿',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
398,'門',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
399,'廾',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
400,'高',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
401,'氏',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
402,'衤',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
403,'幺',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
404,'牛',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
405,'尸',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
406,'免',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
407,'食',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
408,'欠',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
409,'厂',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
410,'貝',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
411,'罒',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
412,'見',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
413,'言',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
414,'舌',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
415,'士',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
416,'文',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
417,'聿',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
418,'⺌',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
419,'礻',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
420,'攵',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
421,'勿',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
422,'車',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
423,'馬',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
424,'父',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
425,'用',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
426,'マ',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
427,'自',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
428,'首',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
429,'也',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
430,'斗',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
431,'止',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
432,'走',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
433,'广',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
434,'凵',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
435,'斤',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
436,'衣',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
437,'長',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
438,'豆',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
439,'矢',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
440,'⻏',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
441,'世',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
442,'黒',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
443,'里',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
444,'灬',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
445,'赤',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
446,'艮',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
447,'肉',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
448,'魚',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
449,'矛',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
450,'爪',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
451,'至',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
452,'角',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
453,'無',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
454,'弓',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
455,'品',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
456,'比',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
457,'⻖',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
458,'殳',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
459,'几',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
460,'⺹',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
461,'井',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
462,'皿',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
463,'風',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
464,'虫',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
465,'忄',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
466,'辛',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
467,'卩',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
468,'亡',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
469,'勹',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
470,'釆',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
471,'戸',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
472,'匚',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
473,'酉',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
474,'已',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
475,'扌',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
476,'生',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
477,'糸',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
478,'羽',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
479,'弋',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
480,'疋',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
481,'頁',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
482,'竹',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
483,'犬',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
484,'斉',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
485,'耒',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
486,'支',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
487,'毛',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
488,'歹',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
489,'甘',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
490,'戈',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
491,'癶',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
492,'谷',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
493,'面',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
494,'色',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
495,'巴',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
496,'彡',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
497,'韋',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
498,'皮',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
499,'冊',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
500,'舟',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
501,'疒',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
502,'歯',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
503,'示',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
504,'玄',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
505,'飛',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
506,'鳥',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
507,'非',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
508,'隶',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
509,'革',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
510,'而',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
511,'尤',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
512,'尢',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
513,'巛',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
514,'犭',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
515,'久',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
516,'臣',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
517,'滴',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
518,'辰',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
519,'麻',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
520,'廴',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
521,'巨',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
522,'禸',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
523,'舛',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
524,'黄',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
525,'乃',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
526,'片',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
527,'牙',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
528,'屮',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
529,'身',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
530,'彑',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
531,'屯',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
532,'鬲',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
533,'及',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
534,'血',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
535,'骨',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
536,'虍',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
537,'臼',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
538,'竜',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
539,'岡',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
540,'亀',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
541,'瓜',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
542,'麦',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
543,'髟',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
544,'鼻',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
545,'奄',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
546,'缶',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
547,'香',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
548,'鬼',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
549,'鹿',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
550,'鼓',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
551,'豸',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
552,'瓦',NULL,NULL,NULL,NULL,NULL);
INSERT INTO public.saiban_radical (id,front,info,alternative,strokes,position,name) VALUES (
553,'爻',NULL,NULL,NULL,NULL,NULL);
