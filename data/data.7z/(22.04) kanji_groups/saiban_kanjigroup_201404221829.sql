﻿INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
483,1,'gate, open, close, hear, between, space');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
484,1,'east, west, south, north, toward');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
485,1,'blue, clear up, light, dark, past, yesterday, tomorrow');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
486,1,'origin, heaven, nature, air, feeling, rain, snow');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
487,1,'I, friend, reach, attain, house, guest, customer');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
488,1,'man, woman, child, attendant, offer, like');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
489,1,'stone, rice field, flower, grove, forest');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
490,1,'mountain, river, sky, empty, sea, every');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
491,1,'eye, mouth, ear, hand, leg, foot');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
492,1,'origin, book, rest, holiday, body, strength, power, cooperate');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
493,1,'person, enter, go out, appear, outside, within');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
494,1,'on, above, top, under, down, right, left, direction, way');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
495,1,'big, medium, center, inside, small, few, many');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
496,1,'previous, before, now, come, go, return, today, last week, this week, next week');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
497,1,'day of the week, week, year, divide, minute, what, what time, what day');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
498,1,'fire, water, tree, gold, money, soil,Tuesday, Wednesday, Thursday, Friday, Saturday');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
499,1,'Yen, time, temple, sun, day, moon, month, Sunday, Monday');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
500,1,'hundred, thousand, ten thousand, hundred million, trillion');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
501,1,'six, seven, eight. nine, ten');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
502,1,'one, two, three, four, five');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
503,1,'floor, steps, value, price, rank');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
504,1,'sell, store, shop, commerce, goods, product');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
505,1,'make, use, expense, disappear, spend');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
506,1,'material, cooking, fee, reason, understand, solution, have, un-, -free');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
507,1,'rice, tea, taste, not yet, end');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
508,1,'meat, fish, field, vegetables, store, shop');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
509,1,'white, black, red, silver, iron');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
510,1,'all, part, country, world, boundary');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
511,1,'near, far, long, short, wide');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
512,1,'stop, walk, run, go across, degrees');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
513,1,'road, path, land, drawing, map, other');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
514,1,'electricity, train, car, station, exchange, traffic, go through');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
515,1,'work, matter, affair, accident, craft, manufacturing, place');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
516,1,'meet, match, company, society, member, full');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
517,1,'sentence, character, Kanji, write, memorize, sense');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
518,1,'say, speak, read, language, English');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
519,1,'eat, drink, meal, buy, watch');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
520,1,'morning, noon, night, early evening');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
521,1,'front, before, after, behind, noon, cattle, half');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
522,1,'high, expensive, relief, inexpensive, low, most, first');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
523,1,'score, point, number, count, round, inning, number of pieces and sheets');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
524,1,'easy, simple, single, plural, complicated, difficult');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
525,1,'test, examine, quality, question, inquire, topic, problem');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
526,1,'train, learn, custom, habit, research, investigate');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
527,1,'study, learn, strong, weak, pull, push');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
528,1,'learn, study, school, teach, grow, system, control');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
529,1,'birth, life, nature, gender, produce, active, student');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
530,1,'wait, hold, own, hit, throw, role, post');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
531,1,'distribute, deliver, send, receive, get, arrive, reach');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
532,1,'cargo, baggage, thing, heavy, light, amount, quantity');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
533,1,'lot number of address, capital, metropolis, appearance, honorific title, honorific prefix');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
534,1,'prefecture, city, town, village, ward');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
535,1,'live, address, place, Mr. Mrs., name, each');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
536,1,'postal service, convenient, bureau, department, number, order');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
537,1,'know, intelligence, talent, ability, possible, impossible, un-, dis-');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
538,1,'heart, mind, think, forget, consider, decide');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
539,1,'new, old, old time, good, bad');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
540,1,'typhoon, wind, information, emotion, report, tell, announce');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
541,1,'hot, heat, cold, warm, temperature');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
542,1,'spring, summer, autumn, winter, season');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
543,1,'movie, film, reflect, screen, surface, plan, project, copy, photograph, truth, middle');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
544,1,'sound, music, song, singer, pronounce, pleasant, fun, easy, medicine, drug, desire, want');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
545,1,'announce, release, discover, invent, indicate, show, paper, letter, picture, painting, magazine');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
546,1,'now, current, appear, exist, real, true, execute, pass, last year, leave, exceed');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
547,1,'early, quick, fast, late, slow, speed, start, begin, finish, end');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
548,1,'carry, convey, drive, operate, turn, fall down, shift, move, animal, automatic, labor, work');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
549,1,'stand, position, sit, seat, attend, be absent, fault, be short of, weak point, next');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
550,1,'ride, get on, get off, fall, transfer, passenger, arrive, wear, take off, tax, evade tax');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
551,1,'change, modify, renew, increase, decrease, tough, culture, chemistry');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
552,1,'finger, appoint, instruct, decide, schedule, reserve, expect, forecast, promise, contract, bundle');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
553,1,'cut, postage stamp, ticket, important, fare, charge, replace, contemporary, era');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
554,1,'apply, propose, term, period of time, time limit, expect, limit, hurry, urgent, express train');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
555,1,'payment, support, return, reply, rent, borrow, debt, lend');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
556,1,'measure, calculate, plan, a clock, budget, balance, gap, divide, 10%, remain, be left');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
557,1,'necessary, certain, sure, important, demand, request, bill, invoice, amount');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
558,1,'technology, technique, skill, engineer, art, artist, manufacture, produce');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
559,1,'company, plan, industry, occupation, profit, use, convenient, advantage, income, collect');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
560,1,'economy, manage, experience, sales, business, stock, ceremony, wedding, official');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
561,1,'law, rule, legal, illegal, method, control, standard, execute, carry out, facilities');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
562,1,'win, lose, game, burden, in charge, share, hit, true, appropriate, of course, nature');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
563,1,'relation, concern, interest, involve, state, situation, circumstances, behavior, attitude');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
564,1,'memory, record, article, guess, register, entry, climb, appear, come onstage, second');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
565,1,'contact, relation, involvement, continue, connect, procedures, consult, talk over, other party');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
566,1,'propose, present, offer, cooperate, guide, show, display, indicate, vote, goal, target, standard');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
567,1,'investigate, check, test, inspect, condition, tune, adjust, control, arrange, maintenance');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
568,1,'right, correct, accurate, normal, abnormal, always, knowledge, common sense, un-, emergency exit');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
569,1,'field, cause, factor, material, ingredient, resources, data, funds, capital, wish, desire');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
570,1,'complete, finish, perfect, succeed, grow, result, lose, unemployment, fail, be defeated');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
571,1,'fly, airplane, airport, harbor, airmail, surface mail, sailing, ship, boat, island, peninsula');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
572,1,'public, fair, unfair, park, zoo, amusement park, festival, police, observe, international, actual');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
573,1,'basis, standard, normal, prepare, equip, facilities, construct, explain, novel, comment, novel');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
574,1,'machine, model, function, instrument, equipment, material, tool, furniture, tableware, vessel');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
575,1,'attention, warning, order, mind, intention, meaning, opinion, certain, accurate, confirm, approve, rate');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
576,1,'dangerous, crisis, insurance, keep, preserve, guarantee, warranty, prove, certify');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
577,1,'forbid, prohibit, smoke, non-smoking, liquor, get drunk, cup');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
578,1,'death, die, pass away, busy, be tired, painful, headache');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
579,1,'illness, disease, hospital, patient, doctor, medical, tooth, science, course, textbook');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
580,1,'normal, common, spread, line up, flat, average, equal');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
581,1,'special, particular, feature, different, separate, expert, exclusive, common, ordinary, purpose');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
582,1,'approve, agree, oppose, reverse, confront, versus, reply, response, answer');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
583,1,'people, citizen, democracy, main, principle, obligation, justice, discussion, argument, diet');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
584,1,'free, liberty, oneself, confidence, nature, reason, trust, believe, rely on');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
585,1,'marry, divorce, result, conclusion, connect, effect, efficiency, section');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
586,1,'daughter, son, breath, rest, young, person, writer, journalist, he, she');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
587,1,'elder sister, younger sister, elder brother, younger brother, rank, No');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
588,1,'father, mother, parents, family, age, kind, familiar, ethnic group');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
589,1,'harmony, peace, Japanese-style, Western-style, clothes, room, window');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
590,1,'travel, journey, hotel, inn, stay, cinema, library, museum, play, enjoy');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
591,1,'together, cooperation, common, same, different, wrong, violation, similar, more, less');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
592,1,'straight, directly, repair, honest, join, connect, line, corner, angle, curve, turn, music');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
593,1,'color, shape, form, model, type, kind, sort, classify, mankind, human race, scenery, view');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
594,2,'scenery, view, business conditions, shadow, affect, influence, echo, environment, border');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
595,2,'dirty, pollute, be infected, be infectious, drain, discharge, eliminate, dump, waste, abolish');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
596,2,'comfortable, pleasant, good condition, appropriate, fit, pick, point out, cool, wet, humidity');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
597,2,'cold, cool, freeze, refrigerator, defrost, store, stock, a safe, garage, organs, heart');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
598,2,'future, forever, eternal, Shogun, after a long time, ice, iceberg, glacier, galaxy');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
599,2,'wash, toilet, oil, petroleum, float, sink, sunset, confiscate');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
600,2,'swim, wave, radio wave, cold wave, stream, flow, distribution, be in fashion, flood, collapse');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
601,2,'lake, pond, battery, deep, serious, shallow, drop, fall, lose an election, settle down');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
602,2,'search, look for, explore, manhunt, investigate a criminal case, throw away, pick up');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
603,2,'mix, be crowded, be confused, disturb, dispute, unify, president, tradition, comprehensive');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
604,2,'escape, run away, challenge, fight, war, compete, competitor, race, match');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
605,2,'steal, rob, plagiarism, kill, murder, plunder, loot, arrest, catch');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
606,2,'police, guard, warning, diplomat, inspector, manage, administer, keep, crime, guilty, innocent');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
607,2,'rescue, save, assist, help, aid, support, dispatch, send (person, team), showy, excellent');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
608,2,'disaster, damage, fire, harm, pollution, suffer, victim, tear, break, destroy, bankrupt');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
609,2,'break down, obstacle, guarantee, secure, repair, correct, training, injury, exchange, substitute');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
610,2,'feeling, impression, image, imagine, idea, expect, forecast, phenomenon, vague, lottery');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
611,2,'compare, ratio, percentage, criticize, comment, judge, reputation, value, evaluate');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
612,2,'participate, take part, miserable, terrible accident, add, join, chase, pursue, alliance, union');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
613,2,'contract, negotiate, compromise, reasonable, condition, terms, regulations, matter, crime');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
614,2,'graduate, get job, take up a new post, occupation, leave one''s job, retire, logic, theory, be warped');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
615,2,'collect, gather, concentrate, recruit, pick, employ, salary, supply, demand, necessities');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
616,2,'work for, commute, working time, obligation, obey, follow, employee, hire, result, achievement');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
617,2,'responsibility, entrust, consign, resign (one''s post, job), committee, dictionary');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
618,2,'organization, structure, assemble, progress, advance, evolve, guess, estimate, expand, spread');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
619,2,'improve, remodel, revise, renew, revolution, reform, command, order, life, territory, president');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
620,2,'neck, capital, leader, Prime Minister, brain, worry, agony, head, top, face');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
621,2,'choose, select, election, player, athlete, candidate, assist, help, climate, weather');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
622,2,'politics, politician, government, policy, treat, cure, party, group, trick');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
623,2,'detailed, particular, thin, small, fine, notice, print, pile up, load, square measure, cubic volume');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
624,2,'mark, print, printing company, publisher, impression, morning paper, magazine, booklet');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
625,2,'both, parents, both side, one side, left side, right side, back side, item, article');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
626,2,'happen, cause, get up, sleep, nap, bedroom, quiet, calm, spare time, vacation, hobby');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
627,2,'hold, being away, defend, protect, conservative, residence, address to be sent, return, refund');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
628,2,'astringent, traffic jam, be delayed, stay, carry with, mobile phone, zone, tropics, merge');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
629,2,'round trip, review, recover, revive, repeat, handle, operate, gymnastics, pilot, vertical');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
630,2,'cargo, cargo ship, currency, trade, easy, simple, import, export, transport, ring, wheel');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
631,2,'visit, countries, islands, together, secret, green, heating, air-conditioning');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
632,2,'Western, Europe, land, continent, North Pole, extreme, forefront, edge, positive, negative');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
633,2,'yellow, gold, side, beside, cross, refuse, judge, decide, inherit, continue, width, wide');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
634,2,'around, surround, enclose, cycle, neighborhood, next to, seaside, range, extent, example');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
635,2,'rank, position, location, replace, put, distance, separate, divorce, split, stop, bus stop');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
636,2,'build, building, construction, architecture, structure, organization, bridge, pillar');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
637,2,'history, one''s personal history, century, king, queen, treasure, public lottery, jewelry');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
638,2,'valuable, valuable article, gene, ruins, mark, trace, miracle, strange, stop at');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
639,2,'God, spirit, mind, nerves, secret, confidence, smuggle, precise, strict, severe');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
640,2,'cloud, cloudy, quake, earthquake, shake, vibrate, pitch, roll');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
641,2,'universe, space, spaceship, astronaut, star, planet, satellite, Earth, ball, balloon, baseball');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
642,2,'sightseeing, tourist, audience, observe, beam, light, shine, measure, forecast, thick, sun');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
643,2,'all, everyone, nothing, we, our (company), who, aging, aging society, nationality');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
644,2,'husband, wife, couple, woman, nurse, depth, each other, compatibility');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
645,2,'relationship, fellow, mediate, intervention, introduce, invitation, lighting, illumination');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
646,2,'single, independent, monopolize, occupy, unique, body, contents, basis, evidence, treat, manage');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
647,2,'hope, wish, desire, rare, disappointed, will, intention, aim, effort, angry, shout');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
648,2,'excellent, gentle, sweet, priority, win championship, transparent, invite, tempt, lead, coach');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
649,2,'bank note, name card, appreciation, rude, reward, apologize, fire, launch, inject, degree, process');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
650,2,'exceed, over, pass, move (house), pull out, select, rise, go up, be promoted, swell, expand, huge');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
651,2,'press, pressure, compress, dynamic, power, threaten, shrink, shorten, stretch, extend, double');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
652,2,'agriculture, farmer, thick, rich (taste), density, fishing, fisherman, thin, thoughtless, thick, gentle');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
653,2,'salt, sand, desert, sugar, vague, pattern, design, model, scale, grope');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
654,2,'sweet, spicy, happy, fortunate, unhappy, welfare, welfare system');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
655,2,'suffering, painful, trouble, bitter, labor, employee, poor, poverty, shortage, lack');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
656,2,'honor, prosper, flourish, nutrition, bring up, rest, educate, rich, plentiful, wealth, vice, sub');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
657,2,'immediately, instantly, already, time, be late for, tighten, fasten, serious, deadline, loose, ease');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
658,2,'surplus, extra, excess, spare time, left over, halfway, delete, remove, shave, reduce');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
659,2,'order, turn, ranking, opposite, reverse, queue, line, row, list up, example, exception');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
660,2,'omit, abbreviate, outline, summary, Ministry of (Finance), concept, memorial, include, contain');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
661,2,'paint, coat with, attach, add, additive, stick, paste, associate with, date, belong to, group');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
662,2,'translation, interpreter, reason, misunderstand, make a mistake, correct, revise, discuss, debate');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
663,2,'poison, food poisoning, sterilize, bacteria, virus, symptoms, clean, pure, dirty, innocent');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
664,2,'health, healthy, health checkup, diagnose, clinic, medical treatment, rare, uncommon');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
665,2,'back (of a body), bone, backbone, slide, slip, fold, snap, break, break a bone, turn right, analyze');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
666,2,'plate, dish, blood, blood pressure, liquid, solution, dissolve, melt, vessel, container, content, easy');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
667,2,'chest, breast, abdomen, stomach, waist, hips, lung, lung cancer');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
668,2,'call, hail, breathe, inhale, absorb, and, reach, spread, handle, level, class, beginners, intermediate');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
669,2,'plant, botanical garden, root, basic, board, billboard, grass, leaf, word, language');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
670,2,'garden, home, family, cherry blossoms, bloom, blow, breathe out, scatter, fall, dissolve');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
671,2,'acid, oxygen, hydrogen, carbon, material, coal, charcoal, rock, lava, coast, shore');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
672,2,'burn, fuel, grill, roast, dry, main (road), leading member, trunk of a tree');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
673,2,'finish, complete, agree, accept, understand, approve, delivery, profit, obtain, lose, damage');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
674,2,'property, finance, loan, save money, deposit, entrust, look after, separate, interval, isolate');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
675,2,'present, gift, donate, compensate, indemnify, prize, award, give, salary, bonus');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
676,2,'remarkable, author, copyright, right, human rights, invade, infringe, fake, action, artificial');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
677,2,'get lost, cannot decide, superstition, trouble, bother, doubt, suspicion, mystery, region, area');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
678,2,'affirm, affirmative, negation, negative, state, describe, court, judge, sue, accuse, appeal');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
679,2,'lawyer, defend, excuse, pay for damage, guard, protect, nurse, care, patient, be ill');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
680,2,'cry, tear, smile, laugh, be glad, be pleased, shame, be embarrassed');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
681,2,'pure, genuine, simple, dream, be crazy about, nightmare, illusion, refrain, careful');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
682,2,'love, fondness, boyfriend, girlfriend, lose love, birth, birthday, extend, postpone, celebration');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
683,2,'fearful, frightful, terrible, scary, horror, dinosaur, huge, enormous, giant, refuse, turn down');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
684,2,'enemy, rival, threaten, frighten, blackmail, menace, might, authority, power, force, figure, pose');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
685,2,'withdraw, remove, pullout, exhaustive, thorough, bottom, resist, oppose, protest');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
686,2,'end, extermination, ruin, die out, disappear, prevent, defend, obstruct, interrupt, dislike, hate');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
687,2,'attack, offense, shoot, fire, bomb, bomber, explode, violence, gang');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
688,2,'weapon, arm, gun, rifle, machine gun, enrich, full, charge a battery, bomb, bullet, round, circle');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
689,2,'troops, military, army, navy, fall, shoot down, soldier, weapon, nuclear, nuclear weapon');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
690,2,'collide, bump into, crash, shock, impact, suddenly, touch, feeling, wall, avoid, evacuate');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
691,2,'hard, tough, coin, soft, mild, flexible, urgent, get nervous, emergency, intimate, stretch, pull');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
692,2,'slope, slanting line, uphill slope, downhill slope, slant, lean, trend, narrow, slowly');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
693,2,'get to, reach, arrive, urgent, match, fatal, fall down, collapse, bankrupt, debt, bond');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
694,2,'stick, sting, stab, exciting, intense, sudden, drastic, impressed, interest, surprise, marvelous');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
695,2,'dog, puppy, horse, horsepower, parking, parking violation, noisy, breed, raise');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
696,2,'bird, bark, mew, sing, ring, voice, statement, egg, counter for small animals');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
697,2,'purchase, subscribe, lecture, course, tuition, teacher, professor, report, message, tradition');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
698,2,'license, exempt, permission, patent, drill, training, noun, verb, boss, master of ceremony');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
699,2,'classic, typical, dictionary, unique, particular, feature, symbol, delicate, strange');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
700,2,'beautiful, art, museum, Dr., exhibition, display, develop, open (exhibition), remind, press');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
701,2,'perform, play, drama, theater, sad, tragedy, miserable, group, solid, hard, fix');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
702,2,'clothes, costume, remodel, temporary, presume, suppose, mirror, telescope, copper, bronze');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
703,2,'again, restart, reform, edit, knitting, broadcast, release, eyesight, regard, ignore, listen');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
704,2,'supervisor, director, coach, press for, remind, take a picture, draw, paint, take an active part');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
705,3,'living, get dark, grave, tomb, cemetery, curtain, open, end, cloth, blanket, hand out, dish towel');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
706,3,'entrance, farm animal, cattle breeding, save, store, gorgeous, brilliant, splendid, sweets, candy');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
707,3,'sheep, lamb, wool, place of origin, scandal, crowd, flock, mob, clear, vivid, fresh, whale');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
708,3,'powder, flour, pollen, grain, sticky, persevering, clay, food, cosmetics, make up');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
709,3,'dry, drought, interfere, sweat, juice, soup, drip, drop, waste, vagrancy, waves');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
710,3,'well, ceiling, (rice) bowl, noodles, boil, simmer, chopsticks');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
711,3,'phrase, words, complaint, restrain, detain, in season, beginning of, die on duty, increase, breed');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
712,3,'oneself, wrap, parcel, siege, surround, hold, hug, ambition, cannon, gun, crush, smash');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
713,3,'pipe, tube, envelope, whistle, warning horn, muscle, story, outline, account book, notebook, bankbook');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
714,3,'bamboo, writing brush, author, box, bag, bag, shopping bag, glove, tear, split, explode, break up');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
715,3,'shellfish, shell, contribute, pierce, carry out, consistency, New Year''s card, New Year''s Day, once');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
716,3,'constitution, judge, umpire, hearing, advertise, declare, swear, pledge, oath, honor, fame');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
717,3,'minister, Prime Minister, face, meet, temporary, cabinet, bureaucrat, colleague, dormitory');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
718,3,'bury, funeral, ceremony, manners, courtesy, victim, casualty, crown');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
719,3,'Buddha, Buddhism, statue, religion, sect, worship, admire, priest, baby, castle');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
720,3,'grow old, aged person, filial piety, congratulation, life span, valuable, respect, honorific');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
721,3,'you, ruler, reign over, district, I, exterminate, wipe out');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
722,3,'ball, precious stone, emperor, imperial family, Bible, Olympic, saint, present, good, improve');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
723,3,'Tatami (mat), floor, government office, hemp, anesthesia, drug, spoil, corrode');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
724,3,'door, closet, well, stay, living room, residence, install, set up, dig, excavate, moat');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
725,3,'wing, feather, following (day, week, year), paper fan, electric fan, door');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
726,3,'tongue, nose, shoulder, eye, sleep, nap, field glasses, a pair of glasses, sleeping drug');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
727,3,'insect, bug, harmful insect, insecticide, hair, feather, down, tail, tail light, skin, fur');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
728,3,'bean, soybean, Tofu, wheat, barley, flour, farm, field, cultivate, agriculture, consume, exhaust');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
729,3,'soak, dip, be flooded, infiltrate, ditch, drain, gutter, waterfall, swamp, marsh, fountain, hot spring');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
730,3,'laundry, washing machine, wash, purification, hot water, steam, boil, seethe, rise suddenly');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
731,3,'inlet, Edo period, marsh, gloss, plentiful, many, bay, gulf, bend, dive, lurk, submarine, Tsunami');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
732,3,'valley, canyon, bath, bathroom, sea-bathing, go along, route, coast, beach, seashore, offshore');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
733,3,'sharp, keen, dull, insensitive, chain, close down, quell, suppress, painkiller, bell, doorbell');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
734,3,'needle, sting, wire, pointer, policy, course, fishing, change, balance, key, steel, mine, mineral');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
735,3,'branch, twig, byroad, wither, dead branch, dry up, trees, broadleaf tree, decay, skillful, ingenious');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
736,3,'desk, shelf, rack, bookshelf, baggage rack, stick, pole, pattern, design, frame');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
737,3,'pregnancy, pregnant woman, family name, full name, wife, bride, princess');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
738,3,'old, old style, restored, pupil, infant, baby, child care, milk, breast, kindergarten, illusion, fantasy');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
739,3,'bow, string, stringed instrument, arc, parentheses, isolated, lonely, orphan, nail, nail clipper');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
740,3,'sword, knife, bear, steal into, patience, cruel, endure, waterproof, arrow, arrow mark');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
741,3,'net, rope, wire netting, baggage rack, lifeline, fiber, textile, synthetic fiber, dietary fiber, delicate');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
742,3,'thread, string, system, systematic, group, grandchild, descendant, silk, cotton, detailed');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
743,3,'intense, powerful, severe, biting, silent, say nothing, tolerate, ripen, skillful, steam, muggy, medal');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
744,3,'only, piled up, accumulate, ratify, burn, hasty, scorch, focus, reef, coral reef, run onto (a reef)');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
745,3,'male, female, bull, cow, stamen, pistil, catch, hunt, obtain, harvest, hero, counter for ships');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
746,3,'welcome, cheer, suggest, invite, canvass, childish, kindergarten, elegant, graceful, cover all, list');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
747,3,'return, make around, patrol, lose, excellent, outstanding, quick, rapid, fire (member, post)');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
748,3,'morals, t, vice, diameter, radius, conquer, achieve, attain, carry out, one by one');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
749,3,'envelope, enclose, blockade, hang, cover, chase, street, shopping street, balance, imbalance');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
750,3,'disappear, abscond, carry out, practical, pier, money, change, small change, devour, greedy');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
751,3,'dance, stage, Kabuki, Bon dance, step on, railroad crossing, crowd, jump, leap, kick, reject');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
752,3,'sensitive, quick, insult, look down, regret, repent, mourn, condolence, desktop, pocket calculator');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
753,3,'courageous, brave, breeding, stock farm, spread, residence, lot, prosper, flourish, shopping area');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
754,3,'ancestor, grandfather, grandmother, aim, shoot, rough, outline, poor, block, obstruct, advantage');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
755,3,'frequent, frequency, remarkable, clear, trouble, worry, complicated, bother, cover the cost, bribe');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
756,3,'time, around, when, essential, receive, obstinate, persevere, strong, look back on, client, adviser');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
757,3,'layer, class, wear (shoes), fulfill, resume, cover, mask, turn over, champion, recommend');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
758,3,'unit of length, scale, reduced scale, run out, do best, interpret, apologize, release, hips, urine');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
759,3,'child, children''s song, nursery rhyme, pupil, eye, blink, a moment, sleep, sleeping drug, hang down');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
760,3,'village, hometown, bury, reclaimed land, sum total, accumulation, base (in baseball), Chinese ink');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
761,3,'dining room, public hall, reliable, formal, strict, wise, clever, exhibition, list, lenient');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
762,3,'exhale, vomit, magnificent, exciting, cottage, restaurant, luxurious, dynamic, heavy (rain, snow)');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
763,3,'suburbs, residence, Japanese (people, movie), federation, sell, repay, cool, wholesale');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
764,3,',, mild, peaceful, hide, conceal, shade, plot, entrap, fault, collapse, pottery, ceramic art');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
765,3,'rice, rice farming, lightning, earn, work, order, disordered, name, title, nickname, manuscript');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
766,3,'turf, lawn, play, drama, bush, admonish, guard, tight security, cut down, conquer, several, many');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
767,3,'bad luck, deadly weapon, atrocious, prisoner, atmosphere, area, range, roll up, tornado, fist, pistol');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
768,3,'punishment, penalty, prison, jail, police station, fire station, bet, gambling, robber, burglar, pirate');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
769,3,'all at once, detergent, insecticide, tablet, pill, trim, cut, mowing, sword, serious, save, economy');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
770,3,'halberd, shield, contradiction, circulate, vicious spiral, warehouse, create, creative, establish');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
771,3,'skin, underwear, arm, ability, armpit, leg, scenario, pulse, pulsation, artery, vein');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
772,3,'point, purpose, purport, fat, plastics, fatten, fertilize, obesity, trunk, body');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
773,3,'sentence, composition, chapter, medal, commendation, sculpture, carve, color, gloss, luster');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
774,3,'fragrance, smell, perfume, risk, adventure, hat, cap, chant, chorus, crystal, liquid crystal');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
775,3,'a can, canned food, pack, fill, good luck, lucky, unlucky, lodgings, paved road, store');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
776,3,'hole, cave, den, again, also, or, twins, both sides, height, durable, strong, all right, center, middle');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
777,3,'call, summon, reveal, Showa (era), philosophy, enlighten, conquer, detailed');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
778,3,'faithful, sincerity, truly, prosperous, active, basis, foundation, people, group, audience');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
779,3,'poem, chant, pop song, folk song, pride, be proud, of exaggerate, sue, fraud, swindle');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
780,3,'wait, restrain, appeal, step, measure, hoist, fly, fry, pioneer, cultivate, inclusive, summarize');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
781,3,'rhythm, moment, applause, blood beat, grasp, understand, shake hands, sweep, clean, wipe, mop');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
782,3,'actor, actress, pray, worship, restrain, repress, respect, believe, welcome');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
783,3,'mud, muddy water, dead drunk, thief, shoes, socks, polish, brush, calendar, A.D.');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
784,3,'neglect, lazy, idle, boast, endure, comics, cartoon, tide, full tide, shallows, rapids');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
785,3,'hold two (positions, usage), low price, sickle, scythe, Kamakura, humble, modest, inferiority');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
786,3,'consider, concern, hesitate, humble, worry, empty, hollow, oppress, maltreat, P.O.W, inquire, ask');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
787,3,'cat, monkey, ape, mad, crazy, enthusiastic, hell, prison, jail, postponement, extension of time');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
788,3,'doubt, suspect, monster, ghost story, animal, beast, furious, intense, hunting, poach');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
789,3,'pig, pork, chicken, bear, polar bear, crane, turtle, crack');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
790,3,'tusk, fang, venom fang, wicked, evil, obstruction, innocence, tiger, deer, stupid, beautiful, gorgeous');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
791,3,'rainbow, deep red, lipstick, black tea, maple, bee, worker bee, queen bee, nectar, syrup, nest, den');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
792,3,'insect, mosquito, snake, poisonous snake, meander, faucet, firefly, barbarous, barbarian');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
793,3,'very, extremely, endure, pardon, intuition, misunderstand, encourage, cheer, inferior, complex');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
794,3,'shout, cry out, curse, spell, grief, sorrow, admire, smoke, coffee shop, encourage, recommend');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
795,3,'gentleman, gentleman''s agreement, sew, seam, spin, dark blue, become entangled, denounce');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
796,3,'purple, violet, edge, fate, relationship, omen, crest, coat, fingerprint, wring, squeeze, tie, restrain');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
797,3,'Korea, latitude, sequence of events, great, great work, bias, prejudice, universal');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
798,3,'Samurai, chamberlain, straw rice-bag, Sumo ring, visit, inquire, quick, suggest, hint, tempt');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
799,3,'assist, detective, reconnaissance, morals, ethical, besides, hear a trial, best work, outstanding');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
800,3,'turn (face) down, hide, surrender, contribute, donate, wasteful, run, pioneer, knight, jockey');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
801,3,'accompany, partner, play music, concert, ensemble, solo, serve, volunteer, salary, peace, quiet');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
802,3,'do, execute, persist, stick, honest, sincere, grasp, conductor (bus and train), friction, rub, wear out');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
803,3,'joke, verbose, painstaking, efforts, commonplace, mediocre person, wide use, sail, sailing boat');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
804,3,'regret, grudge, resentment, misgivings, apprehensive, customary, permanent, hedge');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
805,3,'ash, volcanic ash, spout, erupt, fountain, anger, indignation, deep emotion, understand, realize');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
806,3,'flame, blaze, light, plain, fresh water, lighthouse, streetlight, fireplace, nuclear reactor, cook (rice)');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
807,3,'decoration, ornament, get tired of, lose interest, starve, hunger, food, feeding, victim');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
808,3,'treatment, encounter, coincidence, spouse, corner, foolish, stupid, carapace, purpose in life');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
809,3,'display, exhibit, apologize, petition, ridge, building, column, blank, tank, bathtub, encounter, SOS');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
810,3,'axis, shaft, jurisdiction, control, cut (by sword), temporary, temporary measure, senior, junior, fellow');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
811,3,'eaves, counter for houses, track, position, resign, press, , command, conductor, shine, sparkle');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
812,3,'correct, approve, seawall, embankment, basis, turn, whirlwind, melody, neglect, avoid, depopulation');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
813,3,'bath, (Buddhist) priest, partner, hate, enmity, abhorrence, great-grandfather (grandmother)');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
814,3,'pray, Zen meditation, nude, bare feet, rich, wealthy, spare, margin, vulgar, secular society');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
815,3,'pity, sympathize, mourn, mourning dress, become weak, senility, compromise plan, miss, skeptical');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
816,3,'dew, expose, reveal, introduce, spirit, ghost, devastate, rough, wild, panic, hasty person');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
817,3,'thunder, thunderstorm, land mine, fog, spray, drizzle, frost, zero, zero degrees, atmosphere');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
818,3,'ogre, devil, demon, magic, wizard, witch, witchcraft, charm, attractive, soul, spirit, ugly');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
819,3,'palace, Shinto shrine, temple, grain, cereal, granary, shell, earth''s crust, punch, hit');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
820,3,'comfort, console, punishment, imprisonment, charity, magnet, radio wave, nourishment');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
821,3,'benefit, benefactor, blessing, wisdom, advice, faithful, loyalty, rest, with all one''s might, anxiety');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
822,3,'ordinary people, corridor, art gallery, hometown, local dishes, bride, groom, cheerful, good news');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
823,3,'too early, Buddhist priest, portrait, portrait rights, early evening, nitric acid, sulfuric acid, sulfur');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
824,3,'smell, good smell, bad smell, stink, odorless, deodorize, slope, detain, scold');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
825,3,'dairy farming, brew, ferment, yeast, enzyme, Shochu, drink Sake, extenuating circumstances');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
826,3,'vinegar, acetic acid, reward, pay, without pay, awake, drug, severe, brutal, coldhearted');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
827,3,'stick, spit, rice cake, roast (beans, tea), green tea, decoct, dining table, arrange, repair, patch');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
828,3,'sleeve, short sleeves, hem, base (of a mountain), collar, scarf, lip, humiliate, insult, shame');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
829,3,'elbow, armrest, knee, crotch, fork, embryo, fetus, gland, prostate gland, sweat gland');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
830,3,'blind, guide dog, blind spot, intestine, duodenum, liver, important, swell, tumor, tumor, ulcer');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
831,3,'drum, beat, membrane, mucous membrane, cell, bold, daring, disappointed, option, arms and legs');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
832,3,'personal habit, bed hair, lose weight, scar, marks, bloodstain, devote, mimicry, sound effect');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
833,3,'disease, illness, dash, gale, immunity, quarantine, groper, complaint, grumbling, diarrhea, cure');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
834,3,'emperor, imperialism, Roman Empire, queen, master, anonymous, hide, misfortune, troublesome');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
835,3,'inertia, lazy, become depraved, follow, very, whenever, everywhere, Emperor, outline');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
836,3,'vague, ambiguous, view, watch, clear, obvious, space, room, chance');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
837,3,'give up, consult, advisory committee, music score, admonish, pleasant, unpleasant');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
838,3,'correspond, agree, accept, visit a temple, humble, behave oneself, imprudent, a few, a little');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
839,3,'one, certain (company), medium, catalyst, plot, intrigue, thoughtless, inquire, stopper, tap');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
840,3,'build over, Holy cross, stretcher, pillow, simple, leave for a new post, news of death');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
841,3,'peak, highest point, summit, mountain range, strait, canyon, cape, turning point, fork, various');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
842,3,'hill, sand hill, mountains region, alpine club, precipice, cliff, landslide, storm, sandstorm, fence');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
843,3,'load, boarding pass, tower, pagoda, control tower, fence, coal mine, rostrum, on the stage, flower bed');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
844,3,'catch, grasp, kidnap, abduct, torture, squeeze, exploit, compress');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
845,3,'protect, support, hug, one''s dependents, cross out, kill, sandwich, attack on both sides, Celsius');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
846,3,'greeting, introduce, wedding reception, insert, carry, transport, convey');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
847,3,'impressed, brand, authentic, judge, enjoy (performance), train, drill, lock, pill, come apart, fail');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
848,3,'flowerpot, potted plant, ,, pot, lead, colored pencil, zinc, bell, warning, train, drill');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
849,3,'bud, sprout, begin to grow, stalk, stem, gums, seedling, potato, sweet potato, chrysanthemum');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
850,3,'pine tree, Japanese cedar, cedar pollen allergy, Japanese apricot, peach, persimmon');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
851,3,'cultivate, raise (plant), Bonsai, culture (bacterium), jury, dissect, autopsy, peel, stuffed specimen');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
852,3,'jealousy, envy, son-in-law, bridegroom, banquet, wedding reception, delusion, paranoia');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
853,3,'suddenly, shortage, vividly, queen, daughter, young lady, sell, transfer, compromise, soil');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
854,3,'fabrics for Kimono, amusement, entertainment, slave, quiet, self-restraint, solemn');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
855,3,'nitrogen, NOx, suffocate, come to the (dead) end, distress, theft, amnesty, threaten, warning shot');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
856,3,'fight, battle, struggle, faction, financial combine, browse, censor, darkness, quiet, inactive');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
857,3,'flag, national flag, flagship, deceive, fraud, trick, swindler, Shogi, Go, man of Shogi');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
858,3,'boat, ship, warship, submarine, fleet, flying boat, motorboat race, Court, court, hold the court');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
859,3,'valley, ravine, mountain stream, bay, inlet, lifetime, cave, cavern, den, haunt, hollow');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
860,3,'pickle, salt, crush, smash, stomach ulcer, bubble, eddy, swirl, root of the evil or trouble');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
861,3,'float, drift, bleach, wet, profit, lubricating oil, abundant, clear, leak, reveal, spring, flow out');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
862,3,'flood, drown, die by drowning, dote on, steamship, steam whistle, tideland');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
863,3,'an iteration mark');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
864,3,'cap, lid, cranium, incisive, caustic, crafty, fear, worry, gloomy, depression, vocabulary');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
865,3,'kidney, skin, eyebrow, unlikely story, marrow, essence, skeleton, wreckage');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
866,3,'feeding bottle, mammals, spit, saliva, throat, cheek, chin, jaw, beard');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
867,3,', vermilion color, vermilion-lacquered, pearl, lacquer, lacquer ware, Tsubo, compensate, fill up');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
868,3,'transfer of the capital, demote, track back, go upstream, compliance, pass away, mourn');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
869,3,'wick, core, lament, grief, sorrow, sadness, calmly, slow, regrettable, be afraid, guess');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
870,3,'however, proviso, also, besides, point, items, guest of honor, guest of the state, oligopoly');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
871,3,'unskillful, childish, hasty, progress, put something in order, careless about, be stationed, correct');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
872,3,'center, central nerves, digit, extraordinary, hanker for, wish for, shudder, tremble with fear');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
873,3,'close, block, fortress, private tutoring school, sprain, setback, discouraged, outbreak, sudden rise');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
874,3,'toy, pet, play with, make a fool of, make every effort, free, wild, evil, abuse, money');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
875,3,'miserly, greedy, mean, unfair, obscene, monument, imitate, arrogant, overbearing, precise, minute');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
876,3,'obstruct, interrupt, cover, hide, despise, look down on, weaken, shrink, terrible, horrible, ghastly');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
877,3,'looks, appearances, attractive looks, change, friendly, familiar, reclaim, cultivate, polite');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
878,3,'subtropical zones, zinc, have a good (appetite, demand), group, spot, perfect, impregnable');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
879,3,'cheers, scold, threat, menace, thirst, dry up, water shortage, brown, struggle, Kudzu, wisteria');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
880,3,'select carefully, summons, rouse, ask, metaphor, simile, figurative, ridicule, deride');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
881,3,'umbrella, parasol, subsidiary, parachute, fresh, bracing, cheers, direct, envy, shame');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
882,3,'fertile, bewitching, voluptuous, specter, fairy, notice, news, natural selection, urinary organs, secrete');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
883,3,'count (earl), countess, uncle, aunt, silent, quiet, lonesome, relative, husband, moment, second');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
884,4,'not flat, concave lens, convex lens, one, two, 0.1percent, almost certainly');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
885,4,'Koto, Joruri, Kabuki, play with, flirt with');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
886,4,'nun, coffin, funeral hall, have enjoy, one''s age at death, divine favor, (pray for) the repose of soul');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
887,4,'beggar, disgusting, in mourning, deep-seated grudge, vengeful ghost, arbitrariness, metallurgy');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
888,4,'silkworm, mulberry, cocoon, indigo blue, ear (of wheat), spike (of rice, wheat)');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
889,4,'Tang, sudden, common, occasion for celebration or sorrow, base (of a mountain), skyscraper');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
890,4,'prime minister, government employee, dismiss, Court of Impeachment, Imperial order');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
891,4,'grade B, smart, nice, young girl, grade C, articles of an association, loan, copy of family register');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
892,4,'stouthearted, sturdy, love, long for, respectful, joy, satisfaction, dawn');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
893,4,'chastity, virtue, lady, ladies and gentlemen, old woman, marriage, one''s heir');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
894,4,'feudal domain of Edo period, firewood, alga, seaweed, aroma, fragrance, smoked (salmon, pork)');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
895,4,'roof tile, collapse, bottle, flower vase, pot, casting, mold, kiln, ceramic industry');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
896,4,'lakeside, riverside, port side, starboard, payment in monthly installments, libel, imprisonment');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
897,4,'spinal cord, spine, myocardial infarction, throat, ear-nose-throat hospital, mortar, dislocation');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
898,4,'gradually, obscene, nymphomaniac, moment, famous temple, shut oneself in, cage, letter paper');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
899,4,'ancient tomb, mound, anthill, shell mound, Yayoi period, upheaval, hill, hilly country');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
900,4,'song, Nagauta, Kouta, practice, funny, praise, reward, abuse, revile, be in a critical condition');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
901,4,'Saitama pref., chair, Nagasaki pref., Sendai city, mountain hermits, unworldly man, willow, Senryu');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
902,4,'Okayama pref., Shizuoka pref., Ehime pref., Gifu pref., Kinki district, coronation ceremony');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
903,4,'Osaka, Nara pref., Hell, Yamanashi pref., pear, Tochigi pref., horse chestnut, Ibaraki pref.');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
904,4,'arrange, put in order, hand over, comb down, offer, devote, rub, massage, trouble, seal, stamp');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
905,4,'cage, punish, coffin, funeral car, tub, bucket, papered sliding door, stipend, presence, dignity');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
906,4,'packing, cane, inhabit, habitat, citrus fruits');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
907,4,'proverb, saying, humor, profit, earn, lively, flourishing, prosper, watch vigilantly for a chance');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
908,4,'slander, speak ill, abuse, sophistry, apology, secret of, key to (success)');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
909,4,'select, natural selection, dying, be fatally injured, spray, splash, droplet infection, excretion, bathing');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
910,4,'leak, disclosed, chaos, row (a boat), beach, feel relieved');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
911,4,'wet, moisten, overflow, accumulate, pile up, draw, pump, blaspheme');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
912,4,'joyful, happy, indirect, delivery, niece, nephew');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
913,4,'cough, cough medicine, mutter, twitter, dazzling, glaring, vomit, throw up, glorify, eulogize');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
914,4,'bite, hit, beat, Miso soup, brains, have a taste for, luxury items');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
915,4,'be fulfilled, patrol, patrol plane, scold, encourage, quarrel, fight, marital quarrel, bark, roar');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
916,4,'Seal of State, lie, liar, gossip, rumor, chat, intelligence, spy');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
917,4,'royalty and nobility, feudal lords, old man, heir, I (used by the emperor), ridge');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
918,4,'sergeant, legal circles, lieutenant, count, baron, marshal, leader, transmission');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
919,4,'Japanese brocade, golden carp, reverence, apprehension, rhyme, phoneme, be honored with');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
920,4,'Imperial edict, audience with (the king), compose (a poem), admire, plasticizer, plasticity, lump, gold bar');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
921,4,'epic poem, lyric poem, describe, Confucius, nostril, air hole, distribute, be attached, tag, smallpox');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
922,4,'block letters, Haiku, joke, humanity and justice, fine work, beautiful woman, Confucianism');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
923,4,'600gram, boycott, Big Dipper, funnel, measure, 1.8 liter, taxes');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
924,4,'the real pleasure of, the real thrill, coral, coral reef, religious mendicancy');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
925,4,'foil, gold leaf, aluminum foil, angry waves, category, hesitate, waver');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
926,4,'resemble closely, remind one, roam, wander, worth, value, purpose of life');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
927,4,'in an ecstasy, in raptures, be shocked, surprise, meanness, unfair, forever, eternity, troublesome');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
928,4,'pole, fishing rod, laundry pole, carp, fluent, rubbish, waste, stardust, ant');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
929,4,'page, ruled line, connect, link, tie, rudder, control, pier');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
930,4,'nail, mediation, soy sauce, famine, resolute, firm, dauntless');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
931,4,'punctual, methodical, triumphant return, rice bowl, teacup, rubble, debris, dust');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
932,4,'warp, distort, rare, uncommon, a little, a bit, huge, enormous, enlighten');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
933,4,'meteorite, comet, end, lethargic sleep, coma, New Year''s Eve');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
934,4,'exceed, surpass, reliability, deceive, cheat, become famous, run, delicious food, luxury');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
935,4,'detour, bypass, thoughtless, pursue, trace, far away, long ago, clear, exceed, surpass');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
936,4,'world, people, weary of married life, everywhere, neighborhood, obscene, obscene story, peep');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
937,4,'parch, roast, fry, scorching, sunbaked, keen, severe, bonfire, kitchen');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
938,4,'trap, false accusation, prison, jail, beard, mustache, shave');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
939,4,'rib, nasal cavity, oral cavity, tendon, pus, suppurate, fragile, weak');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
940,4,'cancer, be numbed, benumbed, eruption, eczema, ointment, granule');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
941,4,'now, be shocked, be stupefied, hang, suspend, wolf, panic');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
942,4,'string, strap, spelling, bonds (of friendship), stripe, beautiful');
INSERT INTO public.saiban_kanjigroup (id,level,info) VALUES (
943,4,'recover, obstinate, persistent, flash, sparkle, suffer agony, trouble, thoughtless, careless, generous');
